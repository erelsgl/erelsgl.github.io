/* alghist.cpp -- algoritm histabbruti l-xi$$uv ha-nittux ha-sabir bioter */

#include <cpplib/wordcnt.h>
#include <iomanip.h> 
#include <morph/morphst2.h>
#include <morph/morphanl.h>
#include <morph/similar.h>
#include <morph/alghist.h>
#include <morph/bw2fw.h>
#include <morph/mone-nit.h>
#include <morph/mone-yid.h>
#include <morph/mone-bw.h>

#include <morph/hpmaio.h>


/***************************************************************************/
/**********        The Databases                                    ********/
/***************************************************************************/

BasewordToFullwordMap the_bw2fw_map;
	// maps each baseword to all it's derived fullwords. See the file morph/bw2fw.h

struct GlobalDatabase {
	MorphOptionsWithSikuiTrie the_approximate_database;
		// this database contains, for each word, the approximate sikui for each option, 
		//	as calculated by the algorithm. See the file morph/morphst.h
	MorphOptionsWithSikuiTrie the_realistic_database;
		// this database contains, for each word, the number of real analyses (approved by the user)
		//	for each option-index. See the file cpplib/intcnttr.h
	WordCounter the_mone_fullword;
		// counts full-words in the corpus. See the file cpplib/wordcnt.h
	MoneBaseword the_mone_baseword;
		// counts basewords (ignoring analyses). See the file morph/mone-bw.h
	MoneNituxim the_mone_nituxim;
		// counts analyses (ignoring lexical-values). See the file morph/mone-nit.h
	MoneYidua the_mone_yidua;
		// counts, for each ECEM, the sikui that it is meyuda / lo-meyuda. See the file morph/mone-yid.h

	uint total_word_count;

	bool idkun_mone_nituxim;
		// controls updating of "the-mone-nituxim" during "xajev_sikuiim_lkol_hamilim".

	bool xijuv_jaqet; 
		// controls message-displaying during "xajev_sikuiim_lkol_hamilim".
	bool xijuv_jaqet_meod;
		// controls logging during "xajev_sikuiim".


	#define LOOP_OVER_ALL_THE_WORDS(cursor) for (MorphOptionsWithSikuiTrie::Cursor cursor(the_approximate_database);  cursor.isvalid();  ++cursor)

	bool isempty() const { return total_word_count==0; }

	MorphOptionsWithSikui analysis_with_approximate_sikuiim (CStr hamila) {
		return the_approximate_database.analysis(hamila);
	}

	MorphOptionsWithSikui independent_analysis_with_approximate_sikuiim (CStr hamila) {
		return duplicate (the_approximate_database.analysis(hamila));
	}



	/****************** Database update ******************************/
	/******             Database update             ******************/
	/****************** Database update ******************************/

	status adken (CStr hamila, MorphInfoCR hanitux) {
		DOr(the_realistic_database.insert (hamila,hanitux));
		DOr(the_mone_fullword.remove_one (hamila));
		return OK;
	}

	status adken (CStr hamila, MorphOptionsWithSikuiCR theoptions) {
		DOr(the_approximate_database.insert(hamila,theoptions));
		DOr(the_realistic_database.insert(hamila,theoptions));
		return OK;
	}

	status move_one_word_from_approximate_database_to_realistic_database (CStr hamila, MorphOptionsWithSikuiCR the_realistic_options) {
		DOx(the_realistic_database.add (hamila,the_realistic_options));
		DOx(the_mone_fullword.remove_one (hamila));
		return OK;
	}

	void adken_monim () { // m&adken ^et 3 ha-monim (baseword, nituxim, yidua)
		// loop over all the words in the corpus, and insert all distinct MorphInfoBasic's to the analysis counter. 
		if (idkun_mone_nituxim) {
			LOOP_OVER_ALL_THE_WORDS(cursor1) {
				CStr cur_fullword = cursor1.string().str;
				MorphOptionsWithSikui cur_options = the_approximate_database.item(cur_fullword);
				LOOPVECTOR(;,cur_options,i) 
					the_mone_nituxim.setcount(cur_options.info(i),0);
			}
		}
		the_mone_yidua.zero_all();
		the_mone_baseword.zero_all();
		
		// loop over all the words in the corpus, and if they are similar to the main_word -- add their probabilities to the sums. 
		LOOP_OVER_ALL_THE_WORDS(cursor) {
			CStr cur_fullword = cursor.string().str;
			logfile << cur_fullword << "; ";
			logfile.flush();
			MorphOptionsWithSikuiCR cur_options = the_approximate_database.item(cur_fullword);
			uint cur_count = the_mone_fullword.count(cur_fullword);
			MorphOptionsWithSikuiCR cur_options_real = the_realistic_database.item(cur_fullword);
			LOOPVECTOR(;,cur_options,i) {
				Sikui cur_sikui =	cur_options.sikui(i) * cur_count + 
									cur_options_real.sikui(i);
				the_mone_baseword.add (cur_options.info(i), cur_sikui);
				if (idkun_mone_nituxim) the_mone_nituxim.add (cur_options.info(i), cur_sikui);
				the_mone_yidua.add (cur_options.info(i), cur_sikui);
			}
		}
	}


	void read_mone_nituxim (CStr thefilename) {
		ifstream input;
		open_infile_with_messages (thefilename,input);
		DOx (read(input,the_mone_nituxim));
		input.close();
		idkun_mone_nituxim = false;
	}



	/**************************** sfor-sikuiim ************************************/
	/***********                  sfor-sikuiim                        *************/
	/**************************** sfor-sikuiim ************************************/

/*
		There are 2 ways to count sikuiim:
			a. The slow way -- implemented by 'sfor_sikuiim' and 'hosef_sikuiim'
			b. The fast way -- implemented by 'sfor_sikuiim_maher'. 
				To use this way, it is required that the analysis-counter will be updated.
				Therefore, you must call 'adken_monim' before using this routine.
				Therefore, it is useful only if there are many words to calculate the sikuiim 
					for, like if you want to calculate the sikuiim for all words in the corpus
					(because then you should update the analysis counter only once).
				If there are few words -- you should use 'the slow way'.
*/

	ArrayOfSikuiim 
	    sikuiim_identical,
	    sikuiim_sbwsast,
		sikuiim_sbw,
	    sikuiim_sast,        
	    sikuiim_yidua,     
		sikuiim_mjuqlalim;


	double 
		mijqal_identical, 
		mijqal_sbwsast, 
		mijqal_sbw, 
		mijqal_sast,
		mijqal_yidua;

	// count-similar-words in a single MorphOptions pair.
	void hosef_sikuiim (MorphOptionsWithSikuiCR cur_options, 
						MorphOptionsWithSikuiCR main_options_s,
						uint weight,         // the weight of the sikuiim in cur_options
						MorphOptionsWithSikuiCR cur_options_real  // the weight of the approved analyses 
					   )
	{
			Dimion sbw, sast;    // variables for similarity check: same baseword, same analysis, same txiliot
			LOOPVECTOR(;,cur_options,i) {
				MorphInfoCR cur_info = cur_options.info(i);     
				Sikui cur_sikui = cur_options.sikui(i)*weight + 
								  cur_options_real.sikui(i);
				LOOPVECTOR(;,main_options_s,j) {
					bdoq_dimion (cur_info,main_options_s.info(j),sbw,sast);
					if (sbw==ZEHUT) sikuiim_sbw[j] += cur_sikui;
					//if (sast==ZEHUT) sikuiim_sast[j] += cur_sikui;
					sikuiim_sast[j] += cur_sikui*sast/ZEHUT;
					// if (sbw==ZEHUT&&sast==ZEHUT) sikuiim_sbwsast[j] += cur_sikui;
					if (sbw==ZEHUT) sikuiim_sbwsast[i] += cur_sikui*sast/ZEHUT;
				}
			}
	}


	// count-similar-words for one main MorphOptions, in the entire database.
	void sfor_sikuiim (CStr main_word, MorphOptionsWithSikuiCR main_options_s) {
		// atxel the result vector 
		init (sikuiim_identical,main_options_s.count() );
		init (sikuiim_sbwsast,main_options_s.count() );
		init (sikuiim_sbw,main_options_s.count() );
		init (sikuiim_sast,main_options_s.count() );
		init (sikuiim_yidua,main_options_s.count() );

		LOOPVECTOR (;, main_options_s, i) {
			sikuiim_identical[i] +=	the_mone_fullword.count(main_word) * main_options_s.sikui(i)  
									+	the_realistic_database.sikui(main_word,i);
		}

		// loop over all the words in the corpus, and if they are similar to the main_word -- add their probabilities to the sums. 
		LOOP_OVER_ALL_THE_WORDS(cursor) {
			CStr cur_fullword = cursor.string().duplicate();
			if (identical (cur_fullword,main_word)) continue;
			MorphOptionsWithSikui cur_options = the_approximate_database.item(cur_fullword);
			uint cur_count = the_mone_fullword.count(cur_fullword);	
			MorphOptionsWithSikui cur_options_real = the_realistic_database.item(cur_fullword);

			hosef_sikuiim (	cur_options,main_options_s, cur_count, cur_options_real );
		}
	}



	// count-similar-words for one main MorphOptions, in the entire database.
	// This function should be called only after 'adken_monim' has been called.
	void sfor_sikuiim_maher (CStr main_word, MorphOptionsWithSikuiCR main_options_s) {
		Dimion sbw,sast;

		// atxel the result vector 
		atxel (sikuiim_identical,main_options_s.count() );
		atxel (sikuiim_sbwsast,main_options_s.count() );
		atxel (sikuiim_sbw,main_options_s.count() );
		atxel (sikuiim_sast,main_options_s.count() );
		atxel (sikuiim_yidua,main_options_s.count() );
		LOOPVECTOR (;, main_options_s, i) {
			MorphInfoCR cur_option = main_options_s.info(i);
			sikuiim_identical[i] +=	the_mone_fullword.count(main_word) * main_options_s.sikui(i)  
									+	the_realistic_database.sikui(main_word,i);
			sikuiim_sast[i] += the_mone_nituxim.count(cur_option);
			//sikuiim_sbw[i] += the_mone_baseword.count(cur_option);
			//sikuiim_sbw[i] -= sikuiim_identical[i];

			if (cur_option.hu(ECEM))
				sikuiim_yidua[i] += the_mone_yidua.shifted_count(cur_option)/2;

			// loop over all the words in the corpus with SBW, and if they are similar to the main_word -- add their probabilities to the sums. 
			FullwordArray& the_fullword_array = the_bw2fw_map.fullword_array(cur_option.baseword());
			for (FullwordArray::Cursor cursor(the_fullword_array); cursor.isvalid(); ++cursor) {
				CStr cur_fullword = cursor.item();
				if (identical (cur_fullword,main_word)) continue;
				uint cur_count = the_mone_fullword.count(cur_fullword);	if (cur_count==0) continue;
				MorphOptionsWithSikui cur_options = the_approximate_database.item(cur_fullword);     
				LOOPVECTOR(;,cur_options,j) {
					Sikui cur_sikui = cur_options.sikui(j)*cur_count + 
									  the_realistic_database.sikui(cur_fullword,j);
					bdoq_dimion (cur_options.info(j),cur_option,sbw,sast);
					//if (sbw==ZEHUT&&sast==ZEHUT) sikuiim_sbwsast[i] += cur_sikui;
					if (sbw==ZEHUT) sikuiim_sbwsast[i] += cur_sikui*sast/ZEHUT;
					if (sbw==ZEHUT) sikuiim_sbw[i] += cur_sikui;
				}
			}
		}
	}


	void sfor_sikuiim (CStr main_word, MorphOptionsWithSikuiCR main_options_s, bool maher) {
		if (maher)
			sfor_sikuiim_maher (main_word, main_options_s);
		else 
			sfor_sikuiim (main_word, main_options_s);
	}


	uint mmd, si_lfny, si_axry;

	/**************************** xajev-sikuiim ************************************/
	/*********                    xajev-sikuiim                         ************************************/
	/**************************** xajev-sikuiim ************************************/

	void xaleq_sikuiim (MorphOptionsWithSikuiCR main_options_s, ArrayOfSikuiim& thesikuiim) {
		LOOPVECTOR (;,thesikuiim,i) {
			mmd = mispar_milim_domot ( main_options_s.info(i) );
			si_lfny = thesikuiim[i];
			thesikuiim[i] = si_lfny / mmd;
			si_axry = thesikuiim[i];
		}
	}

	void xaleq_sikuiim_basic (MorphOptionsWithSikuiCR main_options_s, ArrayOfSikuiim& thesikuiim) {
		LOOPVECTOR (;,thesikuiim,i) thesikuiim[i] /= mispar_milim_domot_basic ( main_options_s.info(i) ) ;
	}


	void jaqlel_sikuiim (MorphOptionsWithSikui main_options_s) {
			normalize (sikuiim_sast,1000.);
			atxel (sikuiim_mjuqlalim,main_options_s.count());
			add (sikuiim_mjuqlalim,sikuiim_identical, mijqal_identical);
			add (sikuiim_mjuqlalim,sikuiim_sbwsast, mijqal_sbwsast);
			add (sikuiim_mjuqlalim,sikuiim_sbw, mijqal_sbw);
			xaleq_sikuiim (main_options_s, sikuiim_mjuqlalim);

			xaleq_sikuiim_basic (main_options_s, sikuiim_sast);
			add (sikuiim_mjuqlalim,sikuiim_sast, mijqal_sast);
			add (sikuiim_mjuqlalim,sikuiim_yidua, mijqal_yidua);
	}



	// calculate sikuiim of all the analyses of the main_word, and adken the database
	virtual void xajev_sikuiim (CStr main_word, bool maher) {
		MorphOptionsWithSikui main_options_s = the_approximate_database.item(main_word);
		if (main_options_s.count()<=1)  return;      // no need to calculate probabilities
		if (!xijuv_jaqet_meod) logfile << endl << main_word << (maher? "| ": ": ");
		sfor_sikuiim (main_word, main_options_s, maher);
		jaqlel_sikuiim (main_options_s);
		if (!xijuv_jaqet_meod) logfile << "GLOBAL yidua " << sikuiim_yidua << " sast " << sikuiim_sast << " sbw " << sikuiim_sbw << " sbwsast " << sikuiim_sbwsast << " identical " << sikuiim_identical << " total " << sikuiim_mjuqlalim << endl;
		main_options_s.set (sikuiim_mjuqlalim);
		the_approximate_database.insert (main_word,main_options_s);   // adken the database
		if (!xijuv_jaqet_meod) logfile << " " << main_options_s << endl;
	}

	void xajev_sikuiim_lkol_hamilim () {
		adken_monim();
		LOOP_OVER_ALL_THE_WORDS(cursor) {
			if (!xijuv_jaqet)
				cerr << cursor.string() << " ";
			xajev_sikuiim (cursor.string().str, true);  // xajev siukuiim maher.
		}
	}


	bool contains_sbwsast (MorphOptionsWithSikuiCR theoptions, MorphInfoCR theinfo) {
		LOOPVECTOR (;,theoptions,i)
			if (are_SBW_SA_ST(theoptions.info(i),theinfo)) return true;
		return false;
	}

	void xajev_sikuiim_lkol_hamilim_im_sbwsast (MorphInfoCR theinfo) {
		FullwordArray& the_fullword_array = the_bw2fw_map.fullword_array(theinfo.baseword());
		bool there_are_many_fullwords = the_fullword_array.count() > 10;
		if (there_are_many_fullwords) 
			adken_monim(); 
		for (FullwordArray::Cursor cursor(the_fullword_array); cursor.isvalid(); ++cursor) {
			CStr cur_fullword = cursor.item();
			MorphOptionsWithSikui& curoptions = the_approximate_database.item(cur_fullword);
			if (contains_sbwsast(curoptions,theinfo)) {
				curoptions.set_sikui_axid();
				xajev_sikuiim (cur_fullword, there_are_many_fullwords );
			}
		}
	}



	bool contains_sbw (MorphOptionsWithSikuiCR theoptions, MorphInfoCR theinfo) {
		LOOPVECTOR (;,theoptions,i)
			if (are_SBW(theoptions.info(i),theinfo)) return true;
		return false;
	}

	void xajev_sikuiim_lkol_hamilim_im_sbw (MorphInfoCR theinfo) {
		FullwordArray& the_fullword_array = the_bw2fw_map.fullword_array(theinfo.baseword());
		bool there_are_many_fullwords = the_fullword_array.count() > 3;
		if (there_are_many_fullwords) 
			adken_monim(); 
		for (FullwordArray::Cursor cursor(the_fullword_array); cursor.isvalid(); ++cursor) {
			xajev_sikuiim (cursor.item(), there_are_many_fullwords );
		}
	}


	/****************** Database I/O ******************************/
	/********           Database I/O                  *************/
	/****************** Database I/O ******************************/


	GlobalDatabase(): 
		the_approximate_database(), 
		the_realistic_database(),
		the_mone_fullword(),
		the_mone_baseword(),
		the_mone_nituxim(),
		the_mone_yidua(),
		sikuiim_identical(20),
		sikuiim_sbwsast(20),
		sikuiim_sbw(20),   
		sikuiim_sast(20),
		sikuiim_yidua(20),
		sikuiim_mjuqlalim(20)
		{ 
			xijuv_jaqet = xijuv_jaqet_meod = false;
			idkun_mone_nituxim = true;
			mijqal_identical = 4;
			mijqal_sbwsast = 2071./1000.; mijqal_sbw = 0./1000.; mijqal_sast =  1134./1000.;  mijqal_yidua = 440./1000.; // harc10
		}


	void log_the_database (ofstream& logfile) {
		//the_approximate_database.remove(":");
		//the_realistic_database.remove(":");
		//the_mone_fullword.remove(":");
		logfile << total_word_count << endl;  
		writeln(logfile,the_approximate_database);
		writeln (logfile, the_mone_fullword);
		writeln (logfile, the_mone_baseword);
		writeln (logfile, the_mone_nituxim);
		writeln (logfile, the_mone_yidua);
		writeln (logfile, the_realistic_database);
	}

	void atxel_realistic_database() {
		LOOP_OVER_ALL_THE_WORDS(cursor) {
			CStr cur_fullword = cursor.string().str;
			MorphOptionsWithSikui cur_options; 
			duplicate (cur_options,the_approximate_database.item(cur_fullword));
			cur_options.zero();
			the_realistic_database.insert(cur_fullword,cur_options);
		}
	}

	void atxel_from_analysis_with_sikui_logfile (CStr analysis_with_sikui_filename) {
		ifstream input;
		open_infile_with_messages (analysis_with_sikui_filename,input);
		assert (OK==read(input,total_word_count));
		assert (OK==read(input,the_approximate_database));
		assert (OK==read(input,the_mone_fullword));	
		assert (OK==read(input,the_mone_baseword));
		assert (OK==read(input,the_mone_nituxim));
		assert (OK==read(input,the_mone_yidua));
		assert (OK==read(input,the_realistic_database));
	}

	void atxel_from_input (CStr input_filename) {
		ifstream input;
		open_infile_with_messages (input_filename,input);
		cerr << endl << "counting words in input file " << input_filename << endl;
		the_mone_fullword.count_words_in_file(input);
		open_infile_with_messages (input_filename,input);
		default_heleq_diber=JEM_PRATI;
		DOx(the_approximate_database.analyze_words_in_file (input));
		total_word_count = the_mone_fullword.wordcount();
		the_mone_fullword.remove("*");
		the_approximate_database.remove("*");
		atxel_realistic_database();
	}

	void atxel_from_correct_analysis (CStr input_filename, CStr output_filename) {
		// This method should be called only after :
		//		atxel_from_analysis_with_sikui_logfile
		// or
		//		atxel_from_input (input_filename)
		ifstream correct_analysis, input;
		cerr << "reading correct output file " << output_filename << endl;
		open_infile_with_messages (output_filename,correct_analysis);
		open_infile_with_messages (input_filename,input);
		MorphOptionsWithSikui curoptions;
		StringTemp curword(30);
		MorphInfo curanalysis;
		for(;;) {
			skip_spaces_and_stars(correct_analysis);  
			if (correct_analysis.eof()) break;
			DOEOFx (read(correct_analysis,curanalysis));
			skip_spaces_and_stars(input);			
			DOEOFx (curword.readword(input));
			curoptions = the_approximate_database.item(curword.str);
			if (adken(curword.str,curanalysis) != OK) {
				cerr << "$GIAH BMILH " << curword << ": HNITUX " << curanalysis << " LA NMCA!" << endl;
				lexlogfile << curword << ": " << curanalysis << endl;
			}
		}
		correct_analysis.close();
		input.close();
	}


	void atxel_database (CStr input_filename, CStr analysis_counter_filename, CStr analysis_with_sikui_filename) {
		ifstream input;
		if (analysis_with_sikui_filename!=NULL) 
			atxel_from_analysis_with_sikui_logfile (analysis_with_sikui_filename);
		else 
			atxel_from_input (input_filename);
		if (analysis_counter_filename!=NULL) 
			read_mone_nituxim (analysis_counter_filename);
	}
}; // end of class GlobalDatabase

GlobalDatabase globaldb;	// The global DB holds the data about the whole corpus.


struct LocalDatabase: public GlobalDatabase {
	double mijqal_global;
	LocalDatabase(): GlobalDatabase()
	{ 
			mijqal_identical = 8;
			mijqal_sbwsast = 538./1000.;
			mijqal_sbw = 2041./1000.;
			mijqal_sast = -683./1000.;
			mijqal_yidua = 0./1000.;
			mijqal_global = 1658./1000.;
			xijuv_jaqet = true;
	}

	void get_global_sikuiim(CStr main_word) {
		MorphOptionsWithSikui main_options_s = globaldb.the_approximate_database.item(main_word);
		globaldb.sikuiim_mjuqlalim.truncate(main_options_s.count());
		LOOPVECTOR(;,main_options_s,o) {
			globaldb.sikuiim_mjuqlalim[o] = main_options_s.sikui(o);
		}
	}

	// calculate sikuiim of all the analyses of the main_word, and adken the database
	void xajev_sikuiim (CStr main_word, bool maher) {
		MorphOptionsWithSikui main_options_s = the_approximate_database.item(main_word);
		if (main_options_s.count()<=1)  return;      // no need to calculate probabilities
		if (!xijuv_jaqet_meod) logfile << endl << main_word << (maher? "| ": ": ");

		get_global_sikuiim(main_word);
//		globaldb.sfor_sikuiim (main_word, main_options_s, maher);
//		globaldb.jaqlel_sikuiim (main_options_s);
//		if (!xijuv_jaqet_meod) logfile << "GLOBAL sbwsast " << globaldb.sikuiim_sbwsast << " sast " << globaldb.sikuiim_sast << " sbw " << globaldb.sikuiim_sbw << " identical " << globaldb.sikuiim_identical << " total " << globaldb.sikuiim_mjuqlalim << endl;
		if (!xijuv_jaqet_meod) logfile << "GLOBAL total " << globaldb.sikuiim_mjuqlalim << endl;

		sfor_sikuiim (main_word, main_options_s, maher);
		jaqlel_sikuiim (main_options_s);
		if (!xijuv_jaqet_meod) logfile << "LOCAL sbwsast " << sikuiim_sbwsast << " sast " << sikuiim_sast << " sbw " << sikuiim_sbw << " identical " << sikuiim_identical << " total " << sikuiim_mjuqlalim << endl;
		//float proportion = float(total_word_count) / globaldb.total_word_count;
		//add (sikuiim_mjuqlalim, globaldb.sikuiim_mjuqlalim,1-proportion);
		//main_options_s.add (sikuiim_mjuqlalim,1./(2-proportion));
		add (sikuiim_mjuqlalim, globaldb.sikuiim_mjuqlalim, mijqal_global);
		main_options_s.set (sikuiim_mjuqlalim);
		the_approximate_database.insert (main_word,main_options_s);   // adken the database
		//globaldb.the_approximate_database.insert (main_word,main_options_s);   // adken the database
		if (!xijuv_jaqet_meod) logfile << " " << main_options_s << endl;
	}
};

LocalDatabase localdb;	// The local DB holds the data about the current article only.


void link_local_database_to_global_database() {
	localdb.the_approximate_database = globaldb.the_approximate_database; 
	localdb.the_realistic_database = globaldb.the_realistic_database; 
	localdb.the_mone_fullword = globaldb.the_mone_fullword; 
	localdb.the_mone_baseword = globaldb.the_mone_baseword; 
	localdb.the_mone_nituxim = globaldb.the_mone_nituxim; 
	localdb.the_mone_yidua = globaldb.the_mone_yidua; 
}

/***************************************************************************/
/**********        atxel the databases                              ********/
/***************************************************************************/


void atxel_bw2fw_map_global() {
	for (MorphOptionsWithSikuiTrie::Cursor cursor(globaldb.the_approximate_database);  cursor.isvalid();  ++cursor) {
		CStr cur_fullword = cursor.string().duplicate();
		MorphOptionsWithSikuiCR cur_options = cursor.data();
		LOOPVECTOR (;,cur_options,i) 
			the_bw2fw_map.insert (cur_options.info(i).baseword(), cur_fullword);
	}
}

void atxel_bw2fw_map_local() {
	for (MorphOptionsWithSikuiTrie::Cursor cursor(localdb.the_approximate_database);  cursor.isvalid();  ++cursor) {
		if (globaldb.the_approximate_database.contains(cursor.string().str)) continue;
		CStr cur_fullword = cursor.string().duplicate();
		MorphOptionsWithSikuiCR cur_options = cursor.data();
		LOOPVECTOR (;,cur_options,i) 
			the_bw2fw_map.insert (cur_options.info(i).baseword(), cur_fullword);
	}
}


void atxel_global_database (CStr input_filename, CStr analysis_with_sikui_filename) {
	globaldb.atxel_database(input_filename, NULL, analysis_with_sikui_filename);
	atxel_bw2fw_map_global();
}

void qra_nitux_nakon_global (CStr input_filename, CStr output_filename) {
	globaldb.atxel_from_correct_analysis(input_filename, output_filename);
}

void atxel_local_database (CStr input_filename, CStr analysis_with_sikui_filename) {
	localdb.atxel_database(input_filename, NULL, analysis_with_sikui_filename);
	atxel_bw2fw_map_local();
}

void qra_nitux_nakon_local (CStr input_filename, CStr output_filename) {
	localdb.atxel_from_correct_analysis (input_filename, output_filename);
}



void set_mijqalim_global (double mijqal_identical, double mijqal_sbwsast, double mijqal_sbw, double mijqal_sast, double mijqal_yidua) 
{
	globaldb.mijqal_identical = mijqal_identical;
	globaldb.mijqal_sbwsast = mijqal_sbwsast;
	globaldb.mijqal_sbw = mijqal_sbw;
	globaldb.mijqal_sast = mijqal_sast;
	globaldb.mijqal_yidua = mijqal_yidua;
}

void set_mijqalim_local (double mijqal_identical, double mijqal_sbwsast, double mijqal_sbw, double mijqal_sast, double mijqal_yidua, double mijqal_global) 
{
	localdb.mijqal_identical = mijqal_identical;
	localdb.mijqal_sbwsast = mijqal_sbwsast;
	localdb.mijqal_sbw = mijqal_sbw;
	localdb.mijqal_sast = mijqal_sast;
	localdb.mijqal_yidua = mijqal_yidua;
	localdb.mijqal_global = mijqal_global;
}


/***************************************************************************/
/**********        adken databases                                  ********/
/***************************************************************************/


MorphOptionsWithSikui analysis_with_approximate_sikuiim (CStr hamila) {
	if (!localdb.isempty())
		return localdb.analysis_with_approximate_sikuiim(hamila);
	else
		return globaldb.analysis_with_approximate_sikuiim(hamila);
}

MorphOptionsWithSikui independent_analysis_with_approximate_sikuiim (CStr hamila) {
	if (!localdb.isempty())
		return localdb.independent_analysis_with_approximate_sikuiim(hamila);
	else
		return globaldb.independent_analysis_with_approximate_sikuiim(hamila);
}


status adken_database (CStr hamila, MorphInfoCR hanitux) {
	DOr(globaldb.adken (hamila, hanitux)); 
	return localdb.adken (hamila, hanitux);
}

status adken_database (CStr hamila, MorphOptionsWithSikuiCR kol_hanituxim) {
	DOr(globaldb.adken (hamila,kol_hanituxim));
	return localdb.adken (hamila,kol_hanituxim);
}


status move_one_word_from_approximate_database_to_realistic_database (CStr hamila, MorphOptionsWithSikuiCR the_realistic_options) {
	DOr(globaldb.move_one_word_from_approximate_database_to_realistic_database (hamila, the_realistic_options)); 
	return localdb.move_one_word_from_approximate_database_to_realistic_database (hamila, the_realistic_options);
}

void ktov_global_database (CStr output_filename) { 
	ofstream output;
	open_outfile (output_filename, output, 0);
	globaldb.log_the_database(output); 
	output.close();
}

void ktov_local_database (CStr output_filename) { 
	ofstream output;
	open_outfile (output_filename, output, 0);
	localdb.log_the_database(output); 
	output.close();
}

void xajev_sikuiim_lkol_hamilim_global () { globaldb.xajev_sikuiim_lkol_hamilim(); }
void xajev_sikuiim_lkol_hamilim_local () { localdb.xajev_sikuiim_lkol_hamilim(); }

void xajev_sikuiim_lkol_hamilim_im_sbwsast (MorphInfoCR theinfo) {
	//globaldb.xajev_sikuiim_lkol_hamilim_im_sbwsast(theinfo);
	localdb.xajev_sikuiim_lkol_hamilim_im_sbwsast(theinfo);
}


void xajev_sikuiim_lkol_hamilim_im_sbw (MorphInfoCR theinfo) {
	//globaldb.xajev_sikuiim_lkol_hamilim_im_sbw(theinfo);
	localdb.xajev_sikuiim_lkol_hamilim_im_sbw(theinfo);
}

void xajev_sikuiim (CStr main_word) {
	globaldb.xajev_sikuiim (main_word,false); }

void xajev_sikuiim_maher (CStr main_word) {
	globaldb.xajev_sikuiim (main_word,true);        }


/***************************************************************************/
/**********        TEST ALGHIST                                     ********/
/***************************************************************************/

#ifdef TEST_ALGHIST

#include <cpplib/hcs.hxx>
#include <cpplib/sentence.h>
#include <morph/corpus.h>

#define LOG_PATH "..\\..\\..\\harc\\"

ofstream hcs_logfile;

Corpus the_text;


void atxel_klali_01() {
	initialize_the_analyzer(log_path,log_path);
	atxel_global_database(filename(variable(0),"txt").str, NULL);
	globaldb.xijuv_jaqet = true;
	open_outfile (filename(variable(0),"nt0").str,logfile,0); globaldb.log_the_database(logfile); logfile.close();
	link_local_database_to_global_database();
}

void atxel_klali() {
	atxel_global_database(NULL, filename(variable(0),"nt0").str);
	globaldb.xijuv_jaqet = true;
	link_local_database_to_global_database();
}





class MijqalimSearcher_klali: public HillClimbingSearcher<double> {

	void init_the_parameters() {}

	double score () const {
		globaldb.mijqal_sbwsast=max(par[0],0.); globaldb.mijqal_sbw=max(par[1],0.); globaldb.mijqal_sast=max(par[2],0.); globaldb.mijqal_yidua=max(par[3],0.); 
		globaldb.the_approximate_database.set_sikui_axid();
		open_logfile(2);  globaldb.xajev_sikuiim_lkol_hamilim();  logfile.close();

		the_text.natax_qelet_1();
		the_text.natax_qelet_2();
		return the_text.score();
	}


	void log (double thestep, double thescore) {
		write(hcs_logfile,par);   write(cerr,par);
		LOG(hcs_logfile," " << thestep << ": " << thescore<<endl);  
	}
	
	void finish() {
		open_errorlogfile(log_path);
		score ();
		close_errorlogfile();
		ktov_global_database(filename(variable(0),"nts").str);
	}

public:
	MijqalimSearcher_klali(): HillClimbingSearcher<double>(4) {}

	void run(double step0, double step1,  double m0,double m1,double m2,double m3) {
		par[0]=m0; par[1]=m1; par[2]=m2; par[3]=m3;
		open_outfile (LOG_PATH "loghcs.ma2",hcs_logfile,0);
		the_text.atxel (500);
		the_text.qra_qelet (filename(variable(0),"txt").str);
		the_text.qra_nituxim_nkonim (filename(variable(0),"to").str);
		run_algorithm_a(step0,step1);
		hcs_logfile.close();
	}

};

void test_klali() {
	MijqalimSearcher_klali the_searcher;
	the_searcher.run(0.1,1, 2.071,0, 1.134,0.440);
	//2.0708 0 1.1338 0.440251 0.0107374
}




/*****
		MQOMI
*****/


void atxel_mqomi_01() {
	initialize_the_analyzer(log_path,log_path);
	atxel_global_database (NULL, filename(variable(0),"nt0").str);
	atxel_local_database (filename(variable(1),"txt").str, NULL);
	open_outfile (filename(variable(1),"nt0").str,logfile,0); localdb.log_the_database(logfile); logfile.close();
}

void atxel_mqomi() {
	atxel_global_database (NULL, filename(variable(0),"nt0").str);
	atxel_local_database (NULL, filename(variable(1),"nt0").str);
	localdb.xijuv_jaqet = true;
}




class MijqalimSearcher_mqomi: public HillClimbingSearcher<double> {

	void init_the_parameters() {}

	double score () const {
		double mj=0;
		localdb.mijqal_sbwsast=max(0.,par[0]); localdb.mijqal_sbw=max(0.,par[1]); 
		localdb.mijqal_sast=max(0.,par[2]); localdb.mijqal_yidua=0.; localdb.mijqal_global=max(0.,par[3]);
		localdb.the_approximate_database.set_sikui_axid();
		open_logfile(3); localdb.xajev_sikuiim_lkol_hamilim(); logfile.close();

		the_text.natax_qelet_1(); 
		the_text.natax_qelet_2();
		return the_text.score();
	}


	void log (double thestep, double thescore) {
		write(hcs_logfile,par);
		write(cerr,par);
		LOG(hcs_logfile," " << thestep << ": " << thescore<<endl);  
	}
	
	void finish() {
		open_errorlogfile(log_path);
		score ();
		close_errorlogfile();
	}

public:
	MijqalimSearcher_mqomi(): HillClimbingSearcher<double>(4) {}

	void run(double step0, double step1,  double m0,double m1,double m2,double m3) {
		par[0]=m0; par[1]=m1; par[2]=m2; par[3]=m3;
		open_outfile (LOG_PATH "loghcs.ma2",hcs_logfile,0);
		the_text.atxel (500);
		the_text.qra_qelet (filename(variable(1),"txt").str);
		the_text.qra_nituxim_nkonim (filename(variable(1),"to").str);
		run_algorithm_a(step0,step1);
		hcs_logfile.close();
	}

};


void test_mqomi() {
	MijqalimSearcher_mqomi the_searcher;
	globaldb.xijuv_jaqet=true;
	open_logfile(2); globaldb.xajev_sikuiim_lkol_hamilim(); logfile.close();
	open_logfile(4); globaldb.log_the_database(logfile); logfile.close();
	the_searcher.run(1.,0.9, 0.54,2,0,1.7);
}



void main (int argc, char* argv[]) {
	log_path = LOG_PATH;
	parse_command_line(argc,argv,1,2,"","s");
	if (variable(1)==NULL) {
		if (swtch('s'))  atxel_klali(); else  atxel_klali_01();
		test_klali();
	}
	else {
		if (swtch('s'))  atxel_mqomi(); else  atxel_mqomi_01();
		test_mqomi();
	}
}

#endif

