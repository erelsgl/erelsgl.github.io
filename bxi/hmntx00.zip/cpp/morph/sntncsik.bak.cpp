/* sntncsik.cpp -- 
	Sentence Options with Sikuiim:
		a structure that holds all options to analyze a sentence, with "sikui" attached to 
		each option.
*/

#include <morph/sntncsik.h>
#include <morph/taxbir.h>
#include <cpplib/sentence.h>



/****************  implementation of create_sentence_options_from_eachword_options  ********************/
/****************  implementation of create_sentence_options_from_eachword_options  ********************/
/****************  implementation of create_sentence_options_from_eachword_options  ********************/

/******            struct SentenceOptionIdentifier;                 ******/

struct SentenceOptionIdentifier;
typedef const SentenceOptionIdentifier&  SentenceOptionIdentifierCR;
struct SentenceOptionIdentifier: public Vector1<Index> {
	double my_realsikui;
	ArrayOfMOWS my_eachword_options;
	SentenceOptionIdentifier (): Vector1<Index>() {}
	SentenceOptionIdentifier (const ArrayOfMOWS& eachword_options) {
		my_eachword_options = eachword_options;
		reset (my_eachword_options.count()); 
	}
	void zero() {
		LOOPTHISVECTOR(;,w)  { 
			at(w) = 0;
		}
	}
	void calculate_sikui () {
		LOOPTHISVECTOR(my_realsikui=1.,w)  { 
			my_realsikui *= realsikui(w);
		}
	}
	MorphInfoCR wordinfo (Index the_wordnum) const {	
		return the_wordnum<count()?
			my_eachword_options[the_wordnum].info(at(the_wordnum)):
			miNQUDA;
	}
	double realsikui (Index the_wordnum) const {
		return my_eachword_options[the_wordnum].realsikui(at(the_wordnum)); 
	}
	void create_sentenceinfo_mufrad (SentenceInfo& the_sentenceinfo, double& the_realsikui) const {
		the_sentenceinfo.remove_all();
		LOOPTHISVECTOR(the_realsikui=1.,w)  { 
			the_sentenceinfo.hafred_whosef ( wordinfo(w) ); 
			the_realsikui *= realsikui(w);	
		}
	}
	void create_sentenceinfo_lo_mufrad (SentenceInfo& the_sentenceinfo, double& the_realsikui) const {
		the_sentenceinfo.remove_all();
		LOOPTHISVECTOR(the_realsikui=1.,w)  { 
			the_sentenceinfo.append ( wordinfo(w) ); 
			the_realsikui *= realsikui(w);	
		}
	}
	friend void copy (SentenceOptionIdentifier* to, const SentenceOptionIdentifier* from, uint howmany);
	friend void duplicate (SentenceOptionIdentifier& to, SentenceOptionIdentifierCR from);
};

DEFINE_INLINE_IO_OPERATORS(SentenceOptionIdentifier);

void duplicate (SentenceOptionIdentifier& to, SentenceOptionIdentifierCR from) {
	duplicate (to.myinfo, from.myinfo);
	to.my_eachword_options = from.my_eachword_options;
	to.my_realsikui = from.my_realsikui;
}

void copy (SentenceOptionIdentifier* to, const SentenceOptionIdentifier* from, uint howmany) {
	memcpy(to,from,howmany*sizeof(SentenceOptionIdentifier)); }
//	for (Index i=0; i<howmany; ++i) {
//		duplicate(to[i].myinfo,from[i].myinfo);
//		to[i].my_realsikui = from[i].my_realsikui;
//		to[i].my_eachword_options = from[i].my_eachword_options;
//	}
//}

short compare (SentenceOptionIdentifierCR a, SentenceOptionIdentifierCR b) {
	return compare (a.my_realsikui, b.my_realsikui);    }

bool identical (SentenceOptionIdentifierCR a, SentenceOptionIdentifierCR b) {
	if (a.my_realsikui!=b.my_realsikui)  return false;
	if (a.count()!=b.count())  return false;
	LOOPVECTOR(;,a,w) 
		if (a[w] != b[w]) return false;
	return true;
}




/**********          struct QueueOfSentenceOptionIdentifier              **********/

struct QueueOfSentenceOptionIdentifier: public Array2<SentenceOptionIdentifier> {

	void hosef_et_haba (SentenceOptionIdentifierCR cur_soi, Index w) {
		if (w>=cur_soi.count()) return;
		// w is the "direction".
		if (cur_soi[w]+1 < cur_soi.my_eachword_options[w].count()) {
			SentenceOptionIdentifier new_soi;
			duplicate (new_soi,cur_soi);
			new_soi[w] = cur_soi[w]+1; 
			new_soi.calculate_sikui();
			// ^im ha-cerrup lo^ xuqi -- nasse lhosip ^et ha-ba^im ^axaraw 
			bool 
				cx1 = haceruf_xuqi(new_soi.wordinfo(w-1),new_soi.wordinfo(w)),
				cx2 = haceruf_xuqi(new_soi.wordinfo(w),new_soi.wordinfo(w+1));
			if (cx1 && cx2) {
				if (!contains(*this, new_soi)) {
					DOx(append(new_soi)); }
			}
			else if (!cx1 && cx2) {  
				hosef_et_haba (new_soi,w-1);
				hosef_et_haba (new_soi,w);
			}
			else if (cx1 && !cx2) {  
				hosef_et_haba (new_soi,w);
				hosef_et_haba (new_soi,w+1);
			}
			else if (!cx1 && !cx2) {  
				hosef_et_haba (new_soi,w);
			}
		}
	}
};




/******************  void create_sentence_options_from_eachword_options  ***********************/

status convert_eachword_options_to_sentence_options (
	ArrayOfMOWS the_eachword_options,
	uint TNOSO,     // number of sentence-options
	SentenceOptionsWithSikui& the_sentence_options
) {
	extern ofstream sentencelogfile;
	Vector1<double> the_sentence_options_sikuiim(TNOSO);  // 8 ha-sikuiim ha-@obim bioter &bur ha-mi$pa@ ha-nokxi  
	QueueOfSentenceOptionIdentifier queue_of_options;  queue_of_options.reset(the_eachword_options.count());

	free (the_sentence_options);  the_sentence_options.reset(TNOSO);
	zero (the_sentence_options_sikuiim);

	LOOPVECTOR (;,the_eachword_options,w0) 
		the_eachword_options[w0].sader_lfi_sikui_bseder_yored();
	sentencelogfile<<the_eachword_options<<endl;

	SentenceOptionIdentifier first_soi (the_eachword_options);
	first_soi.zero();      first_soi.calculate_sikui();
	DOr(queue_of_options.append(first_soi));

	SentenceInfo cur_sentence_option_mufrad;

	for (Index i=0;;) {
		sentencelogfile<<i<<endl;
		Index index_of_best_option_in_queue = maxindex (queue_of_options);
		SentenceOptionIdentifier cur_soi = queue_of_options[index_of_best_option_in_queue];
		sentencelogfile<<cur_soi<<endl;
		cur_soi.create_sentenceinfo_mufrad( cur_sentence_option_mufrad, the_sentence_options_sikuiim[i] );
		sentencelogfile<<cur_sentence_option_mufrad<<endl;
		if (hamijpat_xuqi(cur_sentence_option_mufrad)) {
			cur_soi.create_sentenceinfo_lo_mufrad( the_sentence_options.info(i), the_sentence_options_sikuiim[i] );			
			++i;  if (i>=TNOSO) break;                        
		}
		LOOPVECTOR (;,the_eachword_options,w) 
			queue_of_options.hosef_et_haba (cur_soi,w);
		queue_of_options.removeat(index_of_best_option_in_queue);    free(cur_soi);
		if (queue_of_options.isempty()) {
			if (i==0) return ENOTFOUND;        // couldn't create any legal option!
			for (;i<TNOSO;++i)
				the_sentence_options_sikuiim[i] = 0.;
			break;
		}
	}
	normalize (the_sentence_options_sikuiim,1.);
	for (i=0; i<TNOSO; ++i) 
		the_sentence_options.sikui(i) = sikui(the_sentence_options_sikuiim[i]);		
	free (the_sentence_options_sikuiim);
	free (cur_sentence_option_mufrad);
	free (queue_of_options);
	return OK;
}






/******************  SNTNCSIK self-test  ***********************/
/******************  SNTNCSIK self-test  ***********************/
/******************  SNTNCSIK self-test  ***********************/

#ifdef TEST_SNTNCSIK


#include <morph/alghist.h>
#include <morph/mn.h>
#include <morph/tiqun2.h>
#include <morph/hpmaio2.h>



void atxel_klali_s() {
	atxel_global_database (NULL,NULL,"..\\..\\..\\harc\\harc10.nts");
	atxel_local_database (NULL,NULL,"..\\..\\..\\harc\\harc10a.nts");
	atxel_tiqunim("..\\..\\..\\harc"); adken_tiqunim ("..\\..\\..\\harc\\harc10.to2"); 
	ktov_tiqunim("..\\..\\..\\harc");
	adken_monei_zugot_nituxim ("..\\..\\..\\harc\\harc10.to2");
	open_logfile(6); ktov_monei_zugot_nituxim(logfile); logfile.close();
}




void bdoq() {
	Sentence cursentence(500);
	ArrayOfMOWS cursentence_eachword_options;
	SentenceOptionsWithSikui cursentence_options; // 8 ha-^ep$aruiot ha-@obot bioter &bur ha-mi$pa@ ha-nokxi
	for(;;) {
		DOEOFx(read_and_analyze_the_next_sentence (input, cursentence, cursentence_eachword_options));
		taqen_sikuiim_zugot (cursentence_eachword_options);
		convert_eachword_options_to_sentence_options (cursentence_eachword_options, 100, cursentence_options);
		writeln (logfile, cursentence_options);		
		logfile << endl << endl << endl;
	}
}

void main (void) {
	log_path = "..\\..\\..\\harc";
	atxel_klali_s();
	open_logfile(0);
	open_infile ("..\\..\\..\\harc\\harc10a.txt",input);
	bdoq();
}

#endif
