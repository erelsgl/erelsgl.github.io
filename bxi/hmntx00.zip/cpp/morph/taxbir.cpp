/* taxbir.cpp -- 
	yxida $e-tapqidah libdoq ha^im mi$pa@ natun hu^ xuqi mi-bxina taxbirit.
*/

#include <morph/taxbir.h>

bool haceruf_xuqi (MorphInfoBasicCR a, MorphInfoBasicCR b) {
	if (a.smikut()==NISMAK && !b.can_be_somek())  return false;
	//if (a.smikut()==NIFRAD && b.heleqdiber()==ECEM)  return false;
	return true;
}

bool hamijpat_xuqi (SentenceInfoCR the_mijpat) {
	LOOPVECTOR (;,the_mijpat,w) {
		MorphInfoCR curword_info = the_mijpat[w];
		MorphInfoCR nextword_info = w+1<the_mijpat.count()? the_mijpat[w+1]: miNQUDA;
		if (!haceruf_xuqi (curword_info,nextword_info) ) return false;
	}
	return true;
}

