/* morphui.h */

#include <morph/morphinf.h>

HeleqDiber input_hd(CStr prompt);
Zman input_zman(CStr prompt);
Meen input_meen (CStr prompt);
Mispar input_mispar (CStr prompt);
Smikut input_smikut (CStr prompt);
Guf input_guf (CStr prompt);

void input_morphinfo_basic (MorphInfoBasic& theinfo);
