/* cimcumb.cpp -- cimcum-bi@@uyim */

#include <morph/lexiconb.h>
#include <morph/soi.h>
#include <cpplib/stringt.h>


void camcem_bituyim (ArrayOfMOWS& hamijpat) {
	MorphInfo bituy_mcumcam;
	for(Index w=0; w+1<hamijpat.count(); ++w) {
		MorphOptionsWithSikui& mila_x = hamijpat[w];
		MorphOptionsWithSikui& mila_y = hamijpat[w+1];
		LOOPVECTOR(;,mila_x,ox) {  MorphInfo x=mila_x.info(ox);
			LOOPVECTOR(;,mila_y,oy) {  MorphInfo y=mila_y.info(oy);
				if (yej_bituy(x,y,bituy_mcumcam)) {
					mila_x.set_single_option(bituy_mcumcam);
					hamijpat.removeat(w+1);
				}
			}
		}
	}
}

void hagdel_sikui_jel_bituyim (ArrayOfMOWS& hamijpat) {
	for(Index w=0; w+1<hamijpat.count(); ++w) {
		MorphOptionsWithSikui* mila_x = &hamijpat[w];
		MorphOptionsWithSikui* mila_y = &hamijpat[w+1];
		if (mila_y->is_punctuation('-') && w+2<hamijpat.count()) {
			mila_y = &hamijpat[w+2];
			++w;
		}
		LOOPVECTOR(;,(*mila_x),ox) {  MorphInfo x=mila_x->info(ox);
			LOOPVECTOR(;,(*mila_y),oy) {  MorphInfo y=mila_y->info(oy);
				if (yej_bituy(x,y)) {
					mila_x->add_bli_nirmul(ox,SIKUI1);
					mila_y->add_bli_nirmul(oy,SIKUI1);
				}
			}
		}
		mila_x->normalize();
		mila_y->normalize();
	}
}
