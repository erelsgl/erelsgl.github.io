/* tiqun.cpp */

#include <cpplib/stdtempl.h>
#include <cpplib/array2.hxx>
#include <cpplib/stringt.h>
#include <cpplib/cmdline1.h>
#include <cpplib/wordcnt.h>
#include <morph/tiqun.h>
#include <morph/lexiconb.h>
#include <morph/similar.h>


/*****************************************************************/
/*****                   Tiqun___                             ****/
/*****************************************************************/

struct TiqunZug {
	MorphInfoPattern x, y;
	float weight;
	bool match (MorphInfo info_x, MorphInfo info_y) {
		if (!x.match(info_x)) return false;
		if (!y.match(info_y)) return false;
		if (x.yidua_carik_lhatim() && !identical_yidua(info_x.yidua(),info_y.yidua())) return false;
		if (x.meen_carik_lhatim() && !identical_meen(info_x.meen(),info_y.meen())) return false;
		if (x.mispar_carik_lhatim() && !identical_mispar(info_x.mispar(),info_y.mispar())) return false;
		if (x.guf_carik_lhatim() && !identical_guf(info_x.guf(),info_y.guf())) return false;
		return true;
	}
	Sikui weighted_product (Sikui sx, Sikui sy) {
		return product (sx,sy,weight); }
};
typedef const TiqunZug& TiqunZugCR;


void write (ostream& out, TiqunZugCR theinfo, Format format="") {
	write (out,theinfo.x); out << " ";
	write (out,theinfo.y); out << " " << theinfo.weight;
}
status read  (istream& in, TiqunZug& theinfo, Format format="") {
	skip_comments(in,'%');
	DOr (read (in,theinfo.x) );
	DOr (read (in,theinfo.y) );
	return read (in,theinfo.weight);
}

inline void copy (TiqunZug* to, const TiqunZug* from, uint count) { memcpy(to,from,count*sizeof(TiqunZug)); }
inline void duplicate (TiqunZug& to, const TiqunZug& from) { to=from; }
inline void free (TiqunZug& m) { };




/*****************************************************************/
/*****                   taqen_sikuiim                        ****/
/*****************************************************************/

extern ofstream tiqunimlogfile;

Array2 < TiqunZug > tiqunei_zugot;
void taqen_sikuiim_zugot (ArrayOfMOWS& the_sentence_options) {
/*
	mtaqqen ^et ha-sikkuyim $ell millim smukot to^amot, &"p ha-qobc TIQUNIM.MA
*/
	if (the_sentence_options.count()<2) return;
	Index w;
	for (w=0; w<the_sentence_options.count()-1; ++w) {   // xappe$ zug $e-mat^im l-^axat ha-tabniot
		MorphOptionsWithSikui options_x = the_sentence_options[w], options_y = the_sentence_options[w+1];
		ArrayOfSikuiim tosafot_x, tosafot_y;
		init(tosafot_x,options_x.count()); init(tosafot_y,options_y.count());
		if (options_x.count()<=1 && options_y.count()<=1) continue;  // There is no point in adjusting the sikuiim when there is only one option!
		tiqunimlogfile << options_x << " --- " << options_y << endl;

		LOOPVECTOR(;,tiqunei_zugot,t) {		/***** tiqqunei zugot *****/
			TiqunZug& cur_tiqun = tiqunei_zugot[t];
			LOOPVECTOR(;,options_x,ox) if (cur_tiqun.x.match( options_x.info(ox) ) ){
				LOOPVECTOR(;,options_y,oy) if (cur_tiqun.match( options_x.info(ox), options_y.info(oy) ) ){
					Sikui the_tosefet = product (options_x.sikui(ox), options_y.sikui(oy), cur_tiqun.weight ) ;
					tosafot_x[ox] += the_tosefet;
					tosafot_y[oy] += the_tosefet;
				}
			}
		}
		{									/***** tiqqunei bi@@uyim *****/
			LOOPVECTOR(;,options_x,ox) {
				MorphInfo curinfo_x = options_x.info(ox); 
				Bituy thebituy;
				LOOPVECTOR(;,options_y,oy) if (yej_bituy(curinfo_x,options_y.info(oy),thebituy) ){
					Sikui the_tosefet = product (options_x.sikui(ox), options_y.sikui(oy), thebituy.y().baseword_xajuv()? 16: 8) ;
					tosafot_x[ox] += the_tosefet;
					tosafot_y[oy] += the_tosefet;
				}
			}
		}
		{									/***** tiqqunim $liliyim *****/
			MorphInfoPattern MIP_somek_E("=*E**======="), MIP_somek_p("=*p**="), MIP_somek_g("=*g*==="), MIP_somek_T("=*T**===S");
			MorphInfoPattern MIP_PXWT("PXWT=T==L==F"), MIP_IWTR("IWTR=T==L==F");
			#define is_nismak(info) (info.smikut()==NISMAK || (info.heleqdiber()==MILAT_YAXAS&&info.guf_siomet()==NONE) )
			#define isnt_somek_jel_ECEM(info) (!MIP_somek_E.match(info)&&!MIP_somek_p.match(info)&&!MIP_somek_T.match(info))
			#define isnt_somek_jel_MISPAR(info) (!MIP_somek_E.match(info)&&!MIP_somek_g.match(info)&&!MIP_somek_T.match(info))
			#define is_PXWT_o_IWTR(info) (MIP_PXWT.match(info)||MIP_IWTR.match(info))
			#define isnt_m___(info) (info.otiotyaxas()!=OY_MEM)
			#define is_toar_jel_hamila_haqodemet(info) (info.heleqdiber()==TOAR && info.otiotyaxas()==NO_OY && info.smikut()==NIFRAD)
			#define ein_hatama(x,y) (!identical_meen(x.meen(),y.meen()) || !identical_mispar(x.mispar(),y.mispar()) || !identical_yidua(x.yidua(),y.yidua()) )		
			LOOPVECTOR(;,options_x,ox) {
				MorphInfo curinfo_x = options_x.info(ox); 
				LOOPVECTOR(;,options_y,oy) {
					MorphInfo curinfo_y = options_y.info(oy);
					Sikui the_hafxata = product (options_x.sikui(ox), options_y.sikui(oy), -0.5);
					Sikui the_tosefet = 0;
					if (is_nismak(curinfo_x)) {
						if (curinfo_x.heleqdiber()==MISPAR) {
							if (isnt_somek_jel_MISPAR(curinfo_y)) the_tosefet = the_hafxata;
						} else {
							if (isnt_somek_jel_ECEM(curinfo_y)) the_tosefet = the_hafxata;
						}
					}
					if (is_PXWT_o_IWTR(curinfo_x)) {
						if (isnt_m___(curinfo_y))  the_tosefet=the_hafxata;
					}
					if (is_toar_jel_hamila_haqodemet(curinfo_y)) {
						if (curinfo_x.heleqdiber()==ECEM||curinfo_x.heleqdiber()==TOAR) {
							if (ein_hatama(curinfo_x,curinfo_y))  the_tosefet=the_hafxata;
						} else if (curinfo_x.heleqdiber()!=TOAR_POAL) {
							the_tosefet=the_hafxata;
						}
					}
					tosafot_x[ox] += the_tosefet;
					tosafot_y[oy] += the_tosefet;
				}
			}
		}
		options_x.add (tosafot_x);  options_y.add (tosafot_y);
		tiqunimlogfile << tosafot_x << " --- " << tosafot_y << endl;
		tiqunimlogfile << options_x << " --- " << options_y << endl;
	}
}



void taqen_sikuiim_haqbala (ArrayOfMOWS& the_sentence_options) {
/*
	mtaqqen ^et ha-sikkuiim $ell millim $e-nimca^ot b-xca^ei - bi@uyim maqbilim, lma$al, ^im:
		MCD AXD	xxx, ... WMCD $NI yyy, ...
	ha-$igra tagdil ^ett ha-sikkui $e-ha-nittux $ell 'xxx' yihye dome la-nittux $ell 'yyy'.
*/
	if (the_sentence_options.count()<6) return;
	MorphInfoPattern MIP_LA("LA=t="), MIP_RQ("RQ*x*"), MIP_ALA("ALA*x*"), MIP_GM("GM*x*");
	MorphOptionsWithSikui axrei_LA_RQ, axrei_ALA_GM;
	MorphInfoPattern MIP_MCD("CD=E=mLZYF***"), MIP_AXD("AXD*T**LZYF"), MIP_JNI("$NI*T**LZYF");
	MorphOptionsWithSikui axrei_MCD_AXD, axrei_MCD_JNI;
	for (Index w=0; w<the_sentence_options.count()-2; ++w) {   
		MorphOptionsWithSikui &options_x = the_sentence_options[w], &options_y = the_sentence_options[w+1], &options_z=the_sentence_options[w+2];
		if      (options_x.sikui_kolel(MIP_LA)>0 && options_y.sikui_kolel(MIP_RQ)>0) 
			axrei_LA_RQ = options_z;
		else if (!axrei_LA_RQ.isempty() && options_x.sikui_kolel(MIP_ALA)>0 && options_y.sikui_kolel(MIP_GM)>0) {
			axrei_ALA_GM = options_z;
			tiqunimlogfile << "<LA RQ> " << axrei_LA_RQ << " <ALA GM> " << axrei_ALA_GM << endl;
			LOOPVECTOR(;,axrei_LA_RQ,o1) {  
			LOOPVECTOR(;,axrei_ALA_GM,o2) {
				if (dimion(axrei_LA_RQ.info(o1).mila_rijona_info(),axrei_ALA_GM.info(o2).mila_rijona_info())==ZEHUT) {
					Sikui the_tosefet = product (axrei_LA_RQ.sikui(o1), axrei_ALA_GM.sikui(o2), 2) ;
					axrei_LA_RQ.add_bli_nirmul (o1,the_tosefet);
					axrei_ALA_GM.add_bli_nirmul (o2,the_tosefet);
				}
			} }
			axrei_LA_RQ.normalize();  axrei_ALA_GM.normalize();
			tiqunimlogfile << "<LA RQ> " << axrei_LA_RQ << " <ALA GM> " << axrei_ALA_GM << endl;
		}
		else if (options_x.sikui_kolel(MIP_MCD)>0 && options_y.sikui_kolel(MIP_AXD)>0)
			axrei_MCD_AXD = options_z;
		else if (!(axrei_MCD_AXD==0) && options_x.sikui_kolel(MIP_MCD)>0 && options_y.sikui_kolel(MIP_JNI)>0) {
			axrei_MCD_JNI = options_z;
			tiqunimlogfile << "<MCD AXD> " << axrei_MCD_AXD << " <MCD $NI> " << axrei_MCD_JNI << endl;
			LOOPVECTOR(;,axrei_MCD_AXD,o1) {  
			LOOPVECTOR(;,axrei_MCD_JNI,o2) {
				if (dimion(axrei_MCD_AXD.info(o1).mila_rijona_info(),axrei_MCD_JNI.info(o2).mila_rijona_info())==ZEHUT) {
					Sikui the_tosefet = product (axrei_MCD_AXD.sikui(o1), axrei_MCD_JNI.sikui(o2), 2) ;
					axrei_MCD_AXD.add_bli_nirmul (o1,the_tosefet);
					axrei_MCD_JNI.add_bli_nirmul (o2,the_tosefet);
				}
			} }
			axrei_MCD_AXD.normalize();  axrei_MCD_JNI.normalize();
			tiqunimlogfile << "<MCD AXD> " << axrei_MCD_AXD << " <MCD $NI> " << axrei_MCD_JNI << endl;
		}
	}
}


WordCounter mone_jemot_pratiim;
void taqen_sikuiim_jemot_pratiim (ArrayOfMOWS& the_sentence_options) {
/*
	maq@in ^et ha-sikkui $e-$em pra@i yopi&, pa&m ri^$ona b-ma^amar, &im txilliot.
*/
	#define has_txiliot(info) (info.otiotyaxas()!=NO_OY || info.jiabud()!=NO_JIABUD)
	if (the_sentence_options.count()<2) return;
	const Sikui sikui_saf = sikui(0.5);
	for (Index w=0; w<the_sentence_options.count()-1; ++w) {   // &adken ^ett ha-sikkuyim
		MorphOptionsWithSikui options_x = the_sentence_options[w], options_y=the_sentence_options[w+1];
		LOOPVECTOR(;,options_x,ox) {
			Sikui the_tosefet = 0;
			MorphInfo curinfo = options_x.info(ox);
			if ( curinfo.heleqdiber()==JEM_PRATI && has_txiliot(curinfo) ) {
				tiqunimlogfile << "[lipnei tiqun-$em-pra@i] " << options_x << endl;				
				if (mone_jemot_pratiim.count(curinfo.baseword()) < (uint)sikui_saf )  {
					if (!options_y.is_punctuation(',') && !options_y.is_punctuation('"') && !options_y.is_punctuation('(') ) {
						the_tosefet =  - options_x.sikui(ox)/2;
					}
				}
				else {
					the_tosefet =  options_x.sikui(ox)/2;
				}
				options_x.add_bli_nirmul(ox,the_tosefet);
				tiqunimlogfile << "[axrei tiqun-$em-pra@i] " << options_x << endl;				
			}
		}
		options_x.normalize();
		{LOOPVECTOR(;,options_x,ox) {           // &adken ^et ha-monim.
			MorphInfo curinfo = options_x.info(ox);
			if ( curinfo.heleqdiber()==JEM_PRATI )
				mone_jemot_pratiim.insert (curinfo.baseword(),options_x.sikui(ox));
		}}
	}
}


void taqen_meen (ArrayOfMOWS& the_sentence_options) {
/*
	mtaqqen ^ett ha-sikkuyim $ell milla &imm nittuxim $e-nibdalim b-min, 
	lpi ha-min $ell ha-millim ha-qodmot ba-mi$pa@.
*/
	if (the_sentence_options.count()<2) return;
	Sikui sikui_zakar=0, sikui_neqeva=0;
	for (Index w=0; w<the_sentence_options.count(); ++w) {
		MorphOptionsWithSikui options_x = the_sentence_options[w];
		if (options_x.sikui_kolel(MILAT_XIBUR)>0) {
			sikui_zakar=sikui_neqeva=0;
			continue;
		}
		Sikui cur_sikui_zakar = options_x.sikui_kolel_meen(ZAKAR);
		Sikui cur_sikui_neqeva = options_x.sikui_kolel_meen(NEQEVA);
		if (cur_sikui_zakar==0 || cur_sikui_neqeva==0) continue;
		sikui_zakar += cur_sikui_zakar;
		sikui_neqeva += cur_sikui_neqeva;
		tiqunimlogfile << "before ZN: " << options_x << endl;
		ArrayOfSikuiim tosafot_x;	init(tosafot_x,options_x.count()); 
		LOOPVECTOR(;,options_x,ox) { MorphInfo curinfo = options_x.info(ox);
			//Sikui the_tosefet = product (options_x.sikui(ox), options_y.sikui(oy), cur_tiqun.weight ) ;
			if      (curinfo.meen()==ZAKAR) tosafot_x[ox] += product (options_x.sikui(ox), sikui_zakar/(w+1), 1);
			else if (curinfo.meen()==NEQEVA) tosafot_x[ox] += product (options_x.sikui(ox), sikui_neqeva/(w+1), 1);
		}
		options_x.add_only_the_nonzero(tosafot_x);  
		tiqunimlogfile << "after ZN: " << options_x << endl;
	}
}


static WordCounter mone_bituyim;
void taqen_sikuiim_bituyim (ArrayOfMOWS& the_sentence_options) {
	if (the_sentence_options.count()<2) return;
	for (Index w=0; w<the_sentence_options.count()-1; ++w) {   // xappe$ zug $e-mat^im l-^axat ha-tabniot
		MorphOptionsWithSikui options_x = the_sentence_options[w], options_y = the_sentence_options[w+1];
		ArrayOfSikuiim tosafot_x, tosafot_y;
		init(tosafot_x,options_x.count()); init(tosafot_y,options_y.count());
		//if (options_x.count()<=1 && options_y.count()<=1) continue;  // There is no point in adjusting the sikuiim when there is only one option!
		//tiqunimlogfile << options_x << " ::: " << options_y << endl;
		LOOPVECTOR(;,options_x,ox) {
		LOOPVECTOR(;,options_y,oy) {
			StringTemp the_bituy = concat (options_x.info(ox).baseword(), ' ', options_y.info(oy).baseword());
			Sikui the_sikui = product (options_x.sikui(ox), options_y.sikui(oy), 1);
			Sikui the_count = mone_bituyim.count(the_bituy.str);
			if (the_count >= sikui(2) ) {
				tiqunimlogfile << "BI@UI! " << the_bituy << ": " << options_x.info(ox) << " " << options_y.info(oy) << endl;
				tosafot_x[ox] += product (options_x.sikui(ox), the_count, 1) ;
				tosafot_y[oy] += product (options_y.sikui(oy), the_count, 1) ;
			}
			mone_bituyim.insert (the_bituy.str, the_sikui);
		} }
		options_x.add (tosafot_x);  options_y.add (tosafot_y);
		//tiqunimlogfile << tosafot_x << " --- " << tosafot_y << endl;
		//tiqunimlogfile << options_x << " ::: " << options_y << endl;
	}
}	


void taqen_sikuiim (ArrayOfMOWS& the_sentence_options) {
	taqen_sikuiim_zugot (the_sentence_options);
	taqen_sikuiim_haqbala (the_sentence_options);
	taqen_sikuiim_jemot_pratiim (the_sentence_options);
	//taqen_sikuiim_bituyim (the_sentence_options);
	//taqen_meen (the_sentence_options);
}



/*******************************************************************/
/*********                 I/O                        **************/
/*******************************************************************/

void read_the_tiqunim (CStr thepath) {
	ifstream tiqunim_infile;
	StringTemp thefilename = concat_path_to_filename(thepath,"tiqunim.ma");
	cerr << "reading tiqunim file " << thefilename << endl;
	DOx(open(thefilename.str,tiqunim_infile));
	skip_comments(tiqunim_infile,'%');
	DOx(read(tiqunim_infile,tiqunei_zugot,Format("P\n")));
	tiqunim_infile.close();
}

void write_the_tiqunim (CStr thepath) {
	ofstream out;
	StringTemp thefilename = concat_path_to_filename(thepath,"tiqunim.ma");
	DO(open(thefilename.str,out,0));
	out<<endl; writeln(out,tiqunei_zugot,Format("P\n"));
	out.close();
}



