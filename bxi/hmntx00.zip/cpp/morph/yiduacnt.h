/* yiduacnt.h -- yidua counter */
/*
	The structure YiduaCounter holds, for each ECEM in the corpus, two
		numbers: the total sikui that it is meyuda, and the total sikui
		that it is not meyuda.
*/

#ifndef __YIDUACNT_H
#define __YIDUACNT_H

#include <cpplib/pair.hxx>
#include <cpplib/countc.hxx>
#include <cpplib/trie0.hxx>
#include <cpplib/sikui.h>


/*        ***** USAGE EXAMPLE *****
	[not written yet]
*/

struct YiduaCount: public Pair<Sikui> {
	Sikui& count (bool meyuda) {
		return meyuda? x(): y(); }
	
	Sikui count (bool meyuda) const {
		return meyuda? x(): y(); }
	Sikui shifted_count (bool meyuda) const {
		Sikui avg = (x()+y())/2;
		return meyuda? x()-avg: y()-avg; }
	YiduaCount (Sikui m=0, Sikui l=0) { x()=m; y()=l; }
};
/*
	Sikui meyuda;
	Sikui lomeyuda;
	YiduaCount(Sikui m=0, Sikui l=0) { meyuda=m; lomeyuda=l; }
	void operator= (uint ZERO) { meyuda=lomeyuda=0; }
	bool operator== (uint ZERO) { return meyuda==0 && lomeyuda==0; }
};*/
typedef const YiduaCount& YiduaCountCR;



class YiduaCounter: public Trie0<YiduaCount> {
public:
	status add (MorphInfoCR theinfo, Sikui thesikui)   { 
		if (theinfo.heleqdiber()!=ECEM) return OK;
		YiduaCount* curcountp = itemp (theinfo.baseword());
		if (curcountp==NULL)
			DOr( insert (theinfo.baseword(), YiduaCount(1,1), curcountp) );
		curcountp->count (theinfo.meyuda()) += thesikui;
		return OK;
	}
	Sikui count (CStr theword, bool meyuda) const {
		const YiduaCount* curcountp = itemp (theword);
		if (curcountp==NULL) return 0;
		else return curcountp->count(meyuda);
	}
	Sikui count (MorphInfo theinfo) const {
		return count (theinfo.baseword(), theinfo.meyuda()); }

	Sikui shifted_count (CStr theword, bool meyuda) const {
		const YiduaCount* curcountp = itemp (theword);
		if (curcountp==NULL) return 0;
		else return curcountp->shifted_count(meyuda);
	}
	Sikui shifted_count (MorphInfo theinfo) const {
		return shifted_count (theinfo.baseword(), theinfo.meyuda()); }

};
typedef const YiduaCounter& YiduaCounterCR;

void write (ostream& out, YiduaCounterCR theinfo) { 
	write(out, theinfo, Format("T"));				}
status read (istream& in, YiduaCounter& theinfo) { 
	return read(in, theinfo, Format("T")); }

#endif
