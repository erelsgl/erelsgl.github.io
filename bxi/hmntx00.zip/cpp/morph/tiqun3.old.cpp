/* tiqun3.cpp */

#include <cpplib/array2.hxx>
#include <morph/tiqun3.h>
#include <morph/morphsik.h>
#include <morph/hpmaio.h>
#include <morph/mip2.h>

bool equivalent (MorphInfoPatternCR a, MorphInfoPatternCR b) {
	return false;
}

bool ulay_baseword_xajuv (MorphInfoCR a) {
	return  true;
//		(a.heleqdiber()==MILAT_XIBUR) ||
//		(a.heleqdiber()==MILAT_YAXAS) ||
//		(a.heleqdiber()==MILAT_GUF);
}


/*****************************************************************/
/*****                   Tiqun3                               ****/
/*****************************************************************/

struct Tiqun3 {
	MorphInfoPattern x, y, z;
	bool taqen_et_y;           // ha-tiqqun yakol ltaqqen ^et x ^o ^et y.
	Sikui tosefet;
	#define ha_mtaqen (*(taqen_et_y? &x: &y))
	#define ha_mtuqan (*(taqen_et_y? &y: &x))


	bool match (MorphInfoCR the_x, MorphInfoCR the_y, MorphOptionsWithSikuiCR the_options, Index& the_z_index) const {
		static Array2<Index> indexes(20);          // ^indeqsim msuddarim lpi sikkui $ell "the_options".
		if (!x.match(the_x)) return false;
		if (!y.match(the_y)) return false;
		the_options.sader_indexim_lfi_sikui_bseder_yored(indexes);
		if (taqen_et_y) {
			if (z.heleqdiber_xajuv) {   // look for the first option that matches z.
				LOOPVECTOR (;,the_options,o) 
					if (::match(x,z, the_x,the_options.info(indexes[o]))) {
						the_z_index = indexes[o]; return true;
					}
			}
			else {                      // look for the first option that does not match y.
				LOOPVECTOR (;,the_options,o) 
					if (!y.match(the_options.info(indexes[o]))) {
						the_z_index = indexes[o]; return true;
					}
			}
		}
		else {    // taqen et x
			if (z.heleqdiber_xajuv) {   // look for the first option that matches z.
				LOOPVECTOR (;,the_options,o) 
					if (::match(z,y, the_options.info(indexes[o]),the_y)) {
						the_z_index = indexes[o]; return true;
					}
			}
			else {                      // look for the first option that does not match x.
				LOOPVECTOR (;,the_options,o) 
					if (!x.match(the_options.info(indexes[o]))) {
						the_z_index = indexes[o]; return true;
					}
			}
		}
		return false;
	}

	bool match (MorphInfoCR the_x, MorphInfoCR the_y, MorphOptionsWithSikuiCR the_options, MorphInfo& the_z) const {
		Index the_z_index;
		if (!match(the_x,the_y,the_options,the_z_index)) return false;
		the_z = the_options.info(the_z_index);
		return true;
	}

	bool match (MorphInfoCR the_x, MorphInfoCR the_y, MorphOptionsWithSikui& the_options) const {
		Index the_z_index;
		if (!match(the_x,the_y,the_options,the_z_index)) return false;
		the_options.add(the_z_index,tosefet); 
		return true;
	}

	bool meyutar () const {
		return equivalent (ha_mtuqan,z);
	}


	void set_klum_lo_xajuv (MorphInfoCR the_x, MorphInfoCR the_y, MorphInfoCR the_z, bool the_taqen_et_y, Sikui the_tosefet=SIKUI1) {
		x.set(the_x);  x.klum_lo_xajuv();  x.heleqdiber_xajuv=true;  //if (x.heleqdiber()==MILIT) x.baseword_xajuv=true;
		y.set(the_y);  y.klum_lo_xajuv();  y.heleqdiber_xajuv=true;  //if (y.heleqdiber()==MILIT) y.baseword_xajuv=true;
		z.set(the_z);  z.klum_lo_xajuv();  z.heleqdiber_xajuv=true;  //if (z.heleqdiber()==MILIT) z.baseword_xajuv=true;
		taqen_et_y = the_taqen_et_y;
		x.smikut_xajuv=x.guf_siomet_xajuv=true;
		y.vav_xajuv=y.jiabud_xajuv=y.otiotyaxas_xajuv=true;
		if (taqen_et_y)  { z.vav_xajuv=z.jiabud_xajuv=z.otiotyaxas_xajuv=true; }
		else             { z.smikut_xajuv=z.guf_siomet_xajuv=true; }	
		tosefet = the_tosefet;
	}

	void set_xajivut_baseword(bool xajivut_baseword_x, bool xajivut_baseword_y) {
		x.baseword_xajuv = xajivut_baseword_x;
		y.baseword_xajuv = xajivut_baseword_y;
		z.baseword_xajuv = ha_mtuqan.baseword_xajuv;
	}

	void meen_carik_lhatim () {
		ha_mtaqen.meen_carik_lhatim = true;
		z.meen_carik_lhatim = true;
	}

	void mispar_carik_lhatim () {
		ha_mtaqen.mispar_carik_lhatim = true;
		z.mispar_carik_lhatim = true;
	}

	void guf_carik_lhatim () {
		ha_mtaqen.guf_carik_lhatim = true;
		z.guf_carik_lhatim = true;
	}

	void yidua_carik_lhatim () {
		ha_mtaqen.yidua_carik_lhatim = true;
		z.yidua_carik_lhatim = true;
	}

	Tiqun3(): x(), y(), z()  {  }
};
typedef const Tiqun3& Tiqun3CR;


void write (ostream& out, Tiqun3CR theinfo, Format format="B") {
	if (format[0]=='B') {     // write barur
		if (theinfo.taqen_et_y)
			out << theinfo.x << " " << theinfo.y << " => "
				<< theinfo.x << " " << theinfo.z; 
		else
			out << theinfo.x << " " << theinfo.y << " => "
				<< theinfo.z << " " << theinfo.y; 
		out << " " << theinfo.tosefet;
	}
	else 
		out << theinfo.x << " " << theinfo.y << " " 
			<< theinfo.taqen_et_y << " " << theinfo.tosefet << " => " << theinfo.z;
}

status read  (istream& in, Tiqun3& theinfo, Format format="") {
	skip_comments(in,'%');
	DOr (read (in,theinfo.x) );
	DOr (read (in,theinfo.y) );
	int the_taqen_et_y;
	DOr (read (in,the_taqen_et_y));  theinfo.taqen_et_y = (the_taqen_et_y!=0);
	if (testchar(in,'=')!=OK) {
		DOr(read(in,theinfo.tosefet));
		DOr (testchar (in,'='));
	}
	else {
		theinfo.tosefet=SIKUI1;
	}
	DOr (testchar (in,'>'));
	DOr (read (in,theinfo.z) );
	return OK;
}

inline void duplicate (Tiqun3& to, const Tiqun3& from) { to=from; }
inline void free (Tiqun3& m) { };

DEFINE_INLINE_IO_OPERATORS(Tiqun3)






/*****************************************************************/
/*****                   Tiqunim3                             ****/
/*****************************************************************/

class Tiqunim3:  public Array2 <Tiqun3>  {
	MorphInfo basicx; 
	MorphInfo basicy; 
	MorphInfo basicz; 
	HeleqDiber xhd; 
	HeleqDiber yhd; 
	HeleqDiber zhd;

	bool baseword_x_xajuv, baseword_y_xajuv;


	void yacer_tiqunim_0 (Tiqun3 thetiqun) {
		if (thetiqun.meyutar()) return;
		append(thetiqun);
	}

	void yacer_tiqunim__xajivut (Tiqun3 thetiqun) {
		//if (baseword_x_xajuv) {
		//	thetiqun.x.baseword_xajuv=true;
		//	if (thetiqun.taqen_et_x)
		//		thetiqun.z.baseword_xajuv=true;
		//}
		//if (baseword_y_xajuv) {
		//	thetiqun.y.baseword_xajuv=true;
		//	if (thetiqun.taqen_et_y)
		//		thetiqun.z.baseword_xajuv=true;
		//}
		yacer_tiqunim_0 (thetiqun);
	}

	void yacer_tiqunim__hatama_bguf (Tiqun3 thetiqun) {
		yacer_tiqunim__xajivut (thetiqun);
		if (basicz.guf()==NONE) return;
		if ( thetiqun.taqen_et_y? identical_guf(basicx,basicz): identical_guf(basicy,basicz) ) {  // nasse lhosif hat^ama b-guf
			thetiqun.guf_carik_lhatim();
			yacer_tiqunim__xajivut (thetiqun);
		}
	}
	void yacer_tiqunim__hatama_bmispar (Tiqun3 thetiqun) {
		yacer_tiqunim__hatama_bguf (thetiqun);
		if (basicz.mispar()==NONE) return;
		if ( thetiqun.taqen_et_y? identical_mispar(basicx,basicz): identical_mispar(basicy,basicz) ) {  // nasse lhosif hat^ama b-mispar
			thetiqun.mispar_carik_lhatim();
			yacer_tiqunim__hatama_bguf (thetiqun);
		}
	}
	void yacer_tiqunim__hatama_bmeen (Tiqun3 thetiqun) {
		yacer_tiqunim__hatama_bmispar (thetiqun);
		if (basicz.meen()==NONE) return;
		if ( thetiqun.taqen_et_y? identical_meen(basicx,basicz): identical_meen(basicy,basicz) ) {  // nasse lhosif hat^ama b-meen
			thetiqun.meen_carik_lhatim();
			yacer_tiqunim__hatama_bmispar (thetiqun);
		}
	}
	void yacer_tiqunim__hatama_byidua (Tiqun3 thetiqun) {
		yacer_tiqunim__hatama_bmeen (thetiqun);
		if (basicz.yidua()==NONE) return;
		if ( thetiqun.taqen_et_y? identical_yidua(basicx,basicz): identical_yidua(basicy,basicz) ) {  // nasse lhosif hat^ama b-yidua
			thetiqun.yidua_carik_lhatim();
			yacer_tiqunim__hatama_bmeen (thetiqun);
		}
	}

	void yacer_tiqunim_1 (Tiqun3 thetiqun) {
		yacer_tiqunim__hatama_byidua (thetiqun);
		thetiqun.z.heleqdiber_xajuv = false;
		yacer_tiqunim_0(thetiqun);
	}


public:
	void yacer_tiqunim (Tiqun3CR the_basic_tiqun) {
		truncate();
		basicx = the_basic_tiqun.x;
		basicy = the_basic_tiqun.y;
		basicz = the_basic_tiqun.z;
		xhd = the_basic_tiqun.x.heleqdiber();
		yhd = the_basic_tiqun.y.heleqdiber();
		zhd = the_basic_tiqun.z.heleqdiber();
		yacer_tiqunim_1 (the_basic_tiqun);
	}
};


Tiqunim3 tiqunim3;

/*********                 I/O                        **************/
/*********                 I/O                        **************/

void qra_tiqunim (CStr thepath) {
	ifstream tiqunim_infile;
	StringTemp thefilename = concat_path_to_filename(thepath,"tiqunim3.ma");
	cerr << "reading tiqunim file " << thefilename << endl;
	DOx(open(thefilename.str,tiqunim_infile));
	skip_comments(tiqunim_infile,'%');
	DOx(read(tiqunim_infile,tiqunim3,Format("P\n*")));
	tiqunim_infile.close();
}


void ktov_tiqunim (CStr thepath) {
	ofstream out;
	StringTemp thefilename = concat_path_to_filename(thepath,"tiqunim3.ma");
	DO(open(thefilename.str,out,0));
	out<<endl; writeln(out,tiqunim3,Format("P\n"));
	out.close();
}



/*****************************************************************/
/*****                   taqqen nittuxim                      ****/
/*****************************************************************/

extern ofstream tiqunimlogfile;

#include <morph/hpmaio2.h>

void taqen_nituxim_lfi (Tiqun3CR the_tiqun, Index start_from_word_num=0)  {

	if (the_tiqun.taqen_et_y)            // ha-tiqqun mtaqqen et y lfi x
		for (Index w=start_from_word_num; w+1<haqelet.count(); ++w) {
			MorphInfoCR hanitux_jelanu_lx = hanitux_jelanu_laqelet(w);
			MorphInfo&  hanitux_jelanu_ly = hanitux_jelanu_laqelet(w+1);
			MorphOptionsWithSikui& kol_hanituxim_ly = kol_hanituxim_laqelet[w+1];
			Index index_hanitux_hamtuqan_ly;
			if (!the_tiqun.match (hanitux_jelanu_lx, hanitux_jelanu_ly, 
				kol_hanituxim_ly, index_hanitux_hamtuqan_ly )) continue;   // ha-tiqqun lo^ mat^im

			if (kol_hanituxim_ly.sikui(index_hanitux_hamtuqan_ly) + the_tiqun.tosefet
				<= kol_hanituxim_ly.greatest_sikui()) continue;      // ha-tosefet qtana miday
			kol_hanituxim_ly.add (index_hanitux_hamtuqan_ly, the_tiqun.tosefet);
			hanitux_jelanu_ly = kol_hanituxim_ly.info_with_greatest_sikui();
		}
	else                                  // ha-tiqqun mtaqqen et x lfi y
		for (Index w=0; w+1<haqelet.count(); ++w) {
			MorphInfoCR hanitux_jelanu_ly = hanitux_jelanu_laqelet(w+1);
			MorphInfo&  hanitux_jelanu_lx = hanitux_jelanu_laqelet(w);
			MorphOptionsWithSikui& kol_hanituxim_lx = kol_hanituxim_laqelet[w];
			Index index_hanitux_hamtuqan_lx;
			if (!the_tiqun.match (hanitux_jelanu_lx, hanitux_jelanu_ly, 
				kol_hanituxim_lx, index_hanitux_hamtuqan_lx )) continue;   // ha-tiqqun lo^ mat^im

			if (kol_hanituxim_lx.sikui(index_hanitux_hamtuqan_lx) + the_tiqun.tosefet
				<= kol_hanituxim_lx.greatest_sikui()) continue;      // ha-tosefet qtana miday
			kol_hanituxim_lx.add (index_hanitux_hamtuqan_lx, the_tiqun.tosefet);
			hanitux_jelanu_lx = kol_hanituxim_lx.info_with_greatest_sikui();
		}
}

void taqen_nituxim (Index start_from_word_num) {
	LOOPVECTOR (;,tiqunim3,t) 
		taqen_nituxim_lfi (tiqunim3[t],start_from_word_num);
	natax_qelet_2(start_from_word_num);
}
	
void taqen_nituxim_2 () {
	hajwe_nituxim();  errorlogfile << num_of_mistakes << endl << endl;
	LOOPVECTOR (;,tiqunim3,t) {
		errorlogfile << tiqunim3[t] << endl;
		taqen_nituxim_lfi (tiqunim3[t]);
		hajwe_nituxim();  errorlogfile << num_of_mistakes << endl << endl;
	}
}

/********************************************************************************/
/********************           lmad tiqunim         ****************************/
/********************************************************************************/


/*************************** tiqun_score ********************************************/
/*************************** tiqun_score ********************************************/

static int tiqun_score (MorphInfoCR hanitux_haqodem, MorphInfoCR hanitux_hamtuqan, MorphInfoCR hanitux_hanakon) {
	bool haqodem_haya_nakon = identical(hanitux_haqodem,hanitux_hanakon);
	bool hamtuqan_nakon = identical(hanitux_hamtuqan,hanitux_hanakon);
	if (haqodem_haya_nakon && !hamtuqan_nakon)  return -1;      // ha-tiqun qilqel
	if (!haqodem_haya_nakon && hamtuqan_nakon)  return 1;       // ha-tiqun &azar
	return 0;
}

static int tiqun_score (Tiqun3CR the_tiqun) {
	int the_score = 0;
	if (the_tiqun.taqen_et_y)            // ha-tiqqun mtaqqen et y lfi x
		for (Index w=0; w+1<hanitux_hanakon_laqelet.count(); ++w)  {
			MorphInfoCR hanitux_jelanu_lx = hanitux_jelanu_laqelet(w);
			MorphInfoCR hanitux_jelanu_ly = hanitux_jelanu_laqelet(w+1);
			MorphInfoCR hanitux_hanakon_ly = hanitux_hanakon_laqelet[w+1];
			MorphOptionsWithSikuiCR kol_hanituxim_ly = kol_hanituxim_laqelet[w+1];
			Index index_hanitux_hamtuqan_ly;
			if (!the_tiqun.match (hanitux_jelanu_lx, hanitux_jelanu_ly, 
				kol_hanituxim_ly, index_hanitux_hamtuqan_ly )) continue;   // ha-tiqqun lo^ mat^im
			if (kol_hanituxim_ly.sikui(index_hanitux_hamtuqan_ly) + the_tiqun.tosefet
				<= kol_hanituxim_ly.greatest_sikui()) continue;      // ha-tosefet qtana miday
			MorphInfo hanitux_hamtuqan_ly = kol_hanituxim_ly.info(index_hanitux_hamtuqan_ly);
			the_score += tiqun_score (hanitux_jelanu_ly,hanitux_hamtuqan_ly,hanitux_hanakon_ly);
		}
	else                                  // ha-tiqqun mtaqqen et x lfi y
		for (Index w=0; w+1<hanitux_hanakon_laqelet.count(); ++w)  {
			MorphInfoCR hanitux_jelanu_ly = hanitux_jelanu_laqelet(w+1);
			MorphInfoCR hanitux_jelanu_lx = hanitux_jelanu_laqelet(w);
			MorphInfoCR hanitux_hanakon_lx = hanitux_hanakon_laqelet[w];
			MorphOptionsWithSikuiCR kol_hanituxim_lx = kol_hanituxim_laqelet[w];

			Index index_hanitux_hamtuqan_lx;
			if (!the_tiqun.match (hanitux_jelanu_lx, hanitux_jelanu_ly, 
				kol_hanituxim_lx, index_hanitux_hamtuqan_lx )) continue;   // ha-tiqqun lo^ mat^im
			if (kol_hanituxim_lx.sikui(index_hanitux_hamtuqan_lx) + the_tiqun.tosefet
				<= kol_hanituxim_lx.greatest_sikui()) continue;      // ha-tosefet qtana miday
			MorphInfo hanitux_hamtuqan_lx = kol_hanituxim_lx.info(index_hanitux_hamtuqan_lx);
			the_score += tiqun_score (hanitux_jelanu_lx,hanitux_hamtuqan_lx,hanitux_hanakon_lx);
		}
	return the_score;
}



/*************************** yacer_tiqunim ********************************************/
/*************************** yacer_tiqunim ********************************************/


/*************************************  lmad tiqunim ****************************/
/*************************************  lmad tiqunim ****************************/

Tiqun3 the_best_tiqun;
int the_best_tiqun_score;
int the_previous_best_tiqun_score;
bool baseword_x_xajuv, baseword_y_xajuv;

void yacer_wktov_tiqunim (Tiqun3& hatiqun) {
	static Tiqunim3 hatiqunim;
	hatiqun.set_xajivut_baseword(baseword_x_xajuv, baseword_y_xajuv);
	hatiqunim.yacer_tiqunim (hatiqun);
	LOOPVECTOR(;,hatiqunim,t) {
		tiqunimlogfile << hatiqunim[t];
		int ts = tiqun_score(hatiqunim[t]);
		tiqunimlogfile << " " << ts << endl;
		if (ts>the_best_tiqun_score) {
			the_best_tiqun_score = ts;
			the_best_tiqun = hatiqunim[t];
			//if (ts>=the_previous_best_tiqun_score) 
			//	throw "stop searching -- I already found the best tiqun";
		}
	}
}



void lmad_tiqun () {
	LOOPVECTOR(;,hanitux_hanakon_laqelet,w) {
		MorphInfoCR hanitux_jelanu = hanitux_jelanu_laqelet(w);
		MorphInfoCR hanitux_hanakon = hanitux_hanakon_laqelet[w];
		if (identical(hanitux_jelanu,hanitux_hanakon))  continue;
		log_the_mistake(w,haqelet[w],hanitux_jelanu,hanitux_hanakon, tiqunimlogfile);
		MorphOptionsWithSikuiCR kol_hanituxim = kol_hanituxim_laqelet[w];
		Sikui sikui_gavoh_bioter = kol_hanituxim.greatest_sikui();
		Sikui sikui_hanitux_hanakon = kol_hanituxim.sikui(kol_hanituxim.indexof(hanitux_hanakon));
		Sikui hatosefet = sikui_gavoh_bioter - sikui_hanitux_hanakon + 10;
		Tiqun3 hatiqun;            
		if (w>0) {     // nasse lhasiq tiqun lfi hamila haqodemt
			hatiqun.set_klum_lo_xajuv (hanitux_jelanu_laqelet(w-1), hanitux_jelanu, 
				hanitux_hanakon, true, hatosefet);
			yacer_wktov_tiqunim (hatiqun);
		}
		if (w+1<hanitux_hanakon_laqelet.count()) {     // nasse lhasiq tiqun lfi ha-mila haba^a
			hatiqun.set_klum_lo_xajuv (hanitux_jelanu, hanitux_jelanu_laqelet(w+1),
				hanitux_hanakon, false, hatosefet);
			yacer_wktov_tiqunim (hatiqun);
		}
	}
}


void lmad_tiqunim (CStr input_filename, CStr correct_analysis_filename, bool baseword_x_xajuv, bool baseword_y_xajuv) {
	::baseword_x_xajuv = baseword_x_xajuv;
	::baseword_y_xajuv = baseword_y_xajuv;

	the_previous_best_tiqun_score = haqelet.count();
	open_errorlogfile(log_path);  hajwe_nituxim();  errorlogfile.close();
	LOG(tiqunimlogfile,endl << num_of_mistakes << endl);
	for(;;) {
		the_best_tiqun_score = 0;
		try {lmad_tiqun();} catch(CStr) {};
		LOG(tiqunimlogfile,endl<<endl<<endl<<the_best_tiqun << endl);
		if (the_best_tiqun_score < 2) break;
		tiqunim3.append(the_best_tiqun);
		the_previous_best_tiqun_score = the_best_tiqun_score;
		taqen_nituxim_lfi(the_best_tiqun);
		uint previous_num_of_mistakes = num_of_mistakes;
		open_errorlogfile(log_path);  hajwe_nituxim();  errorlogfile.close();
		LOG(tiqunimlogfile,endl << num_of_mistakes << endl);
		if (previous_num_of_mistakes-num_of_mistakes != the_best_tiqun_score) {
			cerr << "MISMATCH! " << previous_num_of_mistakes-num_of_mistakes << " != " << the_best_tiqun_score << endl;
		}
	}
}


void lmad_tiqunim (CStr input_filename, CStr correct_analysis_filename) {
	atxel_maarkei_qelet (2600);
	qra_nituxim_nkonim (correct_analysis_filename);
	qra_qelet (input_filename);
	natax_qelet_1();
	natax_qelet_2();

	lmad_tiqunim(input_filename, correct_analysis_filename,false,false);
	ktov_tiqunim(log_path);
	lmad_tiqunim(input_filename, correct_analysis_filename,false,true);
	ktov_tiqunim(log_path);
	lmad_tiqunim(input_filename, correct_analysis_filename,true,false);
	ktov_tiqunim(log_path);
	lmad_tiqunim(input_filename, correct_analysis_filename,true,true);
	ktov_tiqunim(log_path);
}


#ifdef TEST_TIQUN3
/***************************************************************************/
/**********        TEST TIQUN3                                      ********/
/***************************************************************************/

#include <morph/hpmaio2.h>
#include <morph/alghist.h>
#include <morph/morphanl.h>
#include <cpplib/hcs.hxx>

#define LOG_PATH "..\\..\\..\\harc\\"


/*************************** atxel ********************************************/
/*************************** atxel ********************************************/

void atxel_klali_0 (CStr basicfilename) {
	atxel_global_database (NULL,LOG_PATH "harc20.nts");
	initialize_the_analyzer(log_path,log_path);
	atxel_local_database (filename(basicfilename,"txt").str,NULL);
	open_logfile(3);  xajev_sikuiim_lkol_hamilim_local(); logfile.close();
	ktov_local_database (filename(basicfilename,"nts").str);
}

void atxel_klali(CStr basicfilename) {
	atxel_global_database (NULL, LOG_PATH "harc20.nts");
	atxel_local_database (NULL, filename(basicfilename,"nts").str);
}


void bdoq_tiqunim (CStr input_filename, CStr correct_analysis_filename) {
	uint ms_tauyot;
	atxel_maarkei_qelet (500);
	qra_nituxim_nkonim (correct_analysis_filename);
	qra_qelet (input_filename);
	natax_qelet_1();
	natax_qelet_2();
	taqen_nituxim_2();
	LOG(tiqunimlogfile,endl << num_of_mistakes << endl);
}


void main (int argc, char* argv[]) {
	log_path = "..\\..\\..\\harc";
	parse_command_line(argc,argv,1,1,"","q");
	if (swtch('q')) {
		qra_tiqunim(log_path);
		atxel_klali_0(variable(0));
		open_errorlogfile(log_path);
		bdoq_tiqunim(filename(variable(0),"txt").str, filename(variable(0),"to").str);
		errorlogfile.close();
	}
	else {
		atxel_klali_0(variable(0));
		open_tiqunimlogfile(log_path);
		lmad_tiqunim(filename(variable(0),"txt").str, filename(variable(0),"to").str);
		tiqunimlogfile.close();
	}
}

#endif

