/* mone-nit.h -- mone nittuxim */
/*
*/

#ifndef __MONEHD_H
#define __MONEHD_H

#include <cpplib/countc.hxx>
#include <cpplib/map.hxx>
#include <cpplib/vector1.hxx>
#include <cpplib/sikui.h>


class MoneHD;
typedef const MoneHD& MoneHDCR;

class MoneHD {
	Count mone_ecem;
	Count mone_poal;
	Count mone_toar;
	Count mone_mispar;
	Count mone_jemprati;
	Count mone_milatxibur;
	Count mone_milat;
	Count mone_milatxibur;
	Count mone_milatxibur;
	Count mone_milatxibur;
	MIBCounter& counter (HeleqDiber hd) { return mycounters[hd+8]; }
	const MIBCounter& counter (HeleqDiber hd) const { return mycounters[hd+8]; }
	Count my_skum;
public:
	void zero_all() {
		for (Index i=0; i<16; ++i)  mycounters[i].zero_all(); 
		my_skum = 0;
	}
	status setcount (MorphInfoBasicCR theinfo, Count thecount=0) {
		MIBCounter& thecounter = counter(theinfo.heleqdiber());
		return thecounter.setcount(theinfo,thecount);
	}
	status add (MorphInfoBasicCR theinfo, Sikui thesikui=SIKUI1)   {    
		//MIBCounter& thecounter = counter(theinfo.heleqdiber());
		//DOr(thecounter.add(theinfo,thesikui));
		my_skum += thesikui;
		return true;
	}
	Count count (MorphInfoBasicCR theinfo) const  {
		return counter(theinfo.heleqdiber()).count(theinfo); }
	double relative_count (MorphInfoBasicCR theinfo) const {
		return double(counter(theinfo.heleqdiber()).count(theinfo)) / double(my_skum); }
	friend void write (ostream& out, MoneHDCR theinfo);
	friend status read (istream& in, MoneHD& theinfo);
	friend void duplicate (MoneHD& to, MoneHDCR from);
};

#endif
