/* lexicon2.cpp */

#include <morph/lexicon2.h>
#include <morph/lexinf2.h>
#include <morph/morphopt.h>

bool lexicon_is_creative = false;


/********************************************************************/
/*************     The lexicon structures           ******************/
/********************************************************************/

#include <cpplib/trie0.hxx>

Trie0<LexicalInfo> lexicon_ragil[5];       

Trie0<MorphInfo>	lexicon_milot_yaxas, lexicon_milot_guf, 
					lexicon_misparim, lexicon_pealei_ezer;

Trie0<MorphInfo>	lexicon_acmim_miuxdim, lexicon_pealim_miuxdim_avar, 
					lexicon_pealim_miuxdim_howe, lexicon_pealim_miuxdim_atid, 
					lexicon_tearim_miuxdim;

Trie0<MorphOptions>	lexicon_yocei_dofen;

typedef Pair<MorphInfo> MorphInfoPair;
//Trie0<MorphInfoPair> lexicon_bituiim2;



/********************************************************************/
/*						queries										*/
/********************************************************************/



bool lexicon_contains_word (CStr theword, HeleqDiber thehd, uint* thesug1, uint* thesug2) {
	for (Index i=0; i<5; ++i) {
		LexicalInfo* curinfop = lexicon_ragil[i].itemp(theword);
		if (curinfop==NULL || curinfop->heleqdiber==NO_HD)  return false;                    // item does not exist
		if (curinfop->heleqdiber!=thehd)	continue;	 // item does not exist here, but maybe in the next section	
		if (thesug1!=NULL) *thesug1 = curinfop->sug1;
		if (thesug2!=NULL) *thesug2 = curinfop->sug2;
		return true;                       // item exists.
	}
	return false;
}	


bool lexicon_contains_word (CStr theword, HeleqDiber thehd, Meen* themeen) {
	if (themeen!=NULL) {
		uint thesug2;
		if ( !lexicon_contains_word (theword,thehd,NULL,&thesug2) ) return false;
		*themeen = Meen(thesug2);
		return true;
	}
	else return lexicon_contains_word (theword,thehd,NULL,NULL);
}	


bool lexicon_contains_word_1 (CStr theword, HeleqDiber thehd, uint thesug1, Meen* themeen=NULL) {
	if (thesug1==0) return lexicon_contains_word (theword,thehd,themeen);
	for (Index i=0; i<5; ++i) {
		LexicalInfo* curinfop = lexicon_ragil[i].itemp(theword);
		if (curinfop==NULL || curinfop->heleqdiber==NO_HD)  return false;         // item does not exist
		if (themeen!=NULL) *themeen = Meen(curinfop->sug2);
		if (curinfop->heleqdiber!=thehd)	continue;	 // item does not exist here, but maybe in the next section	
		else if (curinfop->sug1==0 && lexicon_is_creative)		return true;
		else if (curinfop->sug1==thesug1) return true;      // item exists
		else continue;
	}
	return false;
}	

bool lexicon_contains_word_2 (CStr theword, HeleqDiber thehd, uint thesug2, Meen* themeen=NULL) {
	if (thesug2==0) return lexicon_contains_word (theword,thehd,themeen);
	for (Index i=0; i<5; ++i) {
		LexicalInfo* curinfop = lexicon_ragil[i].itemp(theword);
		if (curinfop==NULL || curinfop->heleqdiber==NO_HD)  return false;         // item does not exist
		if (themeen!=NULL) *themeen = Meen(curinfop->sug2);
		if (curinfop->heleqdiber!=thehd)	continue;	 // item does not exist here, but maybe in the next section	
		else if (curinfop->sug2==0 && lexicon_is_creative)		return true;
		else if (curinfop->sug2==thesug2) return true;      // item exists
		else continue;
	}
	return false;
}	


bool lexicon_contains_word (CStr theword, LexicalInfo theinfo, Meen* themeen) {
	if (theinfo.sug2==0) return lexicon_contains_word_1 (theword,theinfo.heleqdiber,theinfo.sug1,themeen);
	else if (theinfo.sug1==0) return lexicon_contains_word_2 (theword,theinfo.heleqdiber,theinfo.sug2,themeen);
	else return false;
}	


bool lexicon_contains_poal (CStr theword, uint* thesug1, uint* thesug2) 
	{ return lexicon_contains_word (theword, POAL, thesug1, thesug2); }
bool lexicon_contains_poal_1 (CStr theword, uint thesug1) 
	{ return lexicon_contains_word_1 (theword, POAL,thesug1); }
bool lexicon_contains_poal_2 (CStr theword, uint thesug2) 
	{ return lexicon_contains_word_2 (theword, POAL,thesug2); }

bool lexicon_contains_ecem (CStr theword, uint thesug1, Meen* themeen)
	{ return lexicon_contains_word_1 (theword, ECEM,thesug1, themeen); }

bool lexicon_contains_ecem (CStr theword, uint* thesug1, Meen* themeen) {
	if (themeen!=NULL) {
		uint thesug2;
		if ( !lexicon_contains_word (theword,ECEM,thesug1,&thesug2) ) return false;
		*themeen = Meen(thesug2);
		return true;
	}
	else return lexicon_contains_word (theword,ECEM,thesug1,NULL);
}	

bool lexicon_contains_jem_prati (CStr theword, Meen* themeen) 
	{ return lexicon_contains_word (theword, JEM_PRATI, themeen); }

bool lexicon_contains_toar (CStr theword, uint thesug1)
	{ return lexicon_contains_word_1 (theword, TOAR,thesug1 ); }


bool lexicon_contains_milat_yaxas (CStr theword, MorphInfoR theinfo) {
	return lexicon_milot_yaxas.contains(theword,theinfo); }

bool lexicon_contains_milat_guf (CStr theword, MorphInfoR theinfo) {
	return lexicon_milot_guf.contains(theword,theinfo); }

bool lexicon_contains_mispar (CStr theword, MorphInfoR theinfo) {
	return lexicon_misparim.contains(theword,theinfo); }

bool lexicon_contains_poal_ezer (CStr theword, MorphInfoR theinfo) {
	return lexicon_pealei_ezer.contains(theword,theinfo); }

bool lexicon_contains_poal_miuxd (CStr theword, Zman thezman, MorphInfoR theinfo) {
	return	thezman==AVAR? lexicon_pealim_miuxdim_avar.contains(theword,theinfo): 
			(thezman==HOWE||thezman==HOWE_SAVIL)? lexicon_pealim_miuxdim_howe.contains(theword,theinfo): 
			(thezman==ATID||thezman==CIWUI||thezman==MAQOR)? lexicon_pealim_miuxdim_atid.contains(theword,theinfo):
			false;
}

bool lexicon_contains_toar_miuxd (CStr theword, MorphInfoR theinfo) {
	return	lexicon_tearim_miuxdim.contains(theword,theinfo); }

bool lexicon_contains_ecem_miuxd (CStr theword, MorphInfoR theinfo) {
	return	lexicon_acmim_miuxdim.contains(theword,theinfo); }


bool lexicon_contains_bitui2 (CStr thebitui, MorphInfo& theinfo1, MorphInfo& theinfo2) { return true;
/*	MorphInfoPair* p = lexicon_bituiim2.itemp(theword);
	if (p==NULL) return false;
	if (p->isempty()) return false;
	theoptions.share(*p);*/
}


bool lexicon_contains_yoce_dofen (CStr theword, MorphOptions& theoptions) {
	MorphOptions* p = lexicon_yocei_dofen.itemp(theword);
	if (p==NULL) return false;
	if (p->isempty()) return false;
	theoptions.share(*p);
	return true;
}




/********************************************************************/
/*						EDITING										*/
/********************************************************************/


status add_word_to_lexicon (CStr theword, HeleqDiber thehd) {
	for (Index i=0; i<5; ++i) {
		LexicalInfo* curinfop = lexicon_ragil[i].itemp(theword);
		if (curinfop==NULL)  return lexicon_ragil[i].insert (theword,LexicalInfo(thehd));      // item does not exist
		else if (curinfop->heleqdiber==NO_HD)   { curinfop->heleqdiber=thehd; return OK; }      // item exists but needs update
		else if (curinfop->heleqdiber!=thehd)	continue;	 // item does not exist here, but maybe in the next section	
		else  return OK;                       // item already exists and needs no update
	}
	return OK;
}

status add_word_to_lexicon_1 (CStr theword, HeleqDiber thehd, uint thesug1) {
	if (thesug1==0)  return add_word_to_lexicon (theword,thehd);
	for (Index i=0; i<5; ++i) {
		LexicalInfo* curinfop = lexicon_ragil[i].itemp(theword);
		if (curinfop==NULL)  return lexicon_ragil[i].insert (theword,LexicalInfo(thehd,thesug1,0));      // item does not exist
		else if (curinfop->heleqdiber==NO_HD)   { curinfop->heleqdiber=thehd; curinfop->sug1=thesug1; return OK; }      // item exists but needs update
		else if (curinfop->heleqdiber!=thehd)	continue;	 // item does not exist here, but maybe in the next section	
		else if (curinfop->sug1==0)  { curinfop->sug1=thesug1; return OK; }
		else if (curinfop->sug1!=thesug1) continue;      // item exists
		else  return OK;                       // item already exists and needs no update
	}
	return OK;
}

status add_word_to_lexicon_2 (CStr theword, HeleqDiber thehd, uint thesug2) {
	if (thesug2==0)  return add_word_to_lexicon (theword,thehd);
	for (Index i=0; i<5; ++i) {
		LexicalInfo* curinfop = lexicon_ragil[i].itemp(theword);
		if (curinfop==NULL)  return lexicon_ragil[i].insert (theword,LexicalInfo(thehd,0,thesug2));      // item does not exist
		else if (curinfop->heleqdiber==NO_HD)   { curinfop->heleqdiber=thehd; curinfop->sug2=thesug2; return OK; }      // item exists but needs update
		else if (curinfop->heleqdiber!=thehd)	continue;	 // item does not exist here, but maybe in the next section	
		else if (curinfop->sug2==0)  { curinfop->sug2=thesug2; return OK; }
		else if (curinfop->sug2!=thesug2) continue;      // item exists
		else  return OK;                       // item already exists and needs no update
	}
	return OK;
}

status add_word_to_lexicon_1_2 (CStr theword, HeleqDiber thehd, uint thesug1, uint thesug2) {
	if (thesug1==0)  return add_word_to_lexicon_2 (theword,thehd,thesug2);
	if (thesug2==0)  return add_word_to_lexicon_1 (theword,thehd,thesug1);
	for (Index i=0; i<5; ++i) {
		LexicalInfo* curinfop = lexicon_ragil[i].itemp(theword);
		if (curinfop==NULL)  return lexicon_ragil[i].insert (theword,LexicalInfo(thehd,thesug1,thesug2));      // item does not exist
		else if (curinfop->heleqdiber==NO_HD)   { curinfop->heleqdiber=thehd; curinfop->sug1=thesug1; curinfop->sug2=thesug2; return OK; }      // item exists but needs update
		else if (curinfop->heleqdiber!=thehd)	continue;	 // item does not exist here, but maybe in the next section	
		else {
			if (curinfop->sug1==0)  { curinfop->sug1=thesug1; }
			if (curinfop->sug1!=thesug1) continue;      // item exists
			if (curinfop->sug2==0)  { curinfop->sug2=thesug2;  }
			if (curinfop->sug2!=thesug2) continue;      // item exists
			return OK;
		}
	}
	return OK;
}


status add_word_to_lexicon (CStr theword, LexicalInfo theinfo) {
	return add_word_to_lexicon_1_2 (theword,theinfo.heleqdiber,theinfo.sug1,theinfo.sug2);
}

status add_ecem_to_lexicon (CStr theword, uint sug, Meen meen) 
	{ return add_word_to_lexicon_1_2 (theword,ECEM,sug,meen); }

status add_toar_to_lexicon (CStr theword, uint sug) 
	{ return add_word_to_lexicon_1 (theword,TOAR,sug); }

status add_poal_to_lexicon (CStr theword) 
	{ return add_word_to_lexicon (theword,POAL); }
status add_poal_1_to_lexicon (CStr theword, uint sug) 
	{ return add_word_to_lexicon_1 (theword,POAL,sug); }
status add_poal_2_to_lexicon (CStr theword, uint sug2) 
	{ return add_word_to_lexicon_2 (theword,POAL,sug2); }

status add_jem_prati_to_lexicon (CStr theword, Meen themeen) 
	{ return add_word_to_lexicon_2 (theword,JEM_PRATI,themeen); }

status add_milit_to_lexicon (CStr theword, MorphInfoCR theinfo) {
	return	theinfo.heleqdiber()==MILAT_YAXAS?	lexicon_milot_yaxas.insert(theword,theinfo):
			theinfo.heleqdiber()==MILAT_GUF?	lexicon_milot_guf.insert(theword,theinfo):
			theinfo.heleqdiber()==MISPAR?		lexicon_misparim.insert(theword,theinfo):
			theinfo.heleqdiber()==POAL_EZER?	lexicon_pealei_ezer.insert(theword,theinfo):
			OK;
}

status add_miuxd_to_lexicon (CStr theword, MorphInfoCR theinfo) {
	HeleqDiber thehd = theinfo.heleqdiber();
	if (thehd==ECEM) return lexicon_acmim_miuxdim.insert(theword,theinfo);
	else if (thehd==TOAR) return lexicon_tearim_miuxdim.insert(theword,theinfo);
	else {
		Zman thezman = theinfo.zman();
		return	thezman==AVAR? lexicon_pealim_miuxdim_avar.insert(theword,theinfo): 
				(thezman==HOWE||thezman==HOWE_SAVIL)? lexicon_pealim_miuxdim_howe.insert(theword,theinfo): 
				(thezman==ATID||thezman==CIWUI||thezman==MAQOR)? lexicon_pealim_miuxdim_atid.insert(theword,theinfo):
				OK;
	}
}

status add_yoce_dofen (CStr theword, MorphOptions theoptions) 
{
	return lexicon_yocei_dofen.insert(theword,theoptions);
}



/********************************************************************/
/*						yocei-dofen									*/
/********************************************************************/

Trie0<bool> acamim_im_ntiat_jayakut_miuxedet;

bool has_ntiat_jayakut_miuxedet (CStr the_ecem) {
	return acamim_im_ntiat_jayakut_miuxedet.item(the_ecem);
}


void init_the_acamim_im_ntiat_jayakut_miuexedet () {
	for (Trie0<MorphInfo>::Cursor c(lexicon_acmim_miuxdim); c.isvalid(); ++c) {
		MorphInfoCR theinfo = c.data();
		if ( theinfo.mispar()==YAXID )
			acamim_im_ntiat_jayakut_miuxedet.insert (theinfo.baseword(),true);
	}
	acamim_im_ntiat_jayakut_miuxedet.insert ("$NIM",true);  // miqre miuxad.
}



/********************************************************************/
/*						IO  										*/
/********************************************************************/


void   write_lexicon_klali (ostream& out, Format format) {
	if (format[0]=='T') {         // table format
		out << '{' << endl;
		for (Index i=0; i<5; ++i) {
			write (out,lexicon_ragil[i],Format("t "));
		}
		out << '}' << endl;
	}
	else  if (format[0]=='D')  // dense format
		for (Index i=0; i<5; ++i) {
			writeln (out,lexicon_ragil[i],Format("D"));
		}
}


status read_lexicon_klali (istream& in, Format format) {
	if (format[0]=='T') {    // table format
		StringTemp curword (30);
		DOr(testchar(in,'{'));
		for (Index i=0;;++i) {
			LexicalInfo curdata;        
			if (testchar(in,'}')==OK) { return OK; }
			in.ipfx();
			DOr (curword.readline(in," ")); 
			DOr ( read (in, curdata ) );
			DOr (add_word_to_lexicon (curword.str,curdata));
		}
		DOr(testchar(in,'}'));
		return OK;
	}
	else { // if (format[0]=='D')  // dense format
		for (Index i=0; i<5; ++i) {
			DOr(read (in,lexicon_ragil[i],Format("D")));
			skip(in,"\n\t ");
		}
		return OK;
	}
}


void   write_the_lexicon (CStr thepath, Format format) {
	ofstream out;

	StringTemp thefilename = concat_path_to_filename(thepath,"lex00.ma");
	cerr << "writing lexicon file " << thefilename << endl;
	DOx(open(thefilename.str,out,0));
	out<<"\n%\n%\n% LEXICON RAGIL\n%\n%\n";
	write_lexicon_klali (out,Format("T "));

	thefilename = concat_path_to_filename(thepath,"lex10.ma");
	cerr << "writing lexicon file " << thefilename << endl;
	DOx(open(thefilename.str,out,0));
	out<<"\n%\n%\n% LEXICON MILOT YAXAS\n%\n%\n";
	writeln (out,lexicon_milot_yaxas,Format("T:L "));
	out<<"\n%\n%\n% LEXICON MILOT GUF\n%\n%\n";
	writeln (out,lexicon_milot_guf,Format("T:L "));
	out<<"\n%\n%\n% LEXICON MISPARIM\n%\n%\n";
	writeln (out,lexicon_misparim,Format("T:L "));
	out<<"\n%\n%\n% LEXICON P&ALEI-&EZER\n%\n%\n";
	writeln (out,lexicon_pealei_ezer,Format("T:L "));

	thefilename = concat_path_to_filename(thepath,"lexmi.ma");
	cerr << "writing lexicon file " << thefilename << endl;
	DOx(open(thefilename.str,out,0));
	out<<"\n%\n%\n% LEXICON &ACAMIM MIUXADIM\n%\n%\n";
	writeln (out,lexicon_acmim_miuxdim,Format("T:L "));
	out<<"\n%\n%\n% LEXICON P&ALIM MIUXADIM -- AVAR\n%\n%\n";
	writeln (out,lexicon_pealim_miuxdim_avar,Format("T:L "));
	out<<"\n%\n%\n% LEXICON P&ALIM MIUXADIM -- HOWE/HOWE-SAVIL\n%\n%\n";
	writeln (out,lexicon_pealim_miuxdim_howe,Format("T:L "));
	out<<"\n%\n%\n% LEXICON P&ALIM MIUXADIM -- ATID/CIWUI/MAQOR\n%\n%\n";
	writeln (out,lexicon_pealim_miuxdim_atid,Format("T:L "));
	out<<"\n%\n%\n% LEXICON T^ARIM MIUXADIM\n%\n%\n";
	writeln (out,lexicon_tearim_miuxdim,Format("T:L "));

	thefilename = concat_path_to_filename(thepath,"lexyd.ma");
	cerr << "writing lexicon file " << thefilename << endl;
	DOx(open(thefilename.str,out,0));
	out<<"\n%\n%\n% LEXICON YOC^EI DOFEN\n%\n%\n";
	write (out,lexicon_yocei_dofen,Format("T:L "));

/*
	thefilename = concat_path_to_filename(thepath,"lexjp.ma");
	DO(open(thefilename.str,out));
	write (out,lexicon_jemot_pratiim,Format("T "));
*/
	out.close();
}




void read_the_lexicon (CStr thepath, Format format) {
	ifstream in;

	StringTemp thefilename = concat_path_to_filename(thepath, "lex00.ma");
	cerr << "reading lexicon file " << thefilename << endl;
	DOx(open(thefilename.str,in));
	skip_comments(in,'%');
	DOx(read_lexicon_klali (in,format));

	thefilename = concat_path_to_filename(thepath,"lex10.ma");  
	cerr << "reading lexicon file " << thefilename << endl;
	DOx(open(thefilename.str,in));
	skip_comments(in,'%');
	DOx(read(in,lexicon_milot_yaxas,Format("T:L ")));
	skip_comments(in,'%');
	DOx(read(in,lexicon_milot_guf,Format("T:L ")));
	skip_comments(in,'%');
	DOx(read(in,lexicon_misparim,Format("T:L ")));
	skip_comments(in,'%');
	DOx(read(in,lexicon_pealei_ezer,Format("T:L ")));

	thefilename = concat_path_to_filename(thepath,"lexmi.ma");  
	cerr << "reading lexicon file " << thefilename << endl;
	DOx(open(thefilename.str,in));
	skip_comments(in,'%');
	DOx(read(in,lexicon_acmim_miuxdim,Format("T:L ")));
	skip_comments(in,'%');
	DOx(read(in,lexicon_pealim_miuxdim_avar,Format("T:L ")));
	skip_comments(in,'%');
	DOx(read(in,lexicon_pealim_miuxdim_howe,Format("T:L ")));
	skip_comments(in,'%');
	DOx(read(in,lexicon_pealim_miuxdim_atid,Format("T:L ")));
	skip_comments(in,'%');
	DOx(read(in,lexicon_tearim_miuxdim,Format("T:L ")));

	thefilename = concat_path_to_filename(thepath,"lexyd.ma");  
	cerr << "reading lexicon file " << thefilename << endl;
	DOx(open(thefilename.str,in));
	skip_comments(in,'%');
	DOx(read(in,lexicon_yocei_dofen,Format("T:L ")));

	init_the_acamim_im_ntiat_jayakut_miuexedet ();
	in.close();
}





#ifdef TEST_LEXICON2

short lexpart[5];
void init_lexpart () {	for(Index i=0; i<5; ++i) lexpart[i]=false;  }
void update_lexpart (LexicalInfo theinfo) {
	switch (theinfo.heleqdiber) {
		case ECEM: ++lexpart[0]; break;
		case POAL: ++lexpart[1]; break;
		case TOAR: ++lexpart[2]; break;
		case JEM_PRATI: ++lexpart[3]; break;
		default: ++lexpart[4]; break;
	}
}
short exists_lexpart (LexicalInfo theinfo) {
	switch (theinfo.heleqdiber) {
		case ECEM: return lexpart[0];
		case POAL: return lexpart[1];
		case TOAR: return lexpart[2];
		case JEM_PRATI: return lexpart[3];
		default: return lexpart[4];
	}
}



void main (void) {
	read_the_lexicon ("c:\\harc");
	for (Trie0<LexicalInfo>::Cursor c(lexicon_ragil[1]);  c.isvalid();  ++c) {
		CStr theword = c.string().str;
		init_lexpart();
		for (Index i=0; i<5; ++i) {
			LexicalInfo* theinfop = lexicon_ragil[i].itemp(theword);  if (theinfop==NULL) break;
//			if (exists_lexpart(*theinfop)>=1 && theinfop->heleqdiber!=ECEM && theinfop->heleqdiber!=POAL) {  // found 2 lexical values of the same baseword and heleqdiber
			if (exists_lexpart(*theinfop)>=2) {  // found 3 lexical values of the same baseword and heleqdiber
				cout << theword << ": ";
				for (Index j=0; j<5; ++j) 
					if (lexicon_ragil[j].contains(theword))
						cout << lexicon_ragil[j].item(theword) << ' ';
				cout << endl;
				break;
			}
			update_lexpart (*theinfop);
		}
	}
}

#endif
