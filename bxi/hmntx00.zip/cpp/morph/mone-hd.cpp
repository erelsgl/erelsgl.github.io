/* mone-nit.cpp -- mone nittuxim */

#include <morph/mone-nit.h>


void write (ostream& out, MoneNituximCR theinfo) { 
	out << "{" << theinfo.my_skum << endl;
	for (Index i=0; i<16; ++i)
		write(out, theinfo.mycounters[i], Format("t:")); 
	out << "}" << endl;
}

status read (istream& in, MoneNituxim& theinfo) {
	DOr(testchar(in,'{'));
	DOr(read(in,theinfo.my_skum));
	char the_stopper='}', the_keydata_separator=':', the_line_separator='\0';
	Format keyformat="", dataformat="";
	if (testchar(in,the_stopper)==OK) return OK; 
	for (Index i=0;;++i) {
		KeyData <MorphInfoBasic,Count> theinput;
		DOr ( read_keydata (in, theinput, the_keydata_separator, keyformat, dataformat ) );
		DOr ( theinfo.setcount ( theinput.key(), theinput.data() ) );
		if (testchar(in,the_stopper)==OK) return OK; 
		DOr ( testchar(in,the_line_separator) );
	}
	return OK;
}

void duplicate (MoneNituxim& to, MoneNituximCR from) {
	for (Index i=0; i<16; ++i)
		duplicate (to.mycounters[i], from.mycounters[i]);
}

