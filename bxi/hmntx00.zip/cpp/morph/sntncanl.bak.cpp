/* sntncanl.cpp -- mnattex taxbiri l-&ibrit 
		mi$tamme$ b-^algoritm BFS
*/

#include <morph/sntncanl.h>
#include <morph/mip.h>
#include <morph/cimcumim.h>
#include <cpplib/vector1.hxx>
#include <cpplib/BFS.hxx>


struct JlavCimcum: public Vector1<XoqCimcum> {};
typedef const JlavCimcum& JlavCimcumCR;


status read  (istream& in, JlavCimcum& theinfo, Format format="") {
	skip_comments(in,'%');
	return read (in, (Vector1<XoqCimcum>&)theinfo, Format("P\n"));
}


Vector1<JlavCimcum> jlav_cimcum;



bool haceruf_savir (MorphInfoBasicCR a, MorphInfoBasicCR b) {
	if (a.smikut()==NISMAK) {
		if (!b.can_be_somek())  return false; 
	}
	if (a.heleqdiber()==MILAT_YAXAS && !a.has_siomet()) {
		if (!b.can_be_somek())  return false; 
	}
	if (b.heleqdiber()==TOAR && a.heleqdiber()!=MILIT) {
		if (a.heleqdiber()!=ECEM || !matimim(a,b)) return false;
	}
	return true;
}



/********************************************************************************/
/*************       Sentence Analyzer               ****************************/
/********************************************************************************/


short qdimut (uint sug1, uint sug2) { 
	uint s1=sug1/10, s2=sug2/10;
	if (s1==5 && s2==2) return 1;
	else if (s1==2 && s2==5) return -1;
	else if (s1==4 && s2==5) return 0;
	else if (s1==5 && s2==4) return 0;
	else return compare(s2,s1);
}

extern ofstream sentencelogfile;

struct SentenceAnalyzer: public BreadthFirstSearcher<SentenceInfo> {

	SentenceInfo the_original_sentence;
	SentenceOptions* the_final_options_p;
	#define the_final_options (*the_final_options_p)

	//status append (SentenceInfoCR the_option) { return the_final_options.append(the_option); }

	SentenceAnalyzer (SentenceInfoCR the_sentence, SentenceOptions& the_options) {
		the_sentence.hafred_txiliot (the_original_sentence);
		the_final_options_p = &the_options;
	}

	status enqueue_first_nodes() {
		return enqueue(the_original_sentence);
	}

	



	/*-----------------------------------------------------------------*/
	/*------------------     natax -- the main routine  ---------------*/
	/*-----------------------------------------------------------------*/

	bool yej_cimcum_qodem (SentenceInfo& the_sentence, Index w, JlavCimcumCR the_jlav, uint the_sug) {
		LOOPVECTOR(;,the_jlav,xc) {  XoqCimcumCR the_xoq = the_jlav[xc];
			if ( qdimut(the_sug,the_xoq.sug)<0 )
				if (the_xoq.match(the_sentence,w+1)) return true; 
		}
		return false;
	}

	bool yej_cimcum_qodem_2 (SentenceInfo& the_sentence, Index w, JlavCimcumCR the_jlav, uint the_sug) {
		LOOPVECTOR(;,the_jlav,xc) {  XoqCimcumCR the_xoq = the_jlav[xc];
			if ( qdimut(the_sug,the_xoq.sug)<0 ) 
				if (the_xoq.match(the_sentence,w+1) || the_xoq.match(the_sentence,w+2) || the_xoq.match(the_sentence,w+3)) return true; 
		}
		return false;
	}

	bool yej_cimcum_dome (SentenceInfo& the_sentence, Index w, JlavCimcumCR the_jlav, uint the_sug) {
		LOOPVECTOR(;,the_jlav,xc) {  XoqCimcumCR the_xoq = the_jlav[xc];
			if ( qdimut(the_sug,the_xoq.sug)==0 )
				if (the_xoq.match(the_sentence,w+1)) return true; 
		}
		return false;
	}

	bool yej_cimcum_dome_2 (SentenceInfo& the_sentence, Index w, JlavCimcumCR the_jlav, uint the_sug) {
		LOOPVECTOR(;,the_jlav,xc) {  XoqCimcumCR the_xoq = the_jlav[xc];
			if ( qdimut(the_sug,the_xoq.sug)==0 ) 
				if (the_xoq.match(the_sentence,w+1) || the_xoq.match(the_sentence,w+2)|| the_xoq.match(the_sentence,w+3)) return true; 
		}
		return false;
	}
/*
	void camcem_lfi_lo_hores (SentenceInfo& the_sentence, JlavCimcumCR the_jlav) {
		restart:
		for (Index w=0; w<the_sentence.count()-1; ++w) {
			LOOPVECTOR(;,the_jlav,xc) {  XoqCimcumCR the_xoq = the_jlav[xc];
				MorphInfo the_new_info;
				if (!the_xoq.match(the_sentence,w, the_new_info)) continue;
				if (!haceruf_savir(the_sentence.wordinfo(w-1), the_new_info) || !haceruf_savir(the_new_info,the_sentence.wordinfo(w+the_xoq.ork()))) continue;
				DOx(the_sentence.replace(w,w+2, the_new_info));
				sentencelogfile << "           " << the_sentence << endl;
				goto restart;
			}
		}
	}
*/
	void camcem_lfi (SentenceInfo& the_sentence, JlavCimcumCR the_jlav, bool& yej_cimcum) {
		restart:
		yej_cimcum = false;
		for (Index w=0; w<the_sentence.count()-1; ++w) {
			LOOPVECTOR(;,the_jlav,xc) {  XoqCimcumCR the_xoq = the_jlav[xc];
				if (the_xoq.is_mdume()) continue;
				MorphInfo the_new_info;
				if (!the_xoq.match(the_sentence,w, the_new_info)) continue;
				if (!haceruf_savir(the_sentence.wordinfo(w-1), the_new_info) || !haceruf_savir(the_new_info,the_sentence.wordinfo(w+the_xoq.ork()))) continue;
				if (the_xoq.sug<10) {
					DOx(the_sentence.replace(w,w+the_xoq.ork(), the_new_info));
					sentencelogfile << "      " << the_sentence << endl;
					goto restart;
				}
				else if (yej_cimcum_qodem(the_sentence,w, the_jlav,the_xoq.sug)) {
					continue;
				}
				else if (yej_cimcum_dome(the_sentence,w, the_jlav,the_xoq.sug)) {  // ha-xoqq &alul lahros
					sentencelogfile << endl;
					SentenceInfo the_new_sentence;   duplicate(the_new_sentence, the_sentence);
					DOx(the_new_sentence.replace(w,w+the_xoq.ork(), the_new_info));
					yej_cimcum = true;
					DOx (enqueue(the_new_sentence));
				}
				else {                                                              // ha-xoqq lo^ hores  
					DOx(the_sentence.replace(w,w+the_xoq.ork(), the_new_info));
					sentencelogfile << "      " << the_sentence << endl;
					goto restart;
				}
			}
		}
	}
/*
	void camcem_lfi (SentenceInfo& the_sentence, JlavCimcum4CR the_jlav, bool& yej_cimcum) {
		for (Index w=0; w<the_sentence.count()-3; ++w) {
			LOOPVECTOR(;,the_jlav,xc) {    XoqCimcum4CR the_xoq = the_jlav[xc];
				MorphInfo the_new_info;
				if (!the_xoq.match(the_sentence,w, the_new_info)) continue;
				SentenceInfo the_new_sentence;   duplicate(the_new_sentence, the_sentence);
				DOx(the_new_sentence.replace(w,w+4, the_new_info));
				yej_cimcum = true;
				DOx (enqueue (the_new_sentence));
			}
		}
	}
*/
	status enqueue_next_nodes(SentenceInfoCR curoption) {
		sentencelogfile << " ***  " << curoption << endl;
		SentenceInfo curoption_mcumcam;  duplicate(curoption_mcumcam, curoption);
		//{LOOPVECTOR (;,jlav_cimcum_lo_hores,i) {
		//	camcem_lfi_lo_hores (curoption_mcumcam, jlav_cimcum_lo_hores[i]);}
		//}
		bool yej_cimcum=false;
		{LOOPVECTOR (;,jlav_cimcum,i) {
			camcem_lfi (curoption_mcumcam, jlav_cimcum[i], yej_cimcum);
			if (yej_cimcum) return OK;
		}}
		if (!contains(the_final_options,curoption_mcumcam))
			DOr(the_final_options.append (curoption_mcumcam));
		sentencelogfile << "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%" << endl << endl;
		return OK;
	}


};



/*******************************************************************/
/*********  public routines						      **************/
/*******************************************************************/

bool the_sentence_analyzer_is_initialized = false;

status read_the_cimcumim (CStr path_to_cimcumim) {
	ifstream cimcumim_infile;
	StringTemp thefilename = concat_path_to_filename(path_to_cimcumim,"cimcumim.ma");
	cerr << "reading cimcumim file " << thefilename << endl;
	DOr(open(thefilename.str,cimcumim_infile));
	skip_comments(cimcumim_infile,'%');
	DOr(read(cimcumim_infile, jlav_cimcum, Format("P\n")));
	cimcumim_infile.close();
	return OK;
}

void initialize_the_sentence_analyzer (CStr path_to_cimcumim) {
	DOx ( read_the_cimcumim(path_to_cimcumim) );
	the_sentence_analyzer_is_initialized = true;
}

double ciyun (SentenceInfoCR the_partially_analyzed_sentence) {
	LOOPVECTOR (double acc=1,the_partially_analyzed_sentence,w) {
		MorphInfoCR curword = the_partially_analyzed_sentence[w];
		if (curword.heleqdiber()!=POAL && curword.heleqdiber()!=MILAT_XIBUR)
			acc *= 0.5;
		else if ( lapoal_yej_nose(curword) )
			acc *= 1;
		else 
			acc *= 0.9;
	}
	return acc;
}

double ciyun_gavoh_bioter (SentenceOptionsCR the_options) {
	LOOPVECTOR (double cur=0, the_options, o)
		if (ciyun(the_options[o]) > cur)
			cur = ciyun(the_options[o]);
	return cur;
}

void mxaq_et_hanituxim_hapaxot_tovim (SentenceOptions& the_options, double the_ciyun_saf) {
	LOOPVECTOR(;, the_options, o) {
		while (ciyun(the_options[o]) < the_ciyun_saf  &&  o<the_options.count()) {
			the_options.removeat(o);    
		}
	}
}


void natax (SentenceInfoCR thesentence, SentenceOptions& theoptions) {
	assert (the_sentence_analyzer_is_initialized);
	SentenceAnalyzer myanalyzer (thesentence, theoptions);
	DOx(myanalyzer.run());
}

double ciyun_hanitux_hataxbiri_hatov_bioter (SentenceInfoCR the_sentence) {
	SentenceOptions the_options;
	natax (the_sentence,the_options);
	writeln (sentencelogfile,the_options,Format("*\n"));  sentencelogfile<<endl;
	double CGB = ciyun_gavoh_bioter(the_options);
	free (the_options);
	return CGB;
}


/*******************************************************************************************************/
/****************  SELF TEST          ******************************************************************/
/*******************************************************************************************************/


#ifdef TEST_SNTNCANL

#include <morph/hpmaio2.h>
#include <morph/alghist.h>
#include <morph/tiqun2.h>
#include <morph/mn.h>
#include <cpplib/sentence.h>

void atxel_klali() {
	atxel_global_database (NULL,NULL,"..\\..\\..\\harc\\harc10.nts");
	atxel_local_database (NULL,NULL,"..\\..\\..\\harc\\harc10a.nts");
	atxel_tiqunim ("..\\..\\..\\harc");
	adken_tiqunim ("..\\..\\..\\harc\\harc10.to2");
	ktov_tiqunim ("..\\..\\..\\harc");
	adken_monei_zugot_nituxim ("..\\..\\..\\harc\\harc10.to2");
	open_logfile(6); ktov_monei_zugot_nituxim(logfile); logfile.close();
}


void bdoq() {
	for(;;) {
		Sentence the_sentence(500);
		SentenceInfo the_sentence_info;
		SentenceOptions the_sentence_options;
		DOEOFx(the_sentence.readline(input));
		DOEOFx(the_sentence_info.read(correct_analysis));
		natax (the_sentence_info, the_sentence_options);
		mxaq_et_hanituxim_hapaxot_tovim (the_sentence_options, ciyun_gavoh_bioter(the_sentence_options) );
		LOG (logfile,the_sentence_info<<endl<<endl<<the_sentence<<endl);
		writeln (logfile,the_sentence_options, Format("*\n"));
		writeln (cout,the_sentence_options, Format("*\n"));
		logfile << endl << endl << endl;
	}
}




void main (int argc, char* argv[]) {
	set_synopsis ("SNTNCANL source.TXT source.TO [/t path-to-cimcumim]");
	parse_command_line (argc,argv,2,2,"t","");
	CStr path_to_cimcumim = log_path = option('t')==NULL? ".": option('t');
	atxel_klali();
	initialize_the_sentence_analyzer (path_to_cimcumim);
	open_logfile(0);
	open_sentencelogfile(log_path);
	open_infile_with_messages (concat_path_to_filename(log_path,variable(0)).str,input);
	open_infile_with_messages (concat_path_to_filename(log_path,variable(1)).str,correct_analysis);
	bdoq();
}

#endif
