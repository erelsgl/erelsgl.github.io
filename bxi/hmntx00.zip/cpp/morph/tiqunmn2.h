/* mn.h -- monei-nittuxim-axrei (w-gamm lipnei) */

#ifndef __TIQUNMN2_H
#define __TIQUNMN2_H

#include <morph/morphinf.h>

void atxel_monei_nituxim (CStr correct_analysis_filename);
void adken_monei_nituxim (CStr correct_analysis_filename);
void ktov_monei_nituxim (ostream& out);
status qra_monei_nituxim(istream& in);
void qra_monei_nituxim (CStr path);

double relative_count_lipnei (MorphInfoCR qodem, MorphInfoCR nokxi);
double relative_count_axrei (MorphInfoCR qodem, MorphInfoCR nokxi);

#endif

