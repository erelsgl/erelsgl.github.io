/* tiqun.h -- tiqqun ha-sikkuyim lfi ha-heq$er */

#ifndef __TIQUN_H
#define __TIQUN_H

#include <morph/mip.h>
#include <morph/morphsik.h>

typedef Vector1<MorphOptionsWithSikui> SentenceOptionsVector;
typedef const SentenceOptionsVector& SentenceOptionsVectorCR;

void taqen_sikuiim (SentenceOptionsVector& the_sentence_options);


void read_the_tiqunim (CStr thepath);
void write_the_tiqunim (CStr thepath);
void open_tiqunimlogfile (CStr log_path);
void close_tiqunimlogfile ();




#endif
