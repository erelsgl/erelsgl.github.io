/* convanl2.cpp  --  converts analysis from Uzi's format to my format */

#include <morph/morphopt.h>
#include <cpplib/stringp.h>
#include <cpplib/stringt.h>
#include <morph/convlang.h>
#include <cpplib/convert1.h>
#include <cpplib/cmdline1.h>

/* 
	The format of morph output:
	[fullword]  pos  baseword  ,smikut,txiliot,siomot  ,zman,guf,meen,,mispar    guf_s,meen_s,,mispar_s  particles
*/


StringTemp parse_engword (StringParseR theline) {
	FINDinSTRING(theline,!isspace(c));
	StringTemp theword(theline.len-theline.index+1);
	PARSE(theline,isspace(c),theword);
	//heb2eng(theword);
	return theword;
}

HeleqDiber parse_hd (StringParseR theline) {
	FINDinSTRING(theline,!isspace(c));
	uchar c1=theline.get();
	switch(c1) {
		case '$': case 'G': return ECEM; // G is for $em-pe&ula.
		case 'P': case 'M': case 'S': return POAL; // M is for poal with kinui-musa. S is for dmui-po&al.
		case 'T': return TOAR;
		case 'Y': case 'E': return MILAT_YAXAS;  // E is for "$el".
		case 'K': return MILAT_GUF;
		case 'Q': return MILAT_JEELA;
		case 'X': case 'V': case 'N': return MILAT_XIBUR;  // V is for milat-$i&bud, such as "kdey". N is for milat-ziqa.
		case 'D': return TOAR_POAL;
		default:  return NO_HD;
	}
}

Smikut parse_smikut(StringParseR theline) {
	FINDinSTRING(theline,c==',');  theline.next();
	uchar c1=theline.cur();  theline.next(2);
	switch(c1) {
		case 'a': return NIFRAD;
		case 'c': return NISMAK;
		case 'i': return BOTH;
		default: return NONE;
	}
}

Zman parse_zman(StringParseR theline) {
	FINDinSTRING(theline,c==',');  theline.next();  FINDinSTRING(theline,c==',');  theline.next();
	uchar c1=theline.cur();    theline.next(2);
	switch(c1) {
		case 'p': return AVAR;
		case 'r': return HOWE;
		case 'f': return ATID;
		case 'i': return CIWUI;
		case 'n': return MAQOR;
		default:  return NO_ZMAN;
	}
}


Guf parse_guf(StringParseR theline) {
	uchar c1=theline.cur();    theline.next(2);
	switch(c1) {
		case '1': return GUF1;
		case '2': return GUF1;
		case '3': return GUF1;
		default:  return NONE;
	}
}		

Meen parse_meen(StringParseR theline) {
	uchar c1=theline.cur(), c2=theline.cur(2);   theline.next(4);
	if (c1=='+' && c2=='#')  return ZAKAR;
	else if (c1=='#' && c2=='+')  return NEQEVA;
	else if (c1=='+' && c2=='+')  return BOTH;
	else return NONE;
}

Mispar parse_mispar(StringParseR theline) {
	uchar c1=theline.cur();    theline.next(2);
	switch (c1) {
		case 's':  return YAXID;
		case 'p':  return RABIM;
		default:   return NONE;
	}
}

bool get_morphinfo_from_nattax_output (StringTempR therawline, StringTemp& thefullword, StringTemp& thebaseword_fonemic, MorphInfo& theinfo) {
	StringTemp thebaseword_eng(30);
	StringParse theline(therawline.str);
	if (theline[0]!=' ') {
		thefullword = parse_engword(theline);  if (theline.end()) return false;
	}
	else {
		thefullword.len=0;
	}
	theinfo.setheleqdiber (parse_hd(theline));  if (theline.end()) return false;

	thebaseword_fonemic = parse_engword(theline);   if (theline.end()) return false;
	fonemic2eng(thebaseword_fonemic,thebaseword_eng);   
	theinfo.setbaseword   (thebaseword_eng.str); 

	theinfo.setsmikut (parse_smikut(theline));   if (theline.end()) return false;
	theinfo.setzman (parse_zman(theline));   if (theline.end()) return false;
	theinfo.setguf (parse_guf(theline));   if (theline.end()) return false;
	theinfo.setmeen (parse_meen(theline));   if (theline.end()) return false;
	theinfo.setmispar (parse_mispar(theline));   if (theline.end()) return false;

	FINDinSTRING(theline,!isspace(c));   if (theline.end()) return false;
	theinfo.setguf_siomet (parse_guf(theline));   if (theline.end()) return false;
	theinfo.setmeen_siomet (parse_meen(theline));   if (theline.end()) return false;
	theinfo.setmispar_siomet (parse_mispar(theline));   if (theline.end()) return false;

	return true;
}

/***********************************************************************************/
/***********     The converter                  ************************************/
/***********************************************************************************/

struct AnalysisConverter: public Converter {
	MorphOptions cur_options;
	StringTemp cur_fullword;

	AnalysisConverter(): Converter(), cur_fullword(50) {}

	void start (ostream&) { cur_fullword.truncate(); }

	status convert_line(ostream& target) {
		if (cur_fullword=="" && myline[0]==' ') return OK;  // skip unimportant lines
		MorphInfo theinfo;
		StringTemp thefullword, thebaseword_fonemic;
		if ( get_morphinfo_from_nattax_output(myline,thefullword,thebaseword_fonemic,theinfo) ) {
			if (thefullword.isempty()) {        // the previous fullword remains
				cur_options.append(theinfo);
				return STAY_IN_THE_SAME_LINE;
			}
			else {                              // a new fullword
				if (cur_fullword.len>0)  target << cur_fullword << ": ";
				write(target,cur_options,Format(" "));
				cur_fullword = thefullword;
				cur_options.truncate();
				cur_options.append(theinfo);
				return OK;
			}
		}
		else return STAY_IN_THE_SAME_LINE;
	}		

	void finish(ostream& target) { 
		target << cur_fullword << ": ";
		writeln(target,cur_options,Format(" "));
	}
};



void main (int argc, char* argv[]) {
	set_synopsis ("CONVANL2 source{Hebrew,Uzi's} target{compact,English}");
	ofstream out; ifstream in;
	parse_command_line (argc,argv,0,2,"","");
	if (variable(0)!=NULL) { open_infile(variable(0),in);  cin=in; }
	if (variable(1)!=NULL) { open_outfile(variable(1),out,0);  cout=out; }
	//open_infile(variable(0),global_source);  open_outfile(variable(1),global_target,0);
	AnalysisConverter theconverter;
	theconverter.convert(cin,cout);
}
