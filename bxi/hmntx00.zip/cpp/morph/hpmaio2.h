/* hpmaio.h -- IO routines for HPMA */

#ifndef __HPMAIO2_H
#define __HPMAIO2_H

#include <morph/hpmaio.h>
#include <morph/soi.h>
#include <cpplib/sentence.h>

void atxel_maarkei_qelet (Size ms_milim_baqelet);
void qra_nituxim_nkonim (CStr correct_analysis_filename);
void qra_qelet (CStr input_filename);
status qra_qelet (istream& input, uint article_limit);  // read at most "article_limit" articles
void natax_qelet_1(Index start_from_word_num=0);
void natax_qelet_2(Index start_from_word_num=0);
void natax_qelet_1(CStr hamila);
void qra_pelet_xelqi (CStr partial_output_filename);

void qra_mijpat_mehamaarak (Index w, ArrayOfMOWS& kol_hanituxim_lamijpat, SentenceInfo& hanitux_hanakon_lamijpat);
void qra_mijpat_mehamaarak (Index w, ArrayOfMOWS& kol_hanituxim_lamijpat, Array2<CStr>& hamijpat);
void ktov_mijpat_lamaarak (Index w, ArrayOfMOWSCR kol_hanituxim_lamijpat);
void ktov_mijpat_lamaarak (Index w, SentenceInfoCR hanitux_jelanu_lamijpat);

double score (ArrayOfMOWSCR kol_hanituxim_lamijpat, SentenceInfo hanitux_hanakon_lamijpat, Index& w);


extern uint 
	num_of_words,
	num_of_mistakes, 
	num_of_mlbdtxiliot_mistakes, 
	num_of_baseword_mistakes;
void hajwe_nituxim (MorphInfoCR hanitux_jelanu, MorphInfoCR hanitux_hanakon, CStr hamila);
void hajwe_nituxim (SentenceInfoCR hanitux_jelanu_lamijpat, SentenceInfoCR hanitux_hanakon_lamijpat, SentenceCR hamijpat);
void hajwe_mijpat_lamaarak (Index w, SentenceInfoCR hanitux_jelanu_lamijpat);
void hajwe_nituxim ();
void hajwe_nituxim (Array2<Index>& indexei_tauyot);
double score ();

extern Array2<char*> haqelet;
extern Vector1<MorphOptionsWithSikui> kol_hanituxim_laqelet;
extern Vector1<MorphInfo> hanitux_jelanu_laqelet;
extern Array2<MorphInfo> hanitux_hanakon_laqelet;

inline Index index_hanitux_jelanu_laqelet(Index w) { return kol_hanituxim_laqelet[w].indexof(hanitux_jelanu_laqelet[w]); }
inline Size godel_haqelet() { return min (hanitux_hanakon_laqelet.count(), hanitux_jelanu_laqelet.count(), haqelet.count()); }


#endif
