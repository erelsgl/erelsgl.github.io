/* hpma-aux.cpp -- auxiliary routines for HPMA */


#include <morph/hpma-aux.h>
#include <morph/hpmaio.h>

