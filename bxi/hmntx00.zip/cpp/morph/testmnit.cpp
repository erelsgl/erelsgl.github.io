/* testmnit.cpp -- test mone nituxim */

#include <morph/mone-nit.h>

void main (void) {
	MorphInfoBasic mibe(ECEM);
	MorphInfoBasic mibp(POAL);
	MoneNituxim thecounter; writeln (cout,thecounter);
	EXEC(thecounter.setcount(mibe,1000));    writeln (cout,thecounter);
	EXEC(thecounter.setcount(mibp,1000));    writeln (cout,thecounter);
	EXEC(thecounter.add(mibe));    writeln (cout,thecounter);
	EXEC(thecounter.add(mibp));    writeln (cout,thecounter);
	EXEC(thecounter.add(mibp));    writeln (cout,thecounter);
	EXEC(thecounter.add(mibe));    writeln (cout,thecounter);
	EXEC(thecounter.setcount(mibe,500));    writeln (cout,thecounter);
}
