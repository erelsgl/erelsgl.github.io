/* morphui.cpp */

#include <iomanip.h>
#include <ios.h>
#include <morph/morphui.h>
#include <cpplib/ui.h>

HeleqDiber input_hd(CStr prompt) {
	for (int i=-8, j=0; i<=7; ++i) {
		HeleqDiber hd = HeleqDiber(i);
		if (hd2char(hd) == '*') continue;
		cout << setiosflags(ios::right) << setw(2) << (i+8) << ". " 
			 << setiosflags(ios::left) << setw(15) << hd2str(hd);
		++j;
		if (j%4==0)  cout<<endl;
	}
	cout << endl;
	return HeleqDiber ( -8 + input_int (prompt,0,15) );
}


Meen input_meen (CStr prompt) { 
	return char2meen ( prompt_from (prompt,"ZNB*") ); }

Mispar input_mispar (CStr prompt) { 
	return char2mispar ( prompt_from (prompt,"YRB*") ); }

Smikut input_smikut (CStr prompt) { 
	return char2smikut ( prompt_from (prompt,"FSB*") ); }

Guf input_guf (CStr prompt) { 
	return char2guf ( prompt_from (prompt,"123A*") ); }

Zman input_zman (CStr prompt) { 
	return char2zman ( prompt_from (prompt,"VHTCMS*") ); }



void input_morphinfo_basic (MorphInfoBasic& theinfo) {
	theinfo.setheleqdiber ( input_hd("XLQ DIBR") );
	switch (theinfo.heleqdiber()) {
		case ECEM: case MISPAR: 
			theinfo.setecem ( input_meen("  MIN"), input_mispar("  MSPR"), input_smikut("  SMIKWT") );   cout<<endl;
			theinfo.setsiomet ( input_meen("  MIN-SIWMT"), input_mispar("  MSPR-SIWMT"), input_guf("  GWP-SIWMT") );   
			break;
		case TOAR:
			theinfo.setecem ( input_meen("  MIN"), input_mispar("  MSPR"), input_smikut("  SMIKWT") );   cout<<endl;
			break;
		case POAL: case POAL_EZER:
			theinfo.setpoal ( input_meen("  MIN"), input_mispar("  MSPR"), input_guf("  GWP"), input_zman("  ZMN")  );
			break;
		case JEM_PRATI:
			theinfo.setmeen (input_meen("  MIN"));
			break;
		case MILAT_GUF:
			theinfo.setpoal ( input_meen("  MIN"), input_mispar("  MSPR"), input_guf("  GWP"), NO_ZMAN );
			break;
		case MILAT_YAXAS:
			theinfo.setsiomet ( input_meen("  MIN-SIWMT"), input_mispar("  MSPR-SIWMT"), input_guf("  GWP-SIWMT") );
			break;
		default: ;
	}
	cout<<endl;
}


#ifdef TEST_MORPHUI

void main(void) {
}

#endif

