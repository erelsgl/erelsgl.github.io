/* lexinf2.cpp */

#include <morph/lexinf2.h>


/***************************************************************************************/
/*      IO for LexicalInfo													           */
/***************************************************************************************/

void write (ostream& out, LexicalInfoCR theinfo, Format format) {
	HeleqDiber hd = theinfo.heleqdiber; 
	out << hd2char(hd);
	if (hd==ECEM||hd==POAL||hd==TOAR) {
		out<<theinfo.sug1;
	}
	if (hd==POAL||hd==ECEM) {
		out<<":";
	}
	if (hd==JEM_PRATI||hd==ECEM) {
		out<<meen2char(theinfo.sug2>64? (theinfo.sug2-128): theinfo.sug2);
	}
	if (hd==POAL) {
		out<<theinfo.sug2;
	}
}

status read (istream& in, LexicalInfo& theinfo, Format format) {
	skip (in," \t\n");
	HeleqDiber hd = char2hd(in.get());
	theinfo.heleqdiber = hd;
	if (hd==ECEM||hd==POAL||hd==TOAR)  {
		short thesug1; 	DOr(read(in,thesug1));  theinfo.sug1=thesug1;
	}
	if (hd==POAL||hd==ECEM) {
		DOr(testchar(in,':'));
	}
	if (hd==POAL) {
		short thesug2; 	DOr(read(in,thesug2));  theinfo.sug2=thesug2;
	}
	if (hd==ECEM||hd==JEM_PRATI) {
		Meen themeen = char2meen(in.get());  theinfo.sug2=themeen;
	}
	return OK;
}

