/* tstanlcnt.cpp -- test analysis counter */

#include <morph/anlcnt.h>

void main (void) {
	MorphInfoBasic mibe(ECEM);
	MorphInfoBasic mibp(POAL);
	AnalysisCounter thecounter; writeln (cout,thecounter);
	thecounter.insert(mibe);    writeln (cout,thecounter);
	thecounter.insert(mibp);    writeln (cout,thecounter);
	thecounter.insert(mibp);    writeln (cout,thecounter);
	thecounter.insert(mibe);    writeln (cout,thecounter);
}