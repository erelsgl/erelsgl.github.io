/* tiqun2.cpp */

#include <cpplib/array2.hxx>
#include <morph/tiqun2.h>
#include <morph/cimcumim.h>
#include <morph/mn.h>
#include <morph/hpmaio.h>
#include <morph/mip2.h>


/*****************************************************************/
/*****                   Tiqun___                             ****/
/*****************************************************************/

struct TiqunZug {
	Index ms_cimcum;
	MorphInfoPattern x, y;
	static SentenceInfo temp_sentence;
	bool match (MorphInfoCR the_x, MorphInfoCR the_y) const {
		if (!::match(x,y,the_x,the_y)) return false;
		temp_sentence[0]=the_x;  temp_sentence[1]=the_y;
		return hacimcumim[ms_cimcum].match(temp_sentence,0); 
	}
	
	uint			// these counts are used to calculate the 'weight' of the Tiqun:
		xcount,			// this is the number of words in the corpus that match the pattern 'x'.
		ycount,			// this is the number of words in the corpus that match the pattern 'y'.		
		xycount;		// this is the number of pairs in the corpus that match the pattern 'x y'.
	void zero_counts () { xcount=ycount=xycount=0; }
	void add_to_counts (MorphInfo info_x, MorphInfo info_y) {
		if (x.match(info_x))  ++xcount;
		if (y.match(info_y))  ++ycount;
	}
	void add_to_counts (SentenceInfoCR the_sentence, Index the_x_index) {
		if (hacimcumim[ms_cimcum].match(the_sentence,the_x_index)) {
			++xycount; 
			++xcount;   ++ycount; 
		}
		else if (the_x_index+1 < the_sentence.count())
			add_to_counts(the_sentence[the_x_index], the_sentence[the_x_index+1]); 
		else if (the_x_index < the_sentence.count())
			add_to_counts(the_sentence[the_x_index], miNQUDA);
	}
	double hajpaat_x_al_y () const { return double(xycount) / xcount; }
	double hajpaat_y_al_x () const { return double(xycount) / ycount; }

	TiqunZug() { zero_counts(); }
};
typedef const TiqunZug& TiqunZugCR;


void write (ostream& out, TiqunZugCR theinfo, Format format="") {
	write (out,theinfo.x); out << " ";
	write (out,theinfo.y); out << " " << theinfo.ms_cimcum << ":";
	if (format[0]=='C')
		out << " " << theinfo.xcount << " " << theinfo.ycount << " " << theinfo.xycount;
}
status read  (istream& in, TiqunZug& theinfo, Format format="") {
	skip_comments(in,'%');
	DOr (read (in,theinfo.x) );
	DOr (read (in,theinfo.y) );
	if (format[0]=='C') {
		DOr (read(in,theinfo.xcount));
		DOr (read(in,theinfo.ycount));
		DOr (read(in,theinfo.xycount));
	}
	return OK;
	//return read (in,theinfo.weight);
}

inline void duplicate (TiqunZug& to, const TiqunZug& from) { to=from; }
inline void free (TiqunZug& m) { };

SentenceInfo TiqunZug::temp_sentence (2);


/*****************************************************************/
/*****                   taqen_sikuiim                        ****/
/*****************************************************************/

extern ofstream tiqunimlogfile;
double      
//	mijqal_qx=0, mijqal_qy=0, mijqal_rx=0, mijqal_ry=0;    //0000
	mijqal_qx=8.3, mijqal_qy=0, mijqal_rx=9.3, mijqal_ry=17.3;  // a
//	mijqal_qx=8.3, mijqal_qy=0, mijqal_rx=4.9, mijqal_ry=8.7;   // c

double  
//	mijqal_lx=0, mijqal_ly=0, mijqal_ax=0, mijqal_ay=0;   //0000
	mijqal_lx=2.7, mijqal_ly=1.1, mijqal_ax=12.2, mijqal_ay=3;   // a
//	mijqal_lx=1.3, mijqal_ly=9.4, mijqal_ax=23.6, mijqal_ay=2.4; // c
Array2 < TiqunZug > tiqunei_zugot;

ArrayOfSikuiim tosafot_x(15), tosafot_y(15);

void taqen_sikuiim_zugot (ArrayOfMOWS& the_eachword_options) {
	//	mtaqqen ^et ha-sikkuyim $ell millim smukot to^amot, &"p ha-qobc TIQUNIM2.MA
	if (the_eachword_options.count()<2) return;
	Index w;
	for (w=0; w<the_eachword_options.count()-1; ++w) {   // xappe$ zug $e-mat^im l-^axat ha-tabniot
		MorphOptionsWithSikui options_x = the_eachword_options[w], options_y = the_eachword_options[w+1];
		atxel(tosafot_x,options_x.count());  atxel(tosafot_y,options_y.count());
		if (options_x.count()<=1 && options_y.count()<=1) continue;  // There is no point in adjusting the sikuiim when there is only one option!
		if (tiqunimlogfile.is_open()) tiqunimlogfile << options_x << " --- " << options_y << endl;

		LOOPVECTOR(;,tiqunei_zugot,t) {		/***** tiqqunei zugot *****/
			TiqunZug& cur_tiqun = tiqunei_zugot[t];
			LOOPVECTOR(;,options_x,ox) if (cur_tiqun.x.match( options_x.info(ox) ) ){
				LOOPVECTOR(;,options_y,oy) if (cur_tiqun.match( options_x.info(ox), options_y.info(oy) ) ){
					double the_makpela = options_x.realsikui(ox) * options_y.realsikui(oy);
					double tosefet_qadima = the_makpela * cur_tiqun.hajpaat_x_al_y(); assert(tosefet_qadima<=1.);
					double tosefet_axora = the_makpela * cur_tiqun.hajpaat_y_al_x();  assert(tosefet_axora<=1.);
					tosafot_x[ox] += sikui(mijqal_qx*tosefet_qadima + mijqal_rx*tosefet_axora);
					tosafot_y[oy] += sikui(mijqal_qy*tosefet_qadima + mijqal_ry*tosefet_axora);
					//tosafot_x[ox] += sikui(mijqal_rx*tosefet_axora);
					//tosafot_y[oy] += sikui(mijqal_qy*tosefet_qadima);
				}
			}
		}

		LOOPVECTOR(;,options_x,ox) { MorphInfo info_x = options_x.info(ox).mila_axrona_info();
			LOOPVECTOR(;,options_y,oy) { MorphInfo info_y = options_y.info(oy).mila_rijona_info();
				double the_makpela = options_x.realsikui(ox) * options_y.realsikui(oy);
				double tosefet_lx = the_makpela * hajpaat_y_al_x_L (info_x,info_y); assert(tosefet_lx<1.);
				double tosefet_ly = the_makpela * hajpaat_x_al_y_L (info_x,info_y); assert(tosefet_ly<1.);
				double tosefet_ax = the_makpela * hajpaat_y_al_x_A (info_x,info_y); assert(tosefet_ax<1.);
				double tosefet_ay = the_makpela * hajpaat_x_al_y_A (info_x,info_y); assert(tosefet_ay<1.);
				tosafot_x[ox] += sikui(mijqal_ax*tosefet_ax + mijqal_lx*tosefet_lx);
				tosafot_y[oy] += sikui(mijqal_ay*tosefet_ay + mijqal_ly*tosefet_ly);
				//tosafot_x[ox] += sikui(mijqal_lx*tosefet_lx);
				//tosafot_y[oy] += sikui(mijqal_ay*tosefet_ay);
			}
		}

		options_x.add (tosafot_x);  options_y.add (tosafot_y);
		if (tiqunimlogfile.is_open())  {
			tiqunimlogfile << tosafot_x << " --- " << tosafot_y << endl;
			tiqunimlogfile << options_x << " --- " << options_y << endl;
		}
	}
}


/*
void taqen_sikuiim (ArrayOfMOWS& the_sentence_options) {
	taqen_sikuiim_zugot (the_sentence_options);
}
*/


/*******************************************************************/
/*********                 I/O                        **************/
/*******************************************************************/


void atxel_tiqunim (CStr thepath) {
	ifstream tiqunim_infile;
	StringTemp thefilename = concat_path_to_filename(thepath,"tiqunim2.ma");
	cerr << "reading tiqunim file " << thefilename << endl;
	DOx(open(thefilename.str,tiqunim_infile));
	skip_comments(tiqunim_infile,'%');
	DOx(read(tiqunim_infile,tiqunei_zugot,Format("P\n")));
	tiqunim_infile.close();
}


//	This function should be called only after "read_the_cimcumim"!
void atxel_tiqunim_from_cimcumim () {
	assert (!hacimcumim.isempty());
	TiqunZug::temp_sentence.truncate(2);
	LOOPVECTOR (;,hacimcumim,x) {
		XoqCimcumCR cur_xoq = hacimcumim[x];
		if (cur_xoq.ork()!=2) continue;
		TiqunZug cur_tiqun;
		cur_tiqun.x = cur_xoq.tavniot[0];
		cur_tiqun.y = cur_xoq.tavniot[1];
		cur_tiqun.ms_cimcum = x;
		tiqunei_zugot.append(cur_tiqun);
	}	
}



void adken_tiqunim (CStr correct_analysis_filename) {
	LOOPVECTOR(;,tiqunei_zugot,t) 		
		tiqunei_zugot[t].zero_counts();
	cerr << "reading correct analysis file " << correct_analysis_filename << endl;
	open_infile (correct_analysis_filename,correct_analysis);
	SentenceInfo hanitux_hanakon_lamijpat, hanitux_hanakon_lamijpat_mufrad;
	for(;;) {
		DOEOFx(hanitux_hanakon_lamijpat.read(correct_analysis));
		//hanitux_hanakon_lamijpat.hafred_txiliot (hanitux_hanakon_lamijpat_mufrad);
		LOOPVECTOR(;,hanitux_hanakon_lamijpat,w) {
			LOOPVECTOR(;,tiqunei_zugot,t)
				tiqunei_zugot[t].add_to_counts (hanitux_hanakon_lamijpat,w);
		}
	}
	correct_analysis.close();
}



void ktov_tiqunim (CStr thepath) {
	ofstream out;
	StringTemp thefilename = concat_path_to_filename(thepath,"tiqunim2.mb");
	DO(open(thefilename.str,out,0));
	out<<endl; writeln(out,tiqunei_zugot,Format("P\nC"));
	out.close();
}





#ifdef TEST_TIQUN2
/***************************************************************************/
/**********        TEST TIQUN2                                      ********/
/***************************************************************************/

#include <morph/hpmaio2.h>
#include <morph/alghist.h>
#include <morph/morphanl.h>
#include <cpplib/hcs.hxx>

#define LOG_PATH "..\\..\\..\\harc\\"

ofstream hcs_logfile;


void atxel_klali_0() {
	initialize_the_analyzer(log_path,log_path);
	atxel_global_database (NULL,NULL,LOG_PATH "harc10.nts");
	atxel_local_database (LOG_PATH "harc10a.txt");
	open_logfile(3);  xajev_sikuiim_lkol_hamilim_local(); logfile.close();
	open_outfile (LOG_PATH "harc10a.nts",logfile,0); 
	log_local_database(logfile); 
	logfile.close();

	read_the_cimcumim(LOG_PATH);
	atxel_tiqunim_from_cimcumim ();
	adken_tiqunim (LOG_PATH "harc10.to");
	ktov_tiqunim (LOG_PATH);
	adken_monei_zugot_nituxim (LOG_PATH "harc10.to");
	open_logfile(1); ktov_monei_zugot_nituxim(logfile); logfile.close();
}

void atxel_klali() {
	atxel_global_database (NULL,NULL, LOG_PATH "harc10.nts");
	atxel_local_database (NULL,NULL,  LOG_PATH "harc10a.nts");

	read_the_cimcumim(LOG_PATH);
	atxel_tiqunim_from_cimcumim ();
	adken_tiqunim (LOG_PATH "harc10.to");
	ktov_tiqunim (LOG_PATH);
	adken_monei_zugot_nituxim (LOG_PATH "harc10.to");
	open_logfile(1); ktov_monei_zugot_nituxim(logfile); logfile.close();
}



class MijqalimSearcher: public HillClimbingSearcher<double> {

	void init_the_parameters() {}

	double score () const {
		double m0=max(par[0],0.), m1=max(par[1],0.), m2=max(par[2],0.), m3=max(par[3],0.);
		//mijqal_qx=m0; mijqal_qy=m1; mijqal_rx=m2; mijqal_ry=m3;
		mijqal_lx=m0; mijqal_ly=m1; mijqal_ax=m2; mijqal_ay=m3;

		ArrayOfMOWS kol_hanituxim_lamijpat;
		SentenceInfo hanitux_hanakon_lamijpat;
		MorphOptionsWithSikui kol_hanituxim_lamila;
		MorphInfo hanitux_hanakon_lamila;
		double the_score=0; 
		for (Index w=0; w<haqelet.count(); ) {
			qra_mijpat_mehamaarak (w, kol_hanituxim_lamijpat, hanitux_hanakon_lamijpat);
			taqen_sikuiim_zugot (kol_hanituxim_lamijpat);
			the_score += ::score (kol_hanituxim_lamijpat, hanitux_hanakon_lamijpat, w);		
		}
		return the_score;
	}

	void log (double thestep, double thescore) {
		write(hcs_logfile,par);
		write(cerr,par);
		LOG(hcs_logfile," " << thestep << ": " << thescore<<endl);  
	}
	
	void finish() {
		open_errorlogfile(log_path);
		open_tiqunimlogfile(log_path);
		score ();
		close_tiqunimlogfile();
		close_errorlogfile();
	}

public:
	MijqalimSearcher(): HillClimbingSearcher<double>(4) {}

	void run(double step0, double step1,  double m0,double m1,double m2,double m3) {
		par[0]=m0; par[1]=m1; par[2]=m2; par[3]=m3;
		open_outfile (LOG_PATH "loghcs.ma2",hcs_logfile,0);
		atxel_maarkei_qelet (500);
		qra_nituxim_nkonim (LOG_PATH "harc10a.to");
		qra_qelet (LOG_PATH "harc10a.txt");
		natax_qelet_1 ();
		run_algorithm_a(step0,step1);
		hcs_logfile.close();
	}

};



void bdoq_4() {
	MijqalimSearcher the_searcher;
	the_searcher.run(20.,15., 2.7,1.1,12.2,3);
}






void main (void) {
	log_path = "..\\..\\..\\harc";
	atxel_klali_0();
	bdoq_4();
	logfile.close();
}

#endif

