/* mone-nit.h -- mone nittuxim */
/*
	The structure MoneNittuxim contains an entry for each distinct 
		MorphInfoBasic in the corpus. It counts the 'sikuiim' of all 
		MorphInfoBasic's 'similar' to it (see similar.h).
*/

#ifndef __MONENIT_H
#define __MONENIT_H

#include <cpplib/countc.hxx>
#include <cpplib/map.hxx>
#include <cpplib/vector1.hxx>
#include <morph/similar.h>
#include <cpplib/sikui.h>

typedef Dimion DimionFunction (MorphInfoBasicCR , MorphInfoBasicCR );


typedef CounterVector1<MorphInfoBasic> MIBCounter;

class MoneNituxim;
typedef const MoneNituxim& MoneNituximCR;

class MoneNituxim {
	MIBCounter mycounters [16];
	MIBCounter& counter (HeleqDiber hd) { return mycounters[hd+8]; }
	const MIBCounter& counter (HeleqDiber hd) const { return mycounters[hd+8]; }
	Count my_skum;
public:
	void zero_all();
	status setcount (MorphInfoBasicCR theinfo, Count thecount=0);
	status add (MorphInfoBasicCR theinfo, Sikui thesikui=SIKUI1, DimionFunction* the_dimion = dimion);
	status add_exact (MorphInfoBasicCR theinfo, Sikui thesikui=SIKUI1);
	Count count (MorphInfoBasicCR theinfo) const;
	double relative_count (MorphInfoBasicCR theinfo) const;
	friend void write (ostream& out, MoneNituximCR theinfo);
	friend status read (istream& in, MoneNituxim& theinfo);
	friend void duplicate (MoneNituxim& to, MoneNituximCR from);
};

#endif
