/* morphopt.h -- morphological options structures */

#ifndef __MORPHOPT_H
#define __MORPHOPT_H

#include <morph/morphinf.h>
#include <cpplib/vector1.hxx>


/* class MorphOptions is used to hold all the possible morphological options for *
 * a single word.																   */
typedef Vector1<MorphInfo> MorphOptions;
typedef const MorphOptions& MorphOptionsCR;

DEFINE_INLINE_IO_OPERATORS(MorphOptions);

#endif
