/* gentav.cpp -- generate tavniot */

#include <morph/tavnit.h>

static Tavnit tavnit_beinony_1 ("aWbc","abc", POAL,BOTH,HOWE,PAAL);
static Tavnit tavnit_beinony_2 ("Nabc","Nabc",POAL,BOTH,HOWE,NIFAAL);
static Tavnit tavnit_beinony_3 ("Mabc","aIbc",POAL,BOTH,HOWE,PIEL);
static Tavnit tavnit_beinony_4 ("MaWbc","aWbc",POAL,BOTH,HOWE,PUAAL);
static Tavnit tavnit_beinony_5 ("MTabc","HTabc",POAL,BOTH,HOWE,HITPAEL);
static Tavnit tavnit_beinony_6 ("MabIc","HabIc",POAL,BOTH,HOWE,HIFIIL);
static Tavnit tavnit_beinony_7 ("MWabc","HWabc",POAL,BOTH,HOWE,HUFAAL);


#include <cpplib/array2.hxx>
Array2<Tavnit> thetavniot;

void main (void) {
	ofstream testo ("gentav.try");
	testo << "[7: " << endl;
	writeln (testo,tavnit_beinony_1);
	writeln (testo,tavnit_beinony_2);
	writeln (testo,tavnit_beinony_3);
	writeln (testo,tavnit_beinony_4);
	writeln (testo,tavnit_beinony_5);
	writeln (testo,tavnit_beinony_6);
	writeln (testo,tavnit_beinony_7);
	testo << "]" << endl;
	testo.close();

	Tavnit tavnit;
	ifstream testi ("gentav.try");
	read (testi,thetavniot,Format("P\n"));
	writeln (cout,thetavniot,Format("\n"));
}
