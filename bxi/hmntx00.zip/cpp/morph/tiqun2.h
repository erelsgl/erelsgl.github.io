/* tiqun2.h -- tiqqun ha-sikkuyim lfi ha-heq$er */

#ifndef __TIQUN2_H
#define __TIQUN2_H

#include <morph/sntncsik.h>

void taqen_sikuiim_zugot (ArrayOfMOWS& the_eachword_options);
//void taqen_sikuiim (ArrayOfMOWS& the_sentence_options);



void atxel_tiqunim (CStr thepath);
void adken_tiqunim (CStr correct_analysis_filename);
void ktov_tiqunim (CStr thepath);

void atxel_tiqunim_from_cimcumim (); //	This function should be called only after "read_the_cimcumim"!

void open_tiqunimlogfile (CStr log_path);
void close_tiqunimlogfile ();




#endif
