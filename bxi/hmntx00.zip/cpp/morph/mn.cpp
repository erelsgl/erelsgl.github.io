/* mn.cpp -- monei-nituxim */

#include <morph/mn.h>
#include <morph/hpmaio.h>
#include <cpplib/sikui.h>


/************************** struct MoneZugotNituximA *********************************/
/************************** struct MoneZugotNituximA *********************************/
/************************** struct MoneZugotNituximA *********************************/

uint hash_ax (MorphInfoCR x) {
	if (x.zman()==MAQOR) return 6;
	else switch (x.heleqdiber()) {
	case MILAT_XIBUR: return 0;
	case MILAT_YAXAS: return x.has_siomet()? 1: 2;
	case TOAR_POAL: return 3;
	case MILAT_JEELA: return 4;
	case MILIT: return 5;
	// case MAQOR: return 6;
	default: return 7;
	}
}

uint hash_ay (MorphInfoCR y) {
	if (y.vav()) return 0;
	else if (y.jiabud()!=NO_JIABUD) return 0;
	else if (y.otiotyaxas()!=NO_OY) return 1;
	else switch (y.heleqdiber()) {
	case MILAT_XIBUR: return 0;
	case MILAT_YAXAS: return 1;
	case TOAR_POAL: return 2;
	case ECEM: return 3;
	case TOAR: return 4;
	case MISPAR: return 5;
	case POAL: case POAL_EZER: return 6;
	case MILAT_GUF: return 7;
	case JEM_PRATI: return 8;
	case MILAT_JEELA: return 9;
	case MILIT: return 10;
	default: return 11;
	}
}

#define MAX_AX 7
#define MAX_AY 11

struct MoneZugotNituximA {
	Sikui my_counts_x[MAX_AX];
	Sikui my_counts_y[MAX_AY];
	Sikui my_counts_xy[MAX_AX][MAX_AY];

	void zero () {
		Index i,j;
		for (i=0; i<MAX_AX; ++i)
			for (j=0; j<MAX_AY; ++j)  
				my_counts_xy[i][j]=0;
		for (i=0; i<MAX_AX; ++i)  my_counts_x[i]=0;
		for (j=0; j<MAX_AY; ++j)  my_counts_y[j]=0;
	}

	void add (MorphInfoCR x, MorphInfoCR y, Sikui thecount=1) {
		Index hax = hash_ax(x), hay = hash_ay(y);
		if (hax<MAX_AX && hay<MAX_AY) my_counts_xy[hax][hay] += thecount;
		if (hax<MAX_AX) my_counts_x[hax] += thecount;
		if (hay<MAX_AY) my_counts_y[hay] += thecount;
	}

	double hajpaat_x_al_y (MorphInfoCR x, MorphInfoCR y) const {
		Index hax = hash_ax(x), hay = hash_ay(y);
		if (hax>=MAX_AX || hay>=MAX_AY)  return 0;
		else if (my_counts_x[hax]==0) return 0;
		else return double(my_counts_xy[hax][hay]) / my_counts_x[hax];
	}
	double hajpaat_y_al_x (MorphInfoCR x, MorphInfoCR y) const {
		Index hax = hash_ax(x), hay = hash_ay(y);
		if (hax>=MAX_AX || hay>=MAX_AY)  return 0;
		else if (my_counts_y[hay]==0) return 0;
		else return double(my_counts_xy[hax][hay]) / my_counts_y[hay];
	}


	void write (ostream& out) {
		Index i,j;
		out << setw(9) << " ";
		for (j=0; j<MAX_AY; ++j) {
			out << setw(7) << my_counts_y[j];
		}
		out << endl;
		for (i=0; i<MAX_AX; ++i) {
			out << setw(10) << my_counts_x[i];
			for (j=0; j<MAX_AY; ++j) { 
				out << setw(7) << my_counts_xy[i][j];
			}
			out << endl;
		}
	}

	status read (istream& in) {
		Index i,j;
		for (j=0; j<MAX_AY; ++j) {
			DOr(::read(in,my_counts_y[j]));
		}
		for (i=0; i<MAX_AX; ++i) {
			DOr(::read(in,my_counts_x[i]));
			for (j=0; j<MAX_AY; ++j) { 
				DOr(::read(in,my_counts_xy[i][j]));
			}
		}
		return OK;
	}
};


MoneZugotNituximA mone_zugot_nituxim_a;



/************************** struct MoneZugotNituximL *********************************/
/************************** struct MoneZugotNituximL *********************************/
/************************** struct MoneZugotNituximL *********************************/


uint hash_ly (MorphInfoCR y) {
	if (y.vav()) return 0;
	else if (y.jiabud()!=NO_JIABUD) return 1;
	else if (y.otiotyaxas()!=NO_OY) return 3;
	else if (y.zman()==MAQOR) return 7;
	else switch (y.heleqdiber()) {
	case MILAT_XIBUR: return 2;
	case MILAT_YAXAS: return 3;
	case TOAR_POAL: return 4;
	case MILAT_JEELA: return 5;
	case MILIT: return 6;
	default: return 8;
	}
}


uint hash_lx (MorphInfoCR x) {
	switch (x.heleqdiber()) {
	case MILAT_XIBUR: return 0;
	case MILAT_YAXAS: return x.has_siomet()? 1: 2;
	case TOAR_POAL: return 3;
	case ECEM: return x.smikut()==NISMAK? 4: x.has_siomet()? 5: 6;
	case TOAR: return x.smikut()==NISMAK? 7: 8;
	case MISPAR: return x.smikut()==NISMAK? 9: x.has_siomet()? 10: 11;
	case POAL: return 12;
	case POAL_EZER: return 13;
	case MILAT_GUF: return 14;
	case JEM_PRATI: return 15;
	case MILAT_JEELA: return 16;
	case MILIT: return 17;
	default: return 18;
	}
}

#define MAX_LX 18
#define MAX_LY 8

struct MoneZugotNituximL {
	Sikui my_counts_x[MAX_LX];
	Sikui my_counts_y[MAX_LY];
	Sikui my_counts_xy[MAX_LX][MAX_LY];

	void zero () {
		Index i,j;
		for (i=0; i<MAX_LX; ++i)
			for (j=0; j<MAX_LY; ++j)  
				my_counts_xy[i][j]=0;
		for (i=0; i<MAX_LX; ++i)  my_counts_x[i]=0;
		for (j=0; j<MAX_LY; ++j)  my_counts_y[j]=0;
	}


	void add (MorphInfoCR x, MorphInfoCR y, Sikui thecount=1) {
		Index hlx = hash_lx(x), hly = hash_ly(y);
		if (hlx<MAX_LX && hly<MAX_LY) my_counts_xy[hlx][hly] += thecount;
		if (hlx<MAX_LX) my_counts_x[hlx] += thecount;
		if (hly<MAX_LY) my_counts_y[hly] += thecount;
	}

	double hajpaat_x_al_y (MorphInfoCR x, MorphInfoCR y) const {
		Index hlx = hash_lx(x), hly = hash_ly(y);
		if (hlx>=MAX_LX || hly>=MAX_LY)  return 0;
		else if (my_counts_x[hlx]==0) return 0;
		else return double(my_counts_xy[hlx][hly]) / my_counts_x[hlx];
	}
	double hajpaat_y_al_x (MorphInfoCR x, MorphInfoCR y) const {
		Index hax = hash_lx(x), hay = hash_ly(y);
		if (hax>=MAX_LX || hay>=MAX_LY)  return 0;
		else if (my_counts_y[hay]==0) return 0;
		else return double(my_counts_xy[hax][hay]) / my_counts_y[hay];
	}


	void write (ostream& out) {
		Index i,j;
		out << setw(9) << " ";
		for (j=0; j<MAX_LY; ++j) {
			out << setw(7) << my_counts_y[j];
		}
		out << endl;
		for (i=0; i<MAX_LX; ++i) {
			out << setw(10) << my_counts_x[i];
			for (j=0; j<MAX_LY; ++j) { 
				out << setw(7) << my_counts_xy[i][j];
			}
			out << endl;
		}
	}

	status read (istream& in) {
		Index i,j;
		for (j=0; j<MAX_LY; ++j) {
			DOr(::read(in,my_counts_y[j]));
		}
		for (i=0; i<MAX_LX; ++i) {
			DOr(::read(in,my_counts_x[i]));
			for (j=0; j<MAX_LY; ++j) { 
				DOr(::read(in,my_counts_xy[i][j]));
			}
		}
		return OK;
	}
};


MoneZugotNituximL mone_zugot_nituxim_l;



/**************************        klali             *********************************/
/**************************        klali             *********************************/
/**************************        klali             *********************************/

#include <morph/sntncinf.h>

double hajpaat_x_al_y_L (MorphInfoCR x, MorphInfoCR y) { 
	return mone_zugot_nituxim_l.hajpaat_x_al_y(x,y); }

double hajpaat_x_al_y_A (MorphInfoCR x, MorphInfoCR y) { 
	return mone_zugot_nituxim_a.hajpaat_x_al_y(x,y); }

double hajpaat_y_al_x_L (MorphInfoCR x, MorphInfoCR y) { 
	return mone_zugot_nituxim_l.hajpaat_y_al_x(x,y); }

double hajpaat_y_al_x_A (MorphInfoCR x, MorphInfoCR y) { 
	return mone_zugot_nituxim_a.hajpaat_y_al_x(x,y); }


void adken_monei_zugot_nituxim (CStr correct_analysis_filename) {
	mone_zugot_nituxim_l.zero();
	mone_zugot_nituxim_a.zero();
	ifstream correct_analysis;
	cerr << "reading correct analysis file " << correct_analysis_filename << endl;
	open_infile (correct_analysis_filename,correct_analysis);
	SentenceInfo hanitux_hanakon_lamijpat, hanitux_hanakon_lamijpat_mufrad;
	for(;;) {
		DOEOFx(hanitux_hanakon_lamijpat.read(correct_analysis));
		hanitux_hanakon_lamijpat.hafred_txiliot (hanitux_hanakon_lamijpat_mufrad);
		for(Index w=0; w+1<hanitux_hanakon_lamijpat.count(); ++w) {
			MorphInfoCR x=hanitux_hanakon_lamijpat[w], y=hanitux_hanakon_lamijpat[w+1];
			mone_zugot_nituxim_l.add(x,y);
			mone_zugot_nituxim_a.add(x,y);
		}
	}
	correct_analysis.close();
}

void ktov_monei_zugot_nituxim (ofstream& logfile) {
	mone_zugot_nituxim_a.write(logfile);
	logfile << endl << endl;
	mone_zugot_nituxim_l.write(logfile);
	logfile << endl << endl;
}	


#ifdef TEST_MN
/**********************************************************************/
/*******            TEST MN                                     *******/
/**********************************************************************/

void main (void) {
	log_path = "..\\..\\..\\harc";
	adken_monei_zugot_nituxim("..\\..\\..\\harc\\harc10.to2");
	open_logfile(1); 
	ktov_monei_zugot_nituxim(logfile);
	logfile.close();
}

#endif

