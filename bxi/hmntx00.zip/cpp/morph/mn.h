/* mn.h -- monei-nittuxim-axrei (w-gamm lipnei) */

#ifndef __MN_H
#define __MN_H

#include <morph/morphinf.h>

double hajpaat_x_al_y_L (MorphInfoCR x, MorphInfoCR y);
double hajpaat_x_al_y_A (MorphInfoCR x, MorphInfoCR y);
double hajpaat_y_al_x_L (MorphInfoCR x, MorphInfoCR y);
double hajpaat_y_al_x_A (MorphInfoCR x, MorphInfoCR y);
void adken_monei_zugot_nituxim (CStr correct_analysis_filename);
void ktov_monei_zugot_nituxim (ofstream& logfile);
//void ktov_monei_nituxim (ostream& out);
//status qra_monei_nituxim(istream& in);
//void qra_monei_nituxim (CStr path);

#endif

