/* hpmaio2.cpp -- IO routines for HPMA */

#include <morph/hpmaio2.h>
#include <morph/alghist.h>






/********************************************************************************/

/*
	These arrays contain the analyses of words from the input files.
	They are used to save time (to read the files only once).
*/
Array2<char*> haqelet;
Vector1<MorphOptionsWithSikui> kol_hanituxim_laqelet;
Vector1<MorphInfo> hanitux_jelanu_laqelet;
Array2<MorphInfo> hanitux_hanakon_laqelet;



void atxel_maarkei_qelet (Size ms_milim_baqelet) {
	haqelet.reset (ms_milim_baqelet);
	//kol_hanituxim_laqelet.reset (ms_milim_baqelet);
	//hanitux_jelanu_laqelet.reset (ms_milim_baqelet);
	hanitux_hanakon_laqelet.reset (ms_milim_baqelet);
}


void qra_nituxim_nkonim (CStr correct_analysis_filename) {
	open_infile (correct_analysis_filename,correct_analysis);
	MorphInfo hanitux_hanakon_lamila;
	for (;;) {
		DOEOFx(read(correct_analysis,hanitux_hanakon_lamila));
		DOx(hanitux_hanakon_laqelet.append(hanitux_hanakon_lamila));
	}
}

void qra_pelet_xelqi (CStr partial_output_filename) {
	open_infile (partial_output_filename,correct_analysis);
	MorphInfo hanitux_hanakon_lamila;
	for (;;) {
		DOEOFx(read(correct_analysis,hanitux_hanakon_lamila));
		DOx(hanitux_jelanu_laqelet.append(hanitux_hanakon_lamila));
	}
}



void qra_qelet (CStr input_filename) {
	LOOPVECTOR(;,haqelet,w) vecfree(haqelet[w]);
	haqelet.truncate();
	open_infile_with_messages (input_filename,input);
	StringTemp hamila(30);
	for (;;) {
		input.ipfx();
		DOEOFx(hamila.readword(input));
		if (hamila.len==0) continue;
		if (hamila[0]=='*') continue;  // End Of Article symbol
		haqelet.append (hamila.duplicate());
	}
}

status qra_qelet (istream& input, uint article_limit) {
	LOOPVECTOR(;,haqelet,w) vecfree(haqelet[w]);
	haqelet.truncate();
	StringTemp hamila(30);
	for (;;) {
		input.eatwhite();
		DOEOFr(hamila.readword(input));
		if (hamila.len==0) continue;
		if (hamila[0]=='*') { // End Of Article symbol
			article_limit--;
			if (article_limit==0) return OK;
			continue;  
		}
		haqelet.append (hamila.duplicate());
	}
	if (haqelet.count()==0) return EOF;
	else return OK;
}



void natax_qelet_1(Index start_from_word_num) {
	free (kol_hanituxim_laqelet);
	kol_hanituxim_laqelet.reset (haqelet.count());
	for (Index w=start_from_word_num; w<haqelet.count(); ++w) {
		CStr hamila = haqelet[w];
		MorphOptionsWithSikui kol_hanituxim_lamila = independent_analysis_with_approximate_sikuiim (hamila);
		kol_hanituxim_laqelet[w] = kol_hanituxim_lamila;
	}
}


void natax_qelet_1(CStr hamila) {
	Index start_from_word_num=0;
	for (Index w=start_from_word_num; w<haqelet.count(); ++w) {
		if (identical(hamila,haqelet[w])) {
			MorphOptionsWithSikui kol_hanituxim_lamila = independent_analysis_with_approximate_sikuiim (hamila);
			kol_hanituxim_laqelet[w] = kol_hanituxim_lamila;
		}
	}
}


void natax_qelet_2(Index start_from_word_num) {
	hanitux_jelanu_laqelet.reset (haqelet.count());
	for (Index w=start_from_word_num; w<haqelet.count(); ++w) {
		MorphOptionsWithSikui& kol_hanituxim_lamila = kol_hanituxim_laqelet[w];
		if (kol_hanituxim_lamila.isempty()) continue;
		hanitux_jelanu_laqelet[w] = kol_hanituxim_lamila.info_with_greatest_sikui();
	}
}




void qra_mijpat_mehamaarak (Index w, ArrayOfMOWS& kol_hanituxim_lamijpat, SentenceInfo& hanitux_hanakon_lamijpat) {
#define SOF_MIJPAT(c) (c=='.'||c=='?'||c=='!')
	static ArrayOfMOWS kol_hanituxim_lamijpat___ (50);
	kol_hanituxim_lamijpat___.truncate();
	hanitux_hanakon_lamijpat.truncate();
	for(Index i=0;;++i) {
		CStr hamila = haqelet[w];
		kol_hanituxim_lamijpat___.append(kol_hanituxim_laqelet[w]);
		hanitux_hanakon_lamijpat.append(hanitux_hanakon_laqelet[w]);
		++w;
		if (SOF_MIJPAT(hamila[0])) break;
	}
	free(kol_hanituxim_lamijpat);
	duplicate (kol_hanituxim_lamijpat,kol_hanituxim_lamijpat___);
}

void qra_mijpat_mehamaarak (Index w, ArrayOfMOWS& kol_hanituxim_lamijpat, Array2<CStr>& hamijpat) {
	static ArrayOfMOWS kol_hanituxim_lamijpat___ (50);
	kol_hanituxim_lamijpat___.truncate();
	hamijpat.truncate();
	for(Index i=0;;++i) {
		if (w>=haqelet.count())  break;   
		CStr hamila = haqelet[w];
		kol_hanituxim_lamijpat___.append(kol_hanituxim_laqelet[w]);
		hamijpat.append(haqelet[w]);
		++w;
		if (SOF_MIJPAT(hamila[0])) break;
	}
	free(kol_hanituxim_lamijpat);
	duplicate (kol_hanituxim_lamijpat,kol_hanituxim_lamijpat___);
}

void ktov_mijpat_lamaarak (Index w, ArrayOfMOWSCR kol_hanituxim_lamijpat) {
	LOOPVECTOR (;,kol_hanituxim_lamijpat,i) {
		kol_hanituxim_laqelet[w] = kol_hanituxim_lamijpat[i];
		++w;
	}
}

void ktov_mijpat_lamaarak (Index w, SentenceInfoCR hanitux_jelanu_lamijpat) {
	LOOPVECTOR (;,hanitux_jelanu_lamijpat,i) {
		hanitux_jelanu_laqelet[w] = hanitux_jelanu_lamijpat[i];
		++w;
	}
}



uint 
	num_of_words,
	num_of_mistakes, 
	num_of_mlbdtxiliot_mistakes, 
	num_of_baseword_mistakes;

void hajwe_nituxim (MorphInfoCR hanitux_jelanu, MorphInfoCR hanitux_hanakon, CStr hamila) {
	if (!identical_baseword(hanitux_jelanu,hanitux_hanakon))  ++num_of_baseword_mistakes;
	if (!identical_except_txiliot(hanitux_jelanu,hanitux_hanakon))  ++num_of_mlbdtxiliot_mistakes;
	if (!identical(hanitux_jelanu,hanitux_hanakon))  ++num_of_mistakes;
	if (!identical(hanitux_jelanu,hanitux_hanakon))  log_the_mistake (num_of_words,hamila,hanitux_jelanu,hanitux_hanakon);
}

void hajwe_nituxim (SentenceInfoCR hanitux_jelanu_lamijpat, SentenceInfoCR hanitux_hanakon_lamijpat, SentenceCR hamijpat) {
	if (hanitux_jelanu_lamijpat.count() != hanitux_hanakon_lamijpat.count()) {
		if (errorlogfile.is_open()) {
			LOG(errorlogfile,"\nM$P@ $LM $GWI! (" << hamijpat << ")"); }
		return;
	}
	LOOPVECTOR (;,hanitux_jelanu_lamijpat,w) {
		StringTemp hamila = hamijpat.word(w);  if (hamila.len==0) { continue; }
		MorphInfoCR hanitux_jelanu_lamila = hanitux_jelanu_lamijpat[w];
		MorphInfoCR hanitux_hanakon_lamila = hanitux_hanakon_lamijpat[w];
		hajwe_nituxim (hanitux_jelanu_lamila, hanitux_hanakon_lamila, hamila.str);
		++num_of_words;
	}
}

void hajwe_mijpat_lamaarak (Index w, SentenceInfoCR hanitux_jelanu_lamijpat) {
	LOOPVECTOR(;,hanitux_jelanu_lamijpat,i) {
		MorphInfoCR hanitux_jelanu = hanitux_jelanu_lamijpat[i];
		MorphInfoCR hanitux_hanakon = hanitux_hanakon_laqelet[w];
		hajwe_nituxim (hanitux_jelanu,hanitux_hanakon, haqelet[w]);
		++w;
		++num_of_words;
	}
}

void hajwe_nituxim () {
	num_of_words=num_of_mistakes=0;
	for(Index w=0; w<godel_haqelet(); ++w) {
		MorphInfoCR hanitux_jelanu = hanitux_jelanu_laqelet[w];
		MorphInfoCR hanitux_hanakon = hanitux_hanakon_laqelet[w];
		hajwe_nituxim (hanitux_jelanu, hanitux_hanakon,haqelet[w]);
		++num_of_words;
	}
}

void hajwe_nituxim (Array2<Index>& indexei_tauyot) {
	indexei_tauyot.truncate();
	num_of_words=num_of_mistakes=0;
	for(Index w=0; w<godel_haqelet(); ++w) {
		MorphInfoCR hanitux_jelanu = hanitux_jelanu_laqelet[w];
		MorphInfoCR hanitux_hanakon = hanitux_hanakon_laqelet[w];
		if (!identical(hanitux_jelanu,hanitux_hanakon))  {
			++num_of_mistakes;
			log_the_mistake (num_of_words,haqelet[w],hanitux_jelanu,hanitux_hanakon);
			indexei_tauyot.append(w);
		}
		++num_of_words;
	}
}




double score (ArrayOfMOWSCR kol_hanituxim_lamijpat, SentenceInfo hanitux_hanakon_lamijpat, Index& w) {
	LOOPVECTOR(double ciyun=0,kol_hanituxim_lamijpat,i) {
		MorphInfoCR hanitux_hanakon = hanitux_hanakon_lamijpat[i];
		MorphOptionsWithSikuiCR kol_hanituxim = kol_hanituxim_lamijpat[i];
		MorphInfoCR hanitux_jelanu = kol_hanituxim.info_with_greatest_sikui();
		if (!identical(hanitux_jelanu,hanitux_hanakon)) {
			Index o = kol_hanituxim.indexof(hanitux_hanakon);
			ciyun = ciyun - 1 + kol_hanituxim.realsikui(o);
			log_the_mistake (w,haqelet[w],hanitux_jelanu,hanitux_hanakon);
		}
		++w;
	}
	return ciyun;
}	

double score () {
	LOOPVECTOR(double ciyun=0,haqelet,w) {
		MorphInfoCR hanitux_hanakon = hanitux_hanakon_laqelet[w];
		MorphOptionsWithSikuiCR kol_hanituxim = kol_hanituxim_laqelet[w];
		MorphInfoCR hanitux_jelanu = hanitux_jelanu_laqelet[w];
		if (!identical(hanitux_jelanu,hanitux_hanakon)) {
			Index o = kol_hanituxim.indexof(hanitux_hanakon);
			ciyun = ciyun - 1 + kol_hanituxim.realsikui(o);
			log_the_mistake (w,haqelet[w],hanitux_jelanu,hanitux_hanakon);
		}
	}
	return ciyun;
}

