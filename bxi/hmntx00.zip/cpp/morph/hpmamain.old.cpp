/* hpmamain.cpp */


#include <math.h>

#include <morph/lexiconb.h>
#include <morph/lexicon.h>
#include <morph/addlex.h>
#include <morph/morphanl.h>

#include <morph/alghist.h>
#include <morph/tiqun.h>
#include <morph/bituy.h>

#include <cpplib/ui.h>
#include <morph/morphui.h>
#include <morph/hpmaio.h>
#include <cpplib/sentence.h>

#include <cpplib/wordcnt.h>
#include <cpplib/hashtab.hxx>
#include <cpplib/map.hxx>
#include <cpplib/countc.hxx>



/***************************************************************************/
/***********        utility routines                                ********/
/***************************************************************************/

bool sof;
bool pelet_cafuf;

void log_global_database (Index thenum) {
	open_logfile(thenum);  
	log_global_database(logfile);
	logfile.close();
}

void log_local_database (Index thenum) {
	open_logfile(thenum);  
	log_local_database(logfile);
	logfile.close();
}


status read_and_analyze_the_next_sentence (istream& input, Sentence& thesentence, Vector1<MorphOptionsWithSikui>& the_sentence_options) {
	skip_spaces_and_stars (input);	
	DOr(thesentence.readline(input));
	free ( the_sentence_options);
	DOr(the_sentence_options.realloc(thesentence.wordcount()));
	for (Index w=0; w<thesentence.wordcount(); ++w) {
		StringTemp curword = thesentence.word(w);
		if (curword.len==0)  { continue; }
		MorphOptionsWithSikui curoptions = analysis_with_approximate_sikuiim(curword.str);
		curoptions.xajev_skum(); 	assert(900<curoptions.skum&&curoptions.skum<1100);
		duplicate (the_sentence_options[w],curoptions);
	}
	return OK;
}


ifstream correct_output;
void read_partial_output (CStr input_filename, CStr output_filename) {
	cerr << "reading partial output file " << output_filename << endl;
	open_infile (output_filename,correct_output);
	open_infile (input_filename,input);

	Sentence cursentence(500);
	Vector1<MorphOptionsWithSikui> cursentence_options;
	MorphOptionsWithSikui curoptions;
	StringTemp curword(30);
	MorphInfo correct_analysis;  
	Index index_of_correct_analysis;

	for(;;) {
			skip_spaces_and_stars(correct_output);  
			if (correct_output.eof()) break;
			DOEOFx (read(correct_output,correct_analysis));
			skip_spaces_and_stars(input);			
			DOEOFx (curword.readword(input));
			curoptions = analysis_with_approximate_sikuiim (curword.str);
			index_of_correct_analysis = curoptions.indexof(correct_analysis);
			if ( index_of_correct_analysis < curoptions.count() )
				move_one_word_from_approximate_database_to_realistic_database (curword.str,index_of_correct_analysis);
			else { 
				cerr << "$GIAH BMILH " << curword << ": HNITUX " << correct_analysis << " LA NMCA!" << endl;
				lexlogfile << curword << ": " << correct_analysis << endl;
			}
	}
	correct_output.close();
	// don't close input -- it is used afterwards.
}


/***************************************************************************/
/***********        Sentence analysis                               ********/
/***************************************************************************/

Sikui sikui_saf (uint options_count) {
	return options_count>1? sikui ( pow(1./options_count,0.63) ): 500;
}



Bituy Bituy_bw_bw (MorphInfo thex, MorphInfo they) {
	Bituy b;
	b.x().set_baseword(thex);
	b.y().set_baseword(they);
	return b;
}

Bituy Bituy_bw_txiliot (MorphInfo thex, MorphInfo they) {
	Bituy b;
	b.x().set_baseword(thex);
	b.y().set_txiliot(they);
	return b;
}



#define Mone CounterHashTable

Mone<Bituy> mone_bituyim_bw_bw;
Mone<Bituy> mone_bituyim_bw_txiliot;

void sfor_bituyim (Vector1<MorphOptionsWithSikui>& the_sentence_options) {
	if (the_sentence_options.count()<2) return;
	for (Index w=0; w<the_sentence_options.count()-1; ++w) {   // xappe$ zug $e-mat^im l-^axat ha-tabniot
		MorphOptionsWithSikui options_x = the_sentence_options[w], options_y = the_sentence_options[w+1];
		LOOPVECTOR(;,options_x,ox) { 
			MorphInfoCR infox = options_x.info(ox); 
			if (strlen(infox.baseword())<=1) continue;
			LOOPVECTOR(;,options_y,oy) {
				MorphInfoCR infoy = options_y.info(oy); 
				if (strlen(infoy.baseword())<=1) continue;
				Sikui the_sikui = product (options_x.sikui(ox), options_y.sikui(oy), 1);		
				mone_bituyim_bw_bw.add (Bituy_bw_bw(infox,infoy), the_sikui);
				mone_bituyim_bw_txiliot.add (Bituy_bw_txiliot(infox,infoy), the_sikui);
			} }
	}
}	

void ktov_bituyim () {
	bituyimlogfile << "bi@uyim baseword-baseword:" << endl;
	for (Mone<Bituy>::Cursor c(mone_bituyim_bw_bw); c.isvalid(); ++c) {
		Sikui the_count = c.count();
		Bituy the_bituy = c.data();
		if (the_count >= sikui(2) ) 
			bituyimlogfile <<  "  " << the_bituy << " " << the_count << endl;
	}
	bituyimlogfile << "bi@uyim baseword-txiliot:" << endl;
	for (c.reset(mone_bituyim_bw_txiliot); c.isvalid(); ++c) {
		Sikui the_count = c.count();
		Bituy the_bituy = c.data();
		if (the_count >= sikui(2) ) 
			bituyimlogfile <<  "  " << the_bituy << " " << the_count << endl;
	}
}

#undef Mone

/***************************************************************************/
/***********        Test Mode analysis                              ********/
/***************************************************************************/

void test_mode_analysis () {
	Sentence cursentence(500);
	Vector1<MorphOptionsWithSikui> cursentence_options;
	MorphOptionsWithSikui curoptions;
	StringTemp curword(30);
	MorphInfo correct_analysis;

	uint num_of_words = 0, 
	num_of_mistakes=0, 
	num_of_mlbdtxiliot_mistakes=0, 
	num_of_baseword_mistakes=0;
	for(;;) {
		DOEOFx(read_and_analyze_the_next_sentence (input, cursentence, cursentence_options));
		taqen_sikuiim (cursentence_options);
		sfor_bituyim (cursentence_options);
		for (Index w=0; w<cursentence.wordcount(); ++w) {
			StringTemp curword = cursentence.word(w);
			if (curword.len==0)  { continue; }
			curoptions = cursentence_options[w];
			DOEOFx (read(correct_output,correct_analysis));	

			if (curoptions.isempty())   { cerr<<curword<<" "; continue; }
			Index m = maxindex (curoptions);
			Sikui the_greatest_sikui = curoptions.sikui(m);
			MorphInfoCR the_analysis_with_the_greatest_sikui = curoptions.info(m);
			the_analysis_with_the_greatest_sikui.write_barur (cerr,curword.str);  cerr << " ";
			if (!identical_baseword(the_analysis_with_the_greatest_sikui,correct_analysis))  ++num_of_baseword_mistakes;
			if (!identical_except_txiliot(the_analysis_with_the_greatest_sikui,correct_analysis))  ++num_of_mlbdtxiliot_mistakes;
			if (!identical(the_analysis_with_the_greatest_sikui,correct_analysis))  ++num_of_mistakes;
			if (!identical(the_analysis_with_the_greatest_sikui,correct_analysis)) {  // log the mistake	
				errorlogfile	<< "M#" << num_of_words << " (" << curword << "): "
								<< the_analysis_with_the_greatest_sikui << "    C\"L   " << correct_analysis << endl;
			}
			++num_of_words;
		}
	}
	LOG(errorlogfile,"\nMSPR MILIM KWLL:            " << num_of_words << endl);
	LOG(errorlogfile,"MSPR $GIAWT:                " << num_of_mistakes
			<< " (" << (num_of_mistakes*100./num_of_words) << "%)" << endl);
	LOG(errorlogfile,"MSPR $GIAWT B&RK MILWNI:    " << num_of_baseword_mistakes 
			<< " (" << (num_of_baseword_mistakes*100./num_of_words) << "%)" << endl);
	ktov_bituyim ();
}



/***************************************************************************/
/***********        Interactive Mode analysis                       ********/
/***************************************************************************/


uint	wordnum=0,       // mispar ha-milim ha-me^u$$arot &ad ko
		curwordnum=0,       // mispar ha-mila ha-nokxit (curwordnum <= wordnum)
		mispar_tiqunim=0,        // meyda& statisti &al mispar ha-tiqunim $e-bicca& ha-mistamme$
		mispar_nituxim_xadajim=0;

StringTemp				milim_meujarot[10];    // maxziq ^et 10 ha-milim ha-axronot $e-^u$ru.
MorphOptionsWithSikui	nituxei_milim_meujarot[10];   // maxziq ^et ha-nituxim $el 10 ha-milim ha-axronot $e-^u$ru.
Index					nituxim_meujarim[10];   // maxziq ^et ha-nituxim $el 10 ha-milim ha-axronot $e-^u$ru.
StringTemp				simanei_pisuq_lifnei_milim[10];
bool					the_nitux_is_xadaj[10]; 

void adken_database_and_cache (CStr thefullword, MorphOptionsWithSikuiCR theoptions) {
	adken_sikuiim_in_approximate_database (thefullword,theoptions);
	for (Index i=0; i<min(10u,wordnum); ++i)
		if ( identical(milim_meujarot[i].str,thefullword) ) {
			free(nituxei_milim_meujarot[i]);  duplicate(nituxei_milim_meujarot[i],theoptions);
		}
}



inline MorphInfoCR nitux_meujar (Index i) { 
	return nituxei_milim_meujarot[i%10].info(nituxim_meujarim[i%10]); }

void flush (uint i) { 
	MorphOptionsWithSikui o;
	// prepare the variables
	StringTempR thefullword = milim_meujarot[i%10];
	StringTempR thepisuq = simanei_pisuq_lifnei_milim[i%10];
	MorphOptionsWithSikui theoptions = nituxei_milim_meujarot[i%10];
	Index thecorrectindex = nituxim_meujarim[i%10];
	MorphInfoCR thecorrectinfo = theoptions.info(thecorrectindex);

	move_one_word_from_approximate_database_to_realistic_database (thefullword.str,thecorrectindex);
	xajev_sikuiim_lkol_hamilim_im_sbwsast (thecorrectinfo);

	// extend the lexicon, but only if the nitux is xadaj.
	if (the_nitux_is_xadaj[i%10])
		extend_lexicon (thefullword.str,thecorrectinfo);

	// output
	if (pelet_cafuf) {
		output << thepisuq;
		thecorrectinfo.write_cafuf (output);
	}
	else {
		output << thepisuq;
		thecorrectinfo.write_barur (output, thefullword.str);
	}
	thepisuq.truncate();
}



ifstream input2;  
void newline() {
	StringTemp curline (300);
	curline.readline(input2);
	cout << endl << curline << endl;
}



/********************* input morphinfo ****************************************/

Index select_txiliot_option (MorphOptionsCR theoptions, CStr thefullword) {
	LOOPVECTOR(;,theoptions,i)  {
		cout << "      " << i << ". ";
		if (theoptions[i].txiliot() > 0) {
			for (Index j=0; j < theoptions[i].txiliot(); ++j)
				cout << thefullword[j];
			cout << "-" << theoptions[i].baseword() << endl;
		}
		else 
			cout << thefullword << endl;
	}
	return Index (input_int("       MHW HNITUX HNKWN?",0,theoptions.count()-1));
}



void input_morphinfo (CStr thefullword, MorphInfo& theinfo) {
	MorphOptions the_txiliot_options = analyze_txiliot(thefullword);
	MorphInfo& selected_option = 
		the_txiliot_options.count()>1? 
			the_txiliot_options [ select_txiliot_option (the_txiliot_options,thefullword) ]:
			the_txiliot_options [0];
	uint the_num_of_txiliot = selected_option.txiliot();
	CStr the_word_without_txiliot = thefullword + the_num_of_txiliot;

	theinfo.settxiliot (selected_option);
	input_morphinfo_basic (theinfo);
	HeleqDiber hd=theinfo.heleqdiber();
	if (hd==ECEM || hd==POAL || hd==POAL_EZER || hd==TOAR || hd==MILAT_GUF || hd==MILAT_YAXAS) {
		StringTemp thebaseword = input_string ("MHW H&RK HMILWNI?",20,the_word_without_txiliot);
		theinfo.setbaseword (thebaseword.str);
	}
	else
		theinfo.setbaseword (the_word_without_txiliot);
}	


/********************* select option ****************************************/

void display_options (MorphOptionsWithSikuiCR theoptions, CStr thefullword) {
	LOOPVECTOR(;,theoptions,i)  {
		cout << "      " << i << ". ";
		theoptions.info(i).write_barur (cout, thefullword);
		cout << " (";
		theoptions.info(i).write_meforat(cout);
		cout << ")" << endl;
	}
	cout << "      " << theoptions.count() << ". " << "AP AXD MHN\"L" << endl;
}

Index select_option (MorphOptionsWithSikui& theoptions, CStr thefullword, bool& the_nitux_is_xadaj) {
	display_options (theoptions,thefullword);
	Index the_index_of_the_selected_analysis = Index (input_int("       MHW HNITUX HNKWN?",0,theoptions.count()));
	the_nitux_is_xadaj = ( the_index_of_the_selected_analysis >= theoptions.count() ) ; 
	if (!the_nitux_is_xadaj) {  // nivxar nitux $e-kvar qayam
		return the_index_of_the_selected_analysis; 
	}
	else {														    // nivxar nitux 'axer' (xada$)
		MorphInfo new_option;  input_morphinfo(thefullword,new_option);
		theoptions.addoption(new_option,1.);
		adken_database_and_cache (thefullword,theoptions);
		lexlogfile << thefullword << ": " << new_option << endl;
		return theoptions.count()-1;
	}
}


/********************* select command ****************************************/


char select_command (CStr thefullword, MorphInfoCR theanalysis, bool question_mark) {
		cout << "   ";
		theanalysis.write_barur (cout, thefullword);  
		if (question_mark)  cout<<"?";  // if you are not sure that this is the right analysis -- say so!
		cout << "   " << flush;
		char c=prompt_from("[A=A$R T=TQN X=XZWR ' '=JURA-XD$H]","atx q"); cout<<endl;
		return c;
}


void get_command_from_user (Index curanalysis_index, bool question_mark=false) {
	for(;!sof;) {
		StringTempCR curword = milim_meujarot[curwordnum%10];
		CStr thefullword = curword.str;
		MorphOptionsWithSikui& curoptions = nituxei_milim_meujarot[curwordnum%10];
		MorphInfoCR curanalysis = curoptions.info(curanalysis_index);
		char c = select_command (thefullword,curanalysis,question_mark);
		switch (c) {
		case 'a':                  // ^a$$er ^et ha-nitux ha-nokxi
			nituxim_meujarim[curwordnum%10] = curanalysis_index;
			++curwordnum;
			if (wordnum+1==curwordnum) {
				++wordnum;
				if (wordnum>=10) {
					flush (wordnum);
				}
			}
			return;
		case 't': {                  // taqqen ^et ha-nittux
			//MorphOptions newoptions = analyze (curword.str);
			//curoptions.set (newoptions);
			//adken_database_and_cache (curword.str,curoptions);
			Index newanalysis_index = select_option (curoptions,thefullword, the_nitux_is_xadaj[curwordnum%10] );
			if (newanalysis_index != curanalysis_index)
				++mispar_tiqunim;
			if (the_nitux_is_xadaj[curwordnum%10])
				++mispar_nituxim_xadajim;
			curanalysis_index = newanalysis_index;
			question_mark = false;
			break; }
		case 'x': {                  // xazor mila axat axora
			if (curwordnum>=1 && curwordnum+9>wordnum) {
				uint prevwordnum = curwordnum = curwordnum-1;
				Index prevanalysis_index = nituxim_meujarim[prevwordnum%10];
				get_command_from_user(prevanalysis_index);
			}
			break; }
		case ' ':
			newline();
			break;
		case 'q':
			sof=true;
		}
	}
}


void interactive_mode_analysis() {
	MorphOptionsWithSikui o1,o2;
	Sentence cursentence(500);
	Vector1<MorphOptionsWithSikui> cursentence_options;
	MorphOptionsWithSikui curoptions;
	open_infile (variable(0),input2);
	for (Index j=0; j<10; ++j)   simanei_pisuq_lifnei_milim[j].alloc(20);

	//newline();
	for(sof=false, mispar_tiqunim=mispar_nituxim_xadajim=0; !sof; ) {
		DOEOFx(read_and_analyze_the_next_sentence (input, cursentence, cursentence_options));
		taqen_sikuiim (cursentence_options);
		sfor_bituyim (cursentence_options);
		//DOEOFx(curword.readword(input));    char nextchar = input.get();
		//DOEOFx(cursentence.readline(input));  //  cursentence.insert_EOS_after_each_word();
		for (Index w=0; w<cursentence.wordcount(); ++w) {
			StringTemp curword = cursentence.word(w);
			StringTemp space = cursentence.space_after_word(w);
			simanei_pisuq_lifnei_milim[wordnum%10].append ( space.str ); 
			if (curword.len==0)   continue; 
			curoptions = cursentence_options[w];
			if (curoptions.isempty()) continue;
			Sikui the_saf = sikui_saf (curoptions.count());
			Index m = maxindex (curoptions);
			Sikui the_greatest_sikui = curoptions.sikui(m);
			milim_meujarot[wordnum%10] = curword;
//			o1 = cursentence_options[0]; o1.xajev_skum(); assert(900<o1.skum&&o1.skum<1100);
//			o2 = analysis_with_approximate_sikuiim("AT"); o2.xajev_skum(); assert(900<o2.skum&&o2.skum<1100);
			free(nituxei_milim_meujarot[wordnum%10]);  duplicate(nituxei_milim_meujarot[wordnum%10],curoptions);
//			o1 = cursentence_options[0]; o1.xajev_skum(); assert(900<o1.skum&&o1.skum<1100);
//			o2 = analysis_with_approximate_sikuiim("AT"); o2.xajev_skum(); assert(900<o2.skum&&o2.skum<1100);
			get_command_from_user (m, the_greatest_sikui<the_saf);
		}
	}

	/* before you leave, don't forget to flush all the words that remained in the buffer. */
	for (Index i=wordnum+1; i<wordnum+10; ++i) {
		if (i>=10)
			flush(i);
	}

#pragma warning (disable: 4244)
	float axuz_tiqunim = 100.*mispar_tiqunim/wordnum;
	float axuz_xadajim = 100.*mispar_nituxim_xadajim/wordnum;

	LOG(logfile,"MSPR MILIM MNUTXOT: " << wordnum << endl 
		<< "MSPR TIQWNIM: " << mispar_tiqunim << " (" << axuz_tiqunim << "%)" << endl
		<< "MSPR NITWXIM XD$IM: " << mispar_nituxim_xadajim << " (" << axuz_xadajim << "%)" << endl);

}

#ifdef MAIN
/***************************************************************************/
/***********        The Main Program                                ********/
/***************************************************************************/



void main (int argc, char* argv[]) {
	lexicon_is_creative=false;
	set_synopsis ("\nInteractive mode:        HPMA *.txt [*.txt] *.out /i [options]\n"
				  "One word analysis mode:    HPMA *.txt *.txt *.out /w word [options]\n"
				  "Compare mode:              HPMA *.txt *.txt *.to  /q [options]\n"
				  "Correct Output mode:       HPMA *.txt *.txt *.to  /o [options]\n"
				  "    (The first *.txt is the large corpus, and the second *.txt is the article)\n"
				  "    (options include:  [/l lex-path] [/g log-path] [/a analysis-filename.NTX] [/s analysis-with-sikuiim-filename.NTS] [/c=cafuf] [/h=hosef])\n");
	parse_command_line (argc,argv,2,3,"ltwasgz","iochq");

	CStr lex_path = option('l')==NULL? ".": option('l');
	initialize_the_analyzer(lex_path,lex_path);
	read_the_tiqunim(lex_path);
	read_the_lexicon_bituyim(lex_path);
	log_path = option('g')==NULL? ".": option('g');
	
	CStr corpus_path, article_path, output_path;
	if (variable(2)!=NULL)
		corpus_path=variable(0), article_path=variable(1), output_path=variable(2);
	else								// no article -- only corpus
		corpus_path=variable(0), article_path=output_path=variable(1);

	atxel_global_database (corpus_path,option('a'),option('s'));
	log_global_database(0);
	if (!swtch('o')) {
		if (variable(2)!=NULL) {
			atxel_local_database (article_path);
		}
	}
	else 
		atxel_local_database_from_correct_output (article_path,output_path);
	log_local_database(1);

	if (option('w')!=NULL) {
		StringTemp main_word;
		main_word.set (option('w'));
		open_logfile(9);
		xajev_sikuiim (main_word.str);
		logfile.close();
	}

	open_logfile(2);
	if (option('s')==NULL) xajev_sikuiim_lkol_hamilim_global ();
	logfile.close();
	log_global_database(4);

//	if (!swtch('o')) {
		if (variable(2)!=NULL) {
			open_logfile(3);
			xajev_sikuiim_lkol_hamilim_local ();
			logfile.close();
		}
		else {
			link_local_database_to_global_database();
		}
//	}
	log_local_database(5);

	pelet_cafuf = swtch('c');

	open_logfile(6); 
	open_lexlogfile(log_path);
	open_errorlogfile(log_path);
	open_tiqunimlogfile(log_path);
	open_bituyimlogfile(log_path);
	if (swtch('h')) {               // hosef!
		read_partial_output (article_path,output_path);
		open_outfile(output_path,output,ios::app);
	}
	else if (swtch('q')) {          // bdoq
		open_infile (article_path,input);
		open_infile (output_path,correct_output);
	}
	else if (swtch('i')){
		open_infile (article_path,input);
		open_outfile (output_path,output,0);
	}

	open_errorlogfile(log_path);
	if (swtch('q'))	test_mode_analysis();
	else if (swtch('i')) interactive_mode_analysis();
	log_local_database(logfile);
	logfile.close();
	close_errorlogfile();
	close_lexlogfile();
	close_tiqunimlogfile();
	close_bituyimlogfile();
}
#endif
