/* taxbir.h -- 
	yxida $e-tapqidah libdoq ha^im mi$pa@ natun hu^ xuqi mi-bxina taxbirit.
*/

#ifndef __TAXBIR_H
#define __TAXBIR_H

#include <morph/sntncinf.h>

bool haceruf_xuqi (MorphInfoBasicCR a, MorphInfoBasicCR b);
bool hamijpat_xuqi (SentenceInfoCR the_mijpat);

#endif
