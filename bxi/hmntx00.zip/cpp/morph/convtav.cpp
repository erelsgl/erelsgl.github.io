/* convtav.cpp */

#include <morph/morphtav.h>

void main (void) {
	DOx ( read_the_tavniot ("c:\\cpp\\morph") );
	write_the_tavniot ("c:\\cpp");
}
