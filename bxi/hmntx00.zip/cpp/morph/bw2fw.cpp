/* bw2fw.cpp -- baseword-to-fullword map */

#include <morph/bw2fw.h>

FullwordArray the_empty_fullword_array;
