/* pmamain.cpp */

#include <morph/morphanl.h>
#include <morph/addlex.h>
#include <morph/alghist.h>
#include <morph/morphui.h>
#include <morph/similar.h>
#include <morph/lexicon.h>
#include <morph/convlang.h>
#include <cpplib/ui.h>
#include <cpplib/cmdline1.h>
#include <cpplib/sentence.h>

#include <math.h>


/***************************************************************************/
/***********        utility routines                                ********/
/***************************************************************************/

bool sof;
ifstream input;
ofstream output;

bool pelet_cafuf;


ofstream logfile, lexlogfile;
CStr log_path;

void open_logfile (Index thenum) {
	StringTemp thefilename = concat_path_to_filename (log_path, format("log%d.ma2",thenum).str );
	open_outfile (thefilename.str,logfile,0);
}

void open_lexlogfile () {
	StringTemp thefilename = concat_path_to_filename  (log_path,"loglex.ma2");
	open_outfile (thefilename.str,lexlogfile,0);
}


void log_the_database (Index thenum) {
	open_logfile(thenum);  
	log_the_database(logfile);
	logfile.close();
}


void open_infile_with_messages (CStr filename, ifstream& input) {
		//cerr << "opening input file " << filename << endl;
		cerr << "reading input file " << filename << endl;
		open_infile (filename,input);
}



void skip_punctuation_and_singletons (istream& in) {
	for(;;) {
		char c = in.get();
		if (charinstring(c,PUNCTUATION_CHARS)) continue;
		if ( charinstring (char(in.peek())," \t\n") ) continue;  // singleton
		in.putback(c);
		break;
	}
}



ifstream correct_output;

void read_partial_output (CStr input_filename, CStr output_filename) {
	cerr << "reading partial output file " << output_filename << endl;
	open_infile (output_filename,correct_output);
	open_infile (input_filename,input);

	StringTemp curword(30);
	MorphOptionsWithSikui curoptions;
	MorphInfo curinfo;  
	Index index_of_curinfo;
	for(;;) {
		skip_punctuation_and_singletons(correct_output);	DOEOFx (read(correct_output,curinfo));
		skip_punctuation_and_singletons(input);			DOEOFx (curword.readword(input));
		curoptions = approximate_analysis_with_sikuiim (curword.str);
		index_of_curinfo = curoptions.indexof(curinfo);
		if ( index_of_curinfo < curoptions.count() )
			move_one_word_from_approximate_database_to_realistic_database (curword.str,index_of_curinfo);
		else { 
			cerr << "$GIAH BMILH " << curword << ": HNITUX " << curinfo << " LA NMCA!" << endl;
			lexlogfile << curword << ": " << curinfo << endl;
		}
	}
	correct_output.close();
	// don't close input -- it is used afterwards.
}

status read_and_analyze_the_next_sentence (istream& input, Sentence& the_sentence, Vector1<MorphOptionsWithSikui>& the_options) {
	DOr(the_sentence.readline(input));
	DOr(the_options.realloc(the_sentence.wordcount()));
	for (Index w=0; w<the_sentence.wordcount(); ++w) {
		StringTemp curword = the_sentence.word(w);
		if (curword.len==0)  { continue; }
		else if (curword.len==1 && !isdigit(curword[0]) )  { continue; }
		the_options[w] = approximate_analysis_with_sikuiim (curword.str);
	}
	return OK;
}




/***************************************************************************/
/***********        Test Mode analysis                              ********/
/***************************************************************************/

void test_mode_analysis () {
	Sentence cursentence(500);
	Vector1<MorphOptionsWithSikui> cursentence_options;
	MorphOptionsWithSikui curoptions;
	StringTemp curword(30);
	MorphInfo correct_analysis;

	uint num_of_words = 0, num_of_mistakes=0, num_of_baseword_mistakes=0;
	for(;;) {
		DOEOFx(read_and_analyze_the_next_sentence (input, cursentence, cursentence_options));
		//skip_punctuation_and_singletons(input);				DOEOFx (curword.readword(input));
		//DOEOFx(cursentence.readline(input));  //  cursentence.insert_EOS_after_each_word();
		for (Index w=0; w<cursentence.wordcount(); ++w) {
			StringTemp curword = cursentence.word(w);
			if (curword.len==0)  { continue; }
			else if (curword.len==1 && !isdigit(curword[0]) )  { continue; }

			//curoptions = approximate_analysis_with_sikuiim (curword.str);
			curoptions = cursentence_options[w];

			skip_punctuation_and_singletons(correct_output);	DOEOFx (read(correct_output,correct_analysis));	

			if (curoptions.isempty())   { cerr<<curword<<" "; continue; }
			Index m = maxindex (curoptions);
			Sikui the_greatest_sikui = curoptions.sikui(m);
			MorphInfoCR the_analysis_with_the_greatest_sikui = curoptions.info(m);
			the_analysis_with_the_greatest_sikui.write_barur (cerr,curword.str);  cerr << " ";
			if (!identical_baseword(the_analysis_with_the_greatest_sikui,correct_analysis))  ++num_of_baseword_mistakes;
			if (!identical(the_analysis_with_the_greatest_sikui,correct_analysis))  ++num_of_mistakes;
			if (!identical(the_analysis_with_the_greatest_sikui,correct_analysis)) {  // log the mistake	
				logfile << "M#" << num_of_words << " (" << curword << "): "
						<< the_analysis_with_the_greatest_sikui << "    C\"L   " << correct_analysis << endl;
			}
			++num_of_words;
		}
	}
	LOG(logfile,"\nMSPR MILIM KWLL:            " << num_of_words << endl);
	LOG(logfile,"MSPR $GIAWT:                " << num_of_mistakes
			<< " (" << (num_of_mistakes*100./num_of_words) << "%)" << endl);
	LOG(logfile,"MSPR $GIAWT B&RK MILWNI:    " << num_of_baseword_mistakes 
			<< " (" << (num_of_baseword_mistakes*100./num_of_words) << "%)" << endl);
}



/***************************************************************************/
/***********        Batch Mode analysis                             ********/
/***************************************************************************/

void batch_mode_analysis () {
	MorphOptionsWithSikui curoptions;
	StringTemp curword(30);
	for(uint wordnum=0;; wordnum++) {
		DOEOFx(curword.readword(input));    char nextchar = input.get();
		if (curword.len==1)  { 
			cerr << curword;	
			if (!pelet_cafuf)  output << curword;
		}
		else if (curword.len>1) {
			curoptions = approximate_analysis_with_sikuiim (curword.str);
			if (curoptions.isempty())   { LOG(output,curword);	continue; }
			Index m = maxindex (curoptions);
			Sikui the_greatest_sikui = curoptions.sikui(m);
			MorphInfoCR the_analysis_with_the_greatest_sikui = curoptions.info(m);
			if (pelet_cafuf) {
				the_analysis_with_the_greatest_sikui.write_cafuf (output);
			}
			else {
				the_analysis_with_the_greatest_sikui.write_barur (output,curword.str);
			}
			the_analysis_with_the_greatest_sikui.write_barur (cerr,curword.str);
		}
		cerr << nextchar;
		output << nextchar;
	}
	cerr << "MSPR MILIM MNUTXOT: " << wordnum << endl; 
}


/***************************************************************************/
/***********        Interactive Mode analysis                       ********/
/***************************************************************************/


uint	wordnum=0,       // mispar ha-milim ha-me^u$$arot &ad ko
		curwordnum=0,       // mispar ha-mila ha-nokxit (curwordnum <= wordnum)
		mispar_tiqunim=0,        // meyda& statisti &al mispar ha-tiqunim $e-bicca& ha-mistamme$
		mispar_nituxim_xadajim=0;

StringTemp				milim_meujarot[10];    // maxziq ^et 10 ha-milim ha-axronot $e-^u$ru.
MorphOptionsWithSikui	nituxei_milim_meujarot[10];   // maxziq ^et ha-nituxim $el 10 ha-milim ha-axronot $e-^u$ru.
Index					nituxim_meujarim[10];   // maxziq ^et ha-nituxim $el 10 ha-milim ha-axronot $e-^u$ru.
StringTemp				simanei_pisuq_lifnei_milim[10];
bool					the_nitux_is_xadaj[10]; 

void update_database_and_cache (CStr thefullword, MorphOptionsWithSikuiCR theoptions) {
	update_sikuiim_in_approximate_database (thefullword,theoptions);
	for (Index i=0; i<min(10u,wordnum); ++i)
		if ( identical(milim_meujarot[i].str,thefullword) )
			nituxei_milim_meujarot[i] = theoptions;	
}



inline MorphInfoCR nitux_meujar (Index i) { 
	return nituxei_milim_meujarot[i%10].info(nituxim_meujarim[i%10]); }

void flush (uint i) { 
	// prepare the variables
	StringTempR thefullword = milim_meujarot[i%10];
	StringTempR thepisuq = simanei_pisuq_lifnei_milim[i%10];
	MorphOptionsWithSikui theoptions = nituxei_milim_meujarot[i%10];
	Index thecorrectindex = nituxim_meujarim[i%10];
	MorphInfoCR thecorrectinfo = theoptions.info(thecorrectindex);

	move_one_word_from_approximate_database_to_realistic_database (thefullword.str,thecorrectindex);
	xajev_sikuiim_lkol_hamilim_im_sbwsast (thecorrectinfo);

	// extend the lexicon, but only if the nitux is xadaj.
	if (the_nitux_is_xadaj[i%10])
		extend_lexicon (thefullword.str,thecorrectinfo);

	// output
	if (pelet_cafuf) {
		output << thepisuq;
		thecorrectinfo.write_cafuf (output);
	}
	else {
		output << thepisuq;
		thecorrectinfo.write_barur (output, thefullword.str);
	}
	thepisuq.truncate();
}



ifstream input2;  
void newline() {
	StringTemp curline (300);
	curline.readline(input2);
	cout << endl << curline << endl;
}



/********************* input morphinfo ****************************************/

Index select_txiliot_option (MorphOptionsCR theoptions, CStr thefullword) {
	LOOPVECTOR(;,theoptions,i)  {
		cout << "      " << i << ". ";
		if (theoptions[i].txiliot() > 0) {
			for (Index j=0; j < theoptions[i].txiliot(); ++j)
				cout << thefullword[j];
			cout << "-" << theoptions[i].baseword() << endl;
		}
		else 
			cout << thefullword << endl;
	}
	return Index (input_int("       MHW HNITUX HNKWN?",0,theoptions.count()-1));
}



void input_morphinfo (CStr thefullword, MorphInfo& theinfo) {
	MorphOptions the_txiliot_options = analyze_txiliot(thefullword);
	MorphInfo& selected_option = 
		the_txiliot_options.count()>1? 
			the_txiliot_options [ select_txiliot_option (the_txiliot_options,thefullword) ]:
			the_txiliot_options [0];
	uint the_num_of_txiliot = selected_option.txiliot();
	CStr the_word_without_txiliot = thefullword + the_num_of_txiliot;

	theinfo.settxiliot (selected_option);
	input_morphinfo_basic (theinfo);
	HeleqDiber hd=theinfo.heleqdiber();
	if (hd==ECEM || hd==POAL || hd==POAL_EZER || hd==TOAR || hd==MILAT_GUF || hd==MILAT_YAXAS) {
		StringTemp thebaseword = input_string ("MHW H&RK HMILWNI?",20,the_word_without_txiliot);
		theinfo.setbaseword (thebaseword.str);
	}
	else
		theinfo.setbaseword (the_word_without_txiliot);
}	


/********************* select option ****************************************/

void display_options (MorphOptionsWithSikuiCR theoptions, CStr thefullword) {
	LOOPVECTOR(;,theoptions,i)  {
		cout << "      " << i << ". ";
		theoptions.info(i).write_barur (cout, thefullword);
		cout << " (";
		theoptions.info(i).write_meforat(cout);
		cout << ")" << endl;
	}
	cout << "      " << theoptions.count() << ". " << "AP AXD MHN\"L" << endl;
}

Index select_option (MorphOptionsWithSikui& theoptions, CStr thefullword, bool& the_nitux_is_xadaj) {
	display_options (theoptions,thefullword);
	Index the_index_of_the_selected_analysis = Index (input_int("       MHW HNITUX HNKWN?",0,theoptions.count()));
	the_nitux_is_xadaj = ( the_index_of_the_selected_analysis >= theoptions.count() ) ; 
	if (!the_nitux_is_xadaj) {  // nivxar nitux $e-kvar qayam
		return the_index_of_the_selected_analysis; 
	}
	else {														    // nivxar nitux 'axer' (xada$)
		MorphInfo new_option;  input_morphinfo(thefullword,new_option);
		theoptions.addoption(new_option,1.);
		update_database_and_cache (thefullword,theoptions);
		lexlogfile << thefullword << ": " << new_option << endl;
		return theoptions.count()-1;
	}
}


/********************* select command ****************************************/


char select_command (CStr thefullword, MorphInfoCR theanalysis, bool question_mark) {
		cout << "   ";
		theanalysis.write_barur (cout, thefullword);  
		if (question_mark)  cout<<"?";  // if you are not sure that this is the right analysis -- say so!
		cout << "   " << flush;
		char c=prompt_from("[A=A$R T=TQN X=XZWR ' '=JURA-XD$H]","atx q"); cout<<endl;
		return c;
}


void get_command_from_user (Index curanalysis_index, bool question_mark=false) {
	for(;!sof;) {
		StringTempCR curword = milim_meujarot[curwordnum%10];
		CStr thefullword = curword.str;
		MorphOptionsWithSikui& curoptions = nituxei_milim_meujarot[curwordnum%10];
		MorphInfoCR curanalysis = curoptions.info(curanalysis_index);
		char c = select_command (thefullword,curanalysis,question_mark);
		switch (c) {
		case 'a':                  // ^a$$er ^et ha-nitux ha-nokxi
			nituxim_meujarim[curwordnum%10] = curanalysis_index;
			++curwordnum;
			if (wordnum+1==curwordnum) {
				++wordnum;
				if (wordnum>=10)
					flush (wordnum);
			}
			return;
		case 't': {                  // taqqen ^et ha-nitux
			MorphOptions newoptions = analyze (curword.str);
		//	if ( newoptions.count() > curoptions.count() ) {
				curoptions.set (newoptions);
				update_database_and_cache (curword.str,curoptions);
		//	}
			Index newanalysis_index = select_option (curoptions,thefullword, the_nitux_is_xadaj[curwordnum%10] );
			if (newanalysis_index != curanalysis_index)
				++mispar_tiqunim;
			if (the_nitux_is_xadaj[curwordnum%10])
				++mispar_nituxim_xadajim;
			curanalysis_index = newanalysis_index;
			question_mark = false;
			break; }
		case 'x': {                  // xazor mila axat axora
			if (curwordnum>=1 && curwordnum+9>wordnum) {
				uint prevwordnum = curwordnum = curwordnum-1;
				Index prevanalysis_index = nituxim_meujarim[prevwordnum%10];
				get_command_from_user(prevanalysis_index);
			}
			break; }
		case ' ':
			newline();
			break;
		case 'q':
			sof=true;
		}
	}
}


void interactive_mode_analysis() {
	Sentence cursentence(500);
	Vector1<MorphOptionsWithSikui> cursentence_options;
	MorphOptionsWithSikui curoptions;
	open_infile (variable(0),input2);
	for (Index j=0; j<10; ++j)   simanei_pisuq_lifnei_milim[j].alloc(20);

	newline();
	for(sof=false, mispar_tiqunim=mispar_nituxim_xadajim=0; !sof; ) {
		DOEOFx(read_and_analyze_the_next_sentence (input, cursentence, cursentence_options));
		//DOEOFx(curword.readword(input));    char nextchar = input.get();
		//DOEOFx(cursentence.readline(input));  //  cursentence.insert_EOS_after_each_word();
		for (Index w=0; w<cursentence.wordcount(); ++w) {
			StringTemp curword = cursentence.word(w);
			StringTemp space = cursentence.space_after_word(w);
			simanei_pisuq_lifnei_milim[wordnum%10].append ( space.str ); 
			if (curword.len==0)  { continue; }
			else if (curword.len==1 && !isdigit(curword[0]) )  { 
				cerr<<"   "<<curword<<endl; 
				simanei_pisuq_lifnei_milim[wordnum%10].append(curword.str); 
				continue; 
			}
			curoptions = cursentence_options[w];
			//curoptions = approximate_analysis_with_sikuiim (curword.str);
			//cout<<endl<<"!"<<curoptions<<"!"<<endl;
			if (curoptions.isempty()) continue;
			Sikui sikui_saf = sikui ( pow(1./curoptions.count(),0.63) );
			Index m = maxindex (curoptions);
			Sikui the_greatest_sikui = curoptions.sikui(m);
			//MorphInfoCR the_analysis_with_the_greatest_sikui = curoptions.info(m);
			milim_meujarot[wordnum%10] = curword;
			nituxei_milim_meujarot[wordnum%10]  = curoptions;
			get_command_from_user (m, the_greatest_sikui<sikui_saf);
		}
	}

	/* before you leave, don't forget flush all the words that remained in the buffer. */
	for (Index i=wordnum+1; i<wordnum+10; ++i) {
		if (i>=10)
			flush(i);
	}

#pragma warning (disable: 4244)
	float axuz_tiqunim = 100.*mispar_tiqunim/wordnum;
	float axuz_xadajim = 100.*mispar_nituxim_xadajim/wordnum;

	LOG(logfile,"MSPR MILIM MNUTXOT: " << wordnum << endl 
		<< "MSPR TIQWNIM: " << mispar_tiqunim << " (" << axuz_tiqunim << "%)" << endl
		<< "MSPR NITWXIM XD$IM: " << mispar_nituxim_xadajim << " (" << axuz_xadajim << "%)" << endl);

}


/***************************************************************************/
/***********        The Main Program                                ********/
/***************************************************************************/



void main (int argc, char* argv[]) {
	lexicon_is_creative=false;
	set_synopsis ("\nInteractive mode:          MA2 *.txt *.out [options]\n"
				  "One word analysis mode:    MA2 *.txt *.out /w word [options]\n"
				  "Batch mode:                MA2 *.txt *.out /b [options]\n"
				  "Compare mode:              MA2 *.txt *.to  /q [options]\n"
				  "    (options include:  [/l lex-path] [/t tav-path] [/g log-path] [/a analysis-filename.NTX] [/s analysis-with-sikuiim-filename.NTS] [/c=cafuf] [/h=hosef])\n");
	parse_command_line (argc,argv,2,2,"ltwasg","bchq");

	initialize_the_analyzer(option('t')==NULL? ".": option('t'),
							option('l')==NULL? ".": option('l') );
	log_path = option('g')==NULL? ".": option('g');
	atxel_database (variable(0),option('a'),option('s'));
	log_the_database(0);

	pelet_cafuf = swtch('c');

	open_lexlogfile();

	if (option('w')!=NULL) {
		StringTemp main_word;
		main_word.set (option('w'));
		open_logfile(1);
		xajev_sikuiim (main_word.str,2);
	}

	if (option('s')==NULL) {
		for (uint i=0; i<1; ++i) {          // only one pass now.
			cerr << "pass #" << i << endl;
			open_logfile(i+2);
			xajev_sikuiim_lkol_hamilim ();
			logfile.close();
		}
	}
	log_the_database(3);
	if (swtch('h')) {               // hosef!
		read_partial_output (variable(0),variable(1));
		open_outfile(variable(1),output,ios::app);
	}
	else if (swtch('q')) {          // bdoq
		open_infile (variable(0),input);
		open_infile (variable(1),correct_output);
	}
	else {
		open_infile (variable(0),input);
		open_outfile (variable(1),output,0);
	}
	log_the_database(4);

	open_logfile(5);
	if (swtch('b')) 
		batch_mode_analysis();
	else if (swtch('q'))
		test_mode_analysis();
	else
		interactive_mode_analysis();
	logfile.close();
	log_the_database(6);

	lexlogfile.close();

}
