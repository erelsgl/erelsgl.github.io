/* sntncsik.cpp -- 
	Sentence Options with Sikuiim:
		a structure that holds all options to analyze a sentence, with "sikui" attached to 
		each option.
*/

#include <morph/sntncsik.h>
#include <morph/taxbir.h>
#include <cpplib/sentence.h>
#include <cpplib/BFS.hxx>



/****************  implementation of create_sentence_options_from_eachword_options  ********************/
/****************  implementation of create_sentence_options_from_eachword_options  ********************/
/****************  implementation of create_sentence_options_from_eachword_options  ********************/

/******            struct SentenceOptionIdentifier;                 ******/

struct SentenceOptionIdentifier;
typedef const SentenceOptionIdentifier&  SentenceOptionIdentifierCR;
struct SentenceOptionIdentifier: public Vector1<Index> {
	double my_realsikui;
	ArrayOfMOWS my_eachword_options;
	SentenceOptionIdentifier (): Vector1<Index>() {}
	SentenceOptionIdentifier (const ArrayOfMOWS& eachword_options) {
		my_eachword_options = eachword_options;
		reset (my_eachword_options.count()); 
	}
	void zero() {
		LOOPTHISVECTOR(;,w)  { 
			at(w) = 0;
		}
	}
	void calculate_sikui () {
		LOOPTHISVECTOR(my_realsikui=1.,w)  { 
			my_realsikui *= realsikui(w);
		}
	}
	MorphInfoCR wordinfo (Index the_wordnum) const {	
		return the_wordnum<count()?
			my_eachword_options[the_wordnum].info(at(the_wordnum)):
			miNQUDA;
	}
	double realsikui (Index the_wordnum) const {
		return my_eachword_options[the_wordnum].realsikui(at(the_wordnum)); 
	}
	void create_sentenceinfo_mufrad (SentenceInfo& the_sentenceinfo, double& the_realsikui) const {
		the_sentenceinfo.remove_all();
		LOOPTHISVECTOR(the_realsikui=1.,w)  { 
			the_sentenceinfo.hafred_whosef ( wordinfo(w) ); 
			the_realsikui *= realsikui(w);	
		}
	}
	void create_sentenceinfo_lo_mufrad (SentenceInfo& the_sentenceinfo, double& the_realsikui) const {
		the_sentenceinfo.remove_all();
		LOOPTHISVECTOR(the_realsikui=1.,w)  { 
			the_sentenceinfo.append ( wordinfo(w) ); 
			the_realsikui *= realsikui(w);	
		}
	}
	friend void duplicate (SentenceOptionIdentifier& to, SentenceOptionIdentifierCR from);
};

DEFINE_INLINE_IO_OPERATORS(SentenceOptionIdentifier);

void duplicate (SentenceOptionIdentifier& to, SentenceOptionIdentifierCR from) {
	duplicate (to.myinfo, from.myinfo);
	to.my_eachword_options = from.my_eachword_options;
	to.my_realsikui = from.my_realsikui;
}


bool identical (SentenceOptionIdentifierCR a, SentenceOptionIdentifierCR b) {
	if (a.my_realsikui!=b.my_realsikui)  return false;
	if (a.count()!=b.count())  return false;
	LOOPVECTOR(;,a,w) 
		if (a[w] != b[w]) return false;
	return true;
}




/**********          SOI-BFS               **********/

extern ofstream sentencelogfile;



struct SentenceConverter: public BestFirstSearcher<SentenceOptionIdentifier> {
	ArrayOfMOWS my_eachword_options;
	uint my_DNOSO;   // the desired number of sentence options
	SentenceOptionsWithSikui* my_sentence_options_p;
	#define my_sentence_options (*my_sentence_options_p)
	Vector1<double> my_sentence_options_sikuiim;	// DNOSO ha-sikuiim ha-@obim bioter &bur ha-mi$pa@ ha-nokxi  
	Index my_NOSOFSF;            // The number of sentence-options found so far [  0 <= my_NOSOFSF < my_DNOSO  ]

	SentenceInfo cur_sentence_option_mufrad;
	//SentenceInfo cur_sentence_option_lo_mufrad;


	SentenceConverter (ArrayOfMOWS the_eachword_options,	uint the_DNOSO,  SentenceOptionsWithSikui& the_sentence_options):
		BestFirstSearcher<SentenceOptionIdentifier> (the_eachword_options.count()) 
	{
		my_eachword_options = the_eachword_options;
		my_DNOSO = the_DNOSO;
		my_NOSOFSF = 0;
		my_sentence_options_p = &the_sentence_options;
		free (my_sentence_options);  my_sentence_options.realloc(the_DNOSO);
		my_sentence_options_sikuiim.realloc (the_DNOSO);
		zero (my_sentence_options_sikuiim);	
		LOOPVECTOR (;,the_eachword_options,w0) 
			my_eachword_options[w0].sader_lfi_sikui_bseder_yored();
		sentencelogfile<<my_eachword_options<<endl;
	}

	
	double score (SentenceOptionIdentifierCR cur_soi)  {
		return cur_soi.my_realsikui; }


	status enqueue_first_nodes() {
		SentenceOptionIdentifier first_soi (my_eachword_options);
		first_soi.zero();      first_soi.calculate_sikui();
		return enqueue(first_soi);
	}


	status enqueue_next_node (SentenceOptionIdentifierCR cur_soi, Index w) {
		if (w>=cur_soi.count()) return OK;
		// w is the "direction".
		if (cur_soi[w]+1 < cur_soi.my_eachword_options[w].count()) {
			SentenceOptionIdentifier new_soi;
			duplicate (new_soi,cur_soi);
			new_soi[w] = cur_soi[w]+1; 
			new_soi.calculate_sikui();
			// ^im ha-cerrup lo^ xuqi -- nasse lhosip ^et ha-ba^im ^axaraw 
			bool 
				cx1 = haceruf_xuqi(new_soi.wordinfo(w-1),new_soi.wordinfo(w)),
				cx2 = haceruf_xuqi(new_soi.wordinfo(w),new_soi.wordinfo(w+1));
			if (cx1 && cx2) 
				return enqueue(new_soi); 
			else if (!cx1 && cx2) {  
				DOr(enqueue_next_node (new_soi,w-1));
				return enqueue_next_node (new_soi,w);
			}
			else if (cx1 && !cx2) {  
				DOr(enqueue_next_node (new_soi,w));
				return enqueue_next_node (new_soi,w+1);
			}
			else if (!cx1 && !cx2) {  
				return enqueue_next_node (new_soi,w);
			}
			return EINVAL;         // I can't reach here anyway.
		}
		else return OK;
	}

	status enqueue_next_nodes(SentenceOptionIdentifierCR cur_soi) {
		sentencelogfile<<my_NOSOFSF<<endl<<cur_soi<<endl;
		cur_soi.create_sentenceinfo_mufrad( cur_sentence_option_mufrad, my_sentence_options_sikuiim[my_NOSOFSF] );
		sentencelogfile<<cur_sentence_option_mufrad<<endl;
		if (hamijpat_xuqi(cur_sentence_option_mufrad)) {
			cur_soi.create_sentenceinfo_lo_mufrad( my_sentence_options.info(my_NOSOFSF), my_sentence_options_sikuiim[my_NOSOFSF] );
			++my_NOSOFSF;  if (my_NOSOFSF>=my_DNOSO) return EOF;                        
		}

		LOOPVECTOR (;,my_eachword_options,w) 
			DOr(enqueue_next_node (cur_soi,w));

		return OK;
	}


	status finish () {
		if (my_NOSOFSF==0) return ENOTFOUND;        // couldn't create any legal option!
		my_sentence_options.truncate(my_NOSOFSF);
		my_sentence_options_sikuiim.truncate(my_NOSOFSF);
		//for (; my_NOSOFSF<my_DNOSO; ++my_NOSOFSF)
		//	my_sentence_options_sikuiim[my_NOSOFSF] = 0.;

		normalize (my_sentence_options_sikuiim,1.);
		for (Index i=0; i<my_NOSOFSF; ++i) 
			my_sentence_options.sikui(i) = sikui(my_sentence_options_sikuiim[i]);
		return OK;
	}


	~SentenceConverter () {
		free (my_sentence_options_sikuiim);
		free (cur_sentence_option_mufrad);
	}

};



/******************  void create_sentence_options_from_eachword_options  ***********************/

status convert_eachword_options_to_sentence_options (
	ArrayOfMOWS the_eachword_options,
	uint the_DNOSO,     // desired number of sentence-options
	SentenceOptionsWithSikui& the_sentence_options
) {
	SentenceConverter the_converter(the_eachword_options,the_DNOSO,the_sentence_options);
	return the_converter.run();
}






/******************  SNTNCSIK self-test  ***********************/
/******************  SNTNCSIK self-test  ***********************/
/******************  SNTNCSIK self-test  ***********************/

#ifdef TEST_SNTNCSIK


#include <morph/alghist.h>
#include <morph/mn.h>
#include <morph/tiqun2.h>
#include <morph/hpmaio2.h>

//#define LOG_PATH "..\\..\\..\\harc\\"
#define LOG_PATH "c:\\winnt\\profiles\\harc\\"

void atxel_klali_s() {
	atxel_global_database (NULL,NULL,LOG_PATH "harc10.nts");
	atxel_local_database (NULL,NULL,LOG_PATH "harc10a.nts");
	atxel_tiqunim(LOG_PATH); adken_tiqunim (LOG_PATH "harc10.to2"); 
	ktov_tiqunim(LOG_PATH);
	adken_monei_zugot_nituxim (LOG_PATH "harc10.to2");
	open_logfile(6); ktov_monei_zugot_nituxim(logfile); logfile.close();
}




void bdoq() {
	Sentence cursentence(500);
	ArrayOfMOWS cursentence_eachword_options;
	SentenceOptionsWithSikui cursentence_options; // 8 ha-^ep$aruiot ha-@obot bioter &bur ha-mi$pa@ ha-nokxi
	for(;;) {
		//read_and_analyze_the_next_sentence (input, cursentence, cursentence_eachword_options);
		DOEOFx(read_and_analyze_the_next_sentence (input, cursentence, cursentence_eachword_options));
		//LOG (logfile, cursentence);
		taqen_sikuiim_zugot (cursentence_eachword_options);
		convert_eachword_options_to_sentence_options (cursentence_eachword_options, 8, cursentence_options);
		writeln (logfile, cursentence_options);
		logfile << endl << endl << endl;
	}
}

void main (void) {
	log_path = "..\\..\\..\\harc";
	atxel_klali_s();
	open_logfile(0);
	open_sentencelogfile(log_path);
	open_infile ("..\\..\\..\\harc\\harc10a.txt",input);
	bdoq();
}

#endif
