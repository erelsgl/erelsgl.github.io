/* tiqunmn2.cpp -- tiqun lfi monei-nituxim */

#include <morph/tiqunmn2.h>
#include <morph/mone-nit.h>
#include <morph/hpmaio.h>

enum SugMoneNituxim { 
	mnKLALI=0, 
	mnMAQOR,
	mnTOARPOAL, 
	mnMILATXIBUR, 
	mnMILATJEELA, 
	mnMILATYAXAS_BLISIOMET, mnMILATYAXAS_IMSIOMET,
	mnMILIT,
	mnAXRON 
}; 


/**********************************************************************/
/*******            Mone Nituxim Axrei                          *******/
/**********************************************************************/

MoneNituxim mn_axrei[mnAXRON];

void atxel_monei_nituxim_axrei (CStr correct_analysis_filename) {
	ifstream correct_analysis;
	cerr << "reading correct analysis file " << correct_analysis_filename << endl;
	open_infile (correct_analysis_filename,correct_analysis);
	MorphInfo curanalysis;
	for(;;) {
		skip_spaces_and_stars(correct_analysis);  
		if (correct_analysis.eof()) break;
		DOEOFx (read(correct_analysis,curanalysis));
		for (Index i=0; i<(sizeof mn_axrei)/(sizeof MoneNituxim); ++i)
			mn_axrei[i].setcount(curanalysis.mila_rijona_info(),0);
	}
	correct_analysis.close();
}

void hosef_lmonei_hanituxim_axrei (MorphInfoCR haqodem, MorphInfoCR hanokxi) {
	mn_axrei[mnKLALI].add(hanokxi, SIKUI1, dimion);
	if (haqodem.zman()==MAOQR)    mn_axrei[mnMAQOR].add(hanokxi, SIKUI1, dimion);
	else switch (haqodem.heleqdiber()) {
	case TOAR_POAL: mn_axrei[mnTOARPOAL].add(hanokxi, SIKUI1, dimion); break;
	case MILAT_YAXAS:
		if (haqodem.has_siomet()) mn_axrei[mnMILATYAXAS_IMSIOMET].add(hanokxi, SIKUI1, dimion);
		else                      mn_axrei[mnMILATYAXAS_BLISIOMET].add(hanokxi, SIKUI1, dimion);
		break;
	case MILAT_XIBUR: mn_axrei[mnMILATXIBUR].add(hanokxi, SIKUI1, dimion); break;
	case MILAT_JEELA: mn_axrei[mnMILATJEELA].add(hanokxi, SIKUI1, dimion); break;
	case MILIT: mn_axrei[mnMILIT].add(hanokxi, SIKUI1, dimion); break;
	}
}


void adken_monei_nituxim_axrei (CStr correct_analysis_filename) {
	ifstream correct_analysis;
	cerr << "reading correct analysis file " << correct_analysis_filename << endl;
	open_infile (correct_analysis_filename,correct_analysis);

	MorphInfo curanalysis;
	MorphInfo prevanalysis;
	for(;;) {
		skip_spaces_and_stars(correct_analysis);  
		if (correct_analysis.eof()) break;
		DOEOFx (read(correct_analysis,curanalysis));
		hosef_lmonei_hanituxim_axrei (prevanalysis,curanalysis);
		prevanalysis = curanalysis;
	}
	correct_analysis.close();
}


void ktov_monei_nituxim_axrei (ostream& out) {
	for (Index i=0; i<(sizeof mn_axrei)/(sizeof MoneNituxim); ++i) {
		out << "%%% MONE NITUXIM AXREI " << i << endl;
		writeln (out, mn_axrei[i]);
		out << endl << endl;
	}
}

status qra_monei_nituxim_axrei (istream& in) {
	for (Index i=0; i<(sizeof mn_axrei)/(sizeof MoneNituxim); ++i) {
		skip_comments (in,'%');
		DOr( read (in, mn_axrei[i]) ) ;
	}
	return OK;
}

double relative_count_axrei (MorphInfoCR haqodem, MorphInfoCR hanokxi) {
	double thecount = mn_axrei[mnKLALI].relative_count(hanokxi);
	if (haqodem.zman()==MAQOR)  thecount += mn_axrei[mnMAQOR].relative_count(hanokxi);
	else switch (haqodem.heleqdiber()) {
	case TOAR_POAL: thecount += mn_axrei[mnTOARPOAL].relative_count(hanokxi); break;
	case MILAT_YAXAS: 
		if (haqodem.has_siomet()) thecount += mn_axrei[mnMILATYAXAS_IMSIOMET].relative_count(hanokxi);
		else                      thecount += mn_axrei[mnMILATYAXAS_BLISIOMET].relative_count(hanokxi);
		break;
	case MILAT_XIBUR: thecount += mn_axrei[mnMILATXIBUR].relative_count(hanokxi); break;
	case MILAT_JEELA: thecount += mn_axrei[mnMILATJEELA].relative_count(hanokxi); break;
	case MILIT: thecount += mn_axrei[mnMILIT].relative_count(hanokxi); break;
	default: thecount += thecount;
	}
	return thecount/2
}



/**********************************************************************/
/*******            Mone Nituxim Lipnei                         *******/
/**********************************************************************/


MoneNituxim mn_lipnei[mnAXRON];

void atxel_monei_nituxim_lipnei (CStr correct_analysis_filename) {
	ifstream correct_analysis;
	cerr << "reading correct analysis file " << correct_analysis_filename << endl;
	open_infile (correct_analysis_filename,correct_analysis);

	MorphInfo curanalysis;
	for(;;) {
		skip_spaces_and_stars(correct_analysis);  
		if (correct_analysis.eof()) break;
		DOEOFx (read(correct_analysis,curanalysis));
		for (Index i=0; i<(sizeof mn_lipnei)/(sizeof MoneNituxim); ++i)
			mn_lipnei[i].setcount(curanalysis.mila_rijona_info(),0);
	}
	correct_analysis.close();
}

void hosef_lmonei_hanituxim_lipnei (MorphInfoCR hanokxi, MorphInfoCR haba) {
	mn_lipnei[mnKLALI].add(hanokxi, SIKUI1, dimion);
	if (haba.zman()==MAOQR)    mn_lipnei[mnMAQOR].add(hanokxi, SIKUI1, dimion);
	else switch (haba.heleqdiber()) {
	case TOAR_POAL: mn_lipnei[mnTOARPOAL].add(hanokxi, SIKUI1, dimion); break;
	case MILAT_YAXAS:
		if (haba.has_siomet()) mn_lipnei[mnMILATYAXAS_IMSIOMET].add(hanokxi, SIKUI1, dimion);
		else                   mn_lipnei[mnMILATYAXAS_BLISIOMET].add(hanokxi, SIKUI1, dimion);
		break;
	case MILAT_XIBUR: mn_lipnei[mnMILATXIBUR].add(hanokxi, SIKUI1, dimion); break;
	case MILAT_JEELA: mn_lipnei[mnMILATJEELA].add(hanokxi, SIKUI1, dimion); break;
	case MILIT: mn_lipnei[mnMILIT].add(hanokxi, SIKUI1, dimion); break;
	}
}


void adken_monei_nituxim_lipnei (CStr correct_analysis_filename) {
	ifstream correct_analysis;
	cerr << "reading correct analysis file " << correct_analysis_filename << endl;
	open_infile (correct_analysis_filename,correct_analysis);

	MorphInfo curanalysis;
	MorphInfo prevanalysis;
	for(;;) {
		skip_spaces_and_stars(correct_analysis);  
		if (correct_analysis.eof()) break;
		DOEOFx (read(correct_analysis,curanalysis));
		hosef_lmonei_hanituxim_lipnei (prevanalysis,curanalysis);
		prevanalysis = curanalysis;
	}
	correct_analysis.close();
}


void ktov_monei_nituxim_lipnei (ostream& out) {
	for (Index i=0; i<(sizeof mn_lipnei)/(sizeof MoneNituxim); ++i) {
		out << "%%% MONE NITUXIM LIPNEI " << i << endl;
		writeln (out, mn_lipnei[i]);
		out << endl << endl;
	}
}

status qra_monei_nituxim_lipnei (istream& in) {
	for (Index i=0; i<(sizeof mn_lipnei)/(sizeof MoneNituxim); ++i) {
		skip_comments (in,'%');
		DOr( read (in, mn_lipnei[i]) ) ;
	}
	return OK;
}

double relative_count_lipnei (MorphInfoCR hanokxi, MorphInfoCR haba) {
	double thecount = mn_lipnei[mnKLALI].relative_count(hanokxi);
	if (haba.zman()==MAQOR)  thecount += mn_lipnei[mnMAQOR].relative_count(hanokxi);
	else switch (haba.heleqdiber()) {
	case TOAR_POAL: thecount += mn_lipnei[mnTOARPOAL].relative_count(hanokxi); break;
	case MILAT_YAXAS: 
		if (haba.has_siomet()) thecount += mn_lipnei[mnMILATYAXAS_IMSIOMET].relative_count(hanokxi);
		else                      thecount += mn_lipnei[mnMILATYAXAS_BLISIOMET].relative_count(hanokxi);
		break;
	case MILAT_XIBUR: thecount += mn_lipnei[mnMILATXIBUR].relative_count(hanokxi); break;
	case MILAT_JEELA: thecount += mn_lipnei[mnMILATJEELA].relative_count(hanokxi); break;
	case MILIT: thecount += mn_lipnei[mnMILIT].relative_count(hanokxi); break;
	default: thecount += thecount;
	}
	return thecount/2
}


/**********************************************************************/
/*******            Monei Nituxim -- klali                      *******/
/**********************************************************************/

void atxel_monei_nituxim(CStr correct_analysis_filename) {
	atxel_monei_nituxim_axrei (correct_analysis_filename);
	atxel_monei_nituxim_lipnei (correct_analysis_filename);
}


void adken_monei_nituxim(CStr correct_analysis_filename) {
	adken_monei_nituxim_axrei (correct_analysis_filename);
	adken_monei_nituxim_lipnei (correct_analysis_filename);
}


void ktov_monei_nituxim(ostream& out) {
	ktov_monei_nituxim_axrei (out);
	ktov_monei_nituxim_lipnei (out);
}

status qra_monei_nituxim(istream& in) {
	qra_monei_nituxim_axrei (in);
	qra_monei_nituxim_lipnei (in);
	return OK;
}

void qra_monei_nituxim (CStr path) {
	ifstream input;
	open_infile_with_messages (path,input);
	DOx(qra_monei_nituxim (input));  
	input.close();
}



/*****************************************************************/
/*****                   taqen_sikuiim                        ****/
/*****************************************************************/

double
	mijqal_lx=5.77, 
	mijqal_ly=15.2,
	mijqal_ax=0,
	mijqal_ay=8.6;


void taqen_sikuiim_lfi_monei_nituxim (ArrayOfMOWS& the_eachword_options) {
	extern ofstream tiqunimlogfile;
	if (the_eachword_options.count()<2) return;
	Index w;
	for (w=0; w<the_eachword_options.count()-1; ++w) {   // xappe$ zug $e-mat^im l-^axat ha-tabniot
		MorphOptionsWithSikui options_x = the_eachword_options[w], options_y = the_eachword_options[w+1];
		ArrayOfSikuiim tosafot_x, tosafot_y;
		init(tosafot_x,options_x.count()); init(tosafot_y,options_y.count());
		if (options_x.count()<=1 && options_y.count()<=1) continue;  // There is no point in adjusting the sikuiim when there is only one option!
		tiqunimlogfile << options_x << " --- " << options_y << endl;

		Sikui the_tosefet;
		LOOPVECTOR(;,options_x,ox) {
			LOOPVECTOR(;,options_y,oy) {
				MorphInfo info_x = options_x.info(ox).mila_axrona_info(), info_y = options_y.info(oy).mila_rijona_info();
				double rcl = relative_count_lipnei (info_x,info_y);
				the_tosefet = product (options_x.sikui(ox), options_y.sikui(oy), rcl ) ;
				tosafot_x[ox] += the_tosefet*mijqal_lx;
				tosafot_y[oy] += the_tosefet*mijqal_ly;
				double rca = relative_count_axrei (info_x,info_y);
				the_tosefet = product (options_x.sikui(ox), options_y.sikui(oy), rca ) ;
				tosafot_y[oy] += the_tosefet*mijqal_ax;
				tosafot_x[ox] += the_tosefet*mijqal_ay;
			}
		}
		options_x.add (tosafot_x);  options_y.add (tosafot_y);
		tiqunimlogfile << tosafot_x << " --- " << tosafot_y << endl;
		tiqunimlogfile << options_x << " --- " << options_y << endl;
	}
}


