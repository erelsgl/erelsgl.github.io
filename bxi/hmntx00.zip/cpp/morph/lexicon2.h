/* lexicon2.h */

#ifndef __LEXICON2_H
#define __LEXICON2_H

#include <morph/morphopt.h>


/* editing the lexicon */
status add_word_to_lexicon (CStr theword, HeleqDiber thehd);

status add_ecem_to_lexicon (CStr theword, uint sug1=0, Meen meen=NONE);

status add_toar_to_lexicon (CStr theword, uint sug1=0);

status add_poal_to_lexicon (CStr theword);
status add_poal_1_to_lexicon (CStr theword, uint sug1);
status add_poal_2_to_lexicon (CStr theword, uint sug2);

status add_jem_prati_to_lexicon (CStr theword, Meen meen=NONE);

status add_milit_to_lexicon (CStr thefullword, MorphInfoCR theinfo);     // used for milat-yaxas and milat-guf and mispar
status add_miuxd_to_lexicon (CStr thefullword, MorphInfoCR theinfo);     // used for miuxdim

status add_yoce_dofen (CStr theword, MorphOptions theoptions);


/* queries */

bool lexicon_contains_word (CStr theword, HeleqDiber thehd, uint* thesug1=NULL, uint* thesug2=NULL);
inline bool lexicon_contains_milit (CStr theword, HeleqDiber thehd) 
	{ return lexicon_contains_word(theword,thehd); }

bool lexicon_contains_poal (CStr theword, uint* thesug1=NULL, uint* thesug2=NULL);
bool lexicon_contains_poal_1 (CStr theword, uint thesug1);
bool lexicon_contains_poal_2 (CStr theword, uint thesug2);

bool lexicon_contains_ecem (CStr theword, uint thesug1=0, Meen* themeen=NULL);
bool lexicon_contains_ecem (CStr theword, uint* thesug1, Meen* themeen=NULL);

bool lexicon_contains_toar (CStr theword, uint thesug1=0);

bool lexicon_contains_jem_prati (CStr theword, Meen* themeen=NULL);

bool lexicon_contains_milat_yaxas (CStr thefullword, MorphInfoR theinfo);
bool lexicon_contains_milat_guf (CStr thefullword, MorphInfoR theinfo);
bool lexicon_contains_mispar (CStr thefullword, MorphInfoR theinfo);
bool lexicon_contains_poal_ezer (CStr thefullword, MorphInfoR theinfo);

bool lexicon_contains_ecem_miuxd (CStr theword, MorphInfoR theinfo);
bool lexicon_contains_poal_miuxd (CStr thefullword, Zman thezman, MorphInfoR theinfo);
bool lexicon_contains_toar_miuxd (CStr theword, MorphInfoR theinfo);

bool lexicon_contains_yoce_dofen (CStr thefullword, MorphOptions& theoptions);

extern bool lexicon_is_creative;

bool has_ntiat_jayakut_miuxedet (CStr the_ecem);


/* IO */
// read/write the simple lexicon
// use Format("T") for table format, Format("D") for dense format.
//status read_the_lexicon (istream& in, Format format);
//void   write_the_lexicon (ostream& out, Format format);  

void   read_the_lexicon (CStr thepath, Format format="T");
void   write_the_lexicon (CStr thepath, Format format="T");  


#endif
