/* sntncinf.h -- 
	Sentence Info:
		a structure that holds information about a whole sentence.

*/

#ifndef __SNTNCINF_H
#define __SNTNCINF_H

#include <morph/morphinf.h>
#include <cpplib/array2.hxx>

struct SentenceInfo: public Array2<MorphInfo> {
	void operator= (int ZERO) { Array2<MorphInfo>::operator=(0); }
	status hafred ();  // mafrid ^et ha-txiliot mi-hamilla.
	status hafred (SentenceInfo& the_result) const;  // mafrid ^et ha-txiliot mi-hamilla.
	status hafred_whosef (MorphInfoCR theinfo);
	status read (istream& in, CStr stopper=".");
	void write (ostream& out) const;
};

typedef const SentenceInfo& SentenceInfoCR;

inline void write (ostream& out, SentenceInfoCR theinfo, Format format="") {
	write (out, (Array2<MorphInfo>)theinfo, Format(" ")); }

inline status read  (istream& in, SentenceInfo& theinfo, Format format="") {
	return read (in,(Array2<MorphInfo>)theinfo, Format(" ")); }

//inline void copy (SentenceInfo* to, const SentenceInfo* from, uint count) { memcpy(to,from,count*sizeof(SentenceInfo)); }
//inline void duplicate (SentenceInfo& to, const SentenceInfo& from) { to=from; }
//inline void free (SentenceInfo& m) { };

inline bool identical (SentenceInfoCR a, SentenceInfoCR b) {
	if (a.count()!=b.count()) return false;
	LOOPVECTOR(;,a,i)  if (!identical(a[i],b[i])) return false;
	return true;
}


DEFINE_INLINE_IO_OPERATORS(SentenceInfo)

#endif
