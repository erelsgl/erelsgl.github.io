/* hpma-aux.h -- auxiliary routines for HPMA */


#include <cpplib/sentence.h>
#include <morph/sntncinf.h>

