/* lexiconb.cpp -- lexicon-bi@utyim */

#include <morph/lexiconb.h>
#include <morph/cimcumim.h>

/********************************************************************/
/*************     Bituy, and the lexicon structures  ***************/
/********************************************************************/

#include <cpplib/pair.hxx>
#include <cpplib/trie0.hxx>


status read  (istream& in, Bituy& theinfo, Format format="") {
	skip_comments(in,'%');
	DOr (read (in,theinfo.x()) );
	DOr (read (in,theinfo.y()) );
	return OK;
}



Trie0<Bituy> lexicon_bituyim;


/********************************************************************/
/*						queries										*/
/********************************************************************/

bool yej_bituy_jematxil_b (MorphInfoCR x) {  /*** LO MEUDKAN! ***/
	Bituy b;  
	if (!lexicon_bituyim.contains(x.baseword(),b))  return false;
	else return b.x().match(x);
}


bool yej_bituy (MorphInfoCR x, MorphInfoCR y, Bituy& b) {
	if (lexicon_bituyim.contains( concat_bw(x,y).str, b ) ) 
		return b.x().match(x) && b.y().match(y);
	else if (lexicon_bituyim.contains(x.baseword(), b))  
		return b.x().match(x) && b.y().match(y);
	else return false;
}

bool yej_bituy (MorphInfoCR x, MorphInfoCR y) {
	Bituy b;  
	return yej_bituy (x,y,b);
}



/********************************************************************/
/*						EDITING										*/
/********************************************************************/

status add_bituy (BituyCR b) { 
	if (b.y().baseword_xajuv)
		return lexicon_bituyim.insert (b.bitui_str().str, b); 
	else
		return lexicon_bituyim.insert (b.x().baseword(), b); 
}		

status add_bituy (MorphInfoPatternCR x, MorphInfoPatternCR y) {
	return add_bituy (Bituy(x,y)); }



/********************************************************************/
/*						IO											*/
/********************************************************************/

void write_lexicon_bituyim(ostream& out) {
	out << '{' << endl;
	for (Trie0<Bituy>::Cursor c(lexicon_bituyim); c.isvalid(); ++c) {
		writeln (out, c.item());
	}
	out << '}' << endl;
}


status read_lexicon_bituyim (istream& in) {
	DOr(testchar(in,'{'));
	for (Index i=0;;++i) {
		Bituy curdata;        
		if (testchar(in,'}')==OK) { return OK; }
		in.eatwhite();
		DOr ( read (in, curdata ) );
		if (OK!=add_bituy (curdata)) {
			int i=0;
		}
	}
	DOr(testchar(in,'}'));
	return OK;
}

void   write_the_lexicon_bituyim (CStr thepath, Format format) {
	ofstream out;
	StringTemp thefilename;
	thefilename = concat_path_to_filename(thepath,"lex20.ma");
	cerr << "writing lexicon file " << thefilename << endl;
	DOx(open(thefilename.str,out,0));
	out<<"\n%\n%\n% LEXICON BI@UYIM\n%\n%\n";
	write_lexicon_bituyim(out);
	out.close();
}

void read_the_lexicon_bituyim (CStr thepath, Format format) {
	ifstream in;
	StringTemp thefilename;
	thefilename = concat_path_to_filename(thepath, "lex20.ma");
	cerr << "reading lexicon file " << thefilename << endl;
	DOx(open(thefilename.str,in));
	skip_comments(in,'%');
	DOx(read_lexicon_bituyim(in));
	in.close();
}


#ifdef TEST_LEXICONB

void main (void) {
	read_the_lexicon_bituyim ("c:\\harc");
	write_the_lexicon_bituyim ("c:\\cpp");
}

#endif
