/* tiqunmn.h -- tiqqun ha-sikkuyim lfi ha-heq$er, b&ezrat monei-nittuxim */

#ifndef __TIQUNMN_H
#define __TIQUNMN_H

#include <morph/sntncsik.h>

void taqen_sikuiim_lfi_monei_nituxim (ArrayOfMOWS& the_sentence_options);



#endif
