/* tiqunmn.cpp */

#include <morph/tiqunmn.h>
#include <morph/mna.h>


/*****************************************************************/
/*****                   taqen_sikuiim                        ****/
/*****************************************************************/

double
	mijqal_lx=5.77, 
	mijqal_ly=15.2,
	mijqal_ax=0,
	mijqal_ay=8.6;


void taqen_sikuiim_lfi_monei_nituxim (ArrayOfMOWS& the_eachword_options) {
	extern ofstream tiqunimlogfile;
	if (the_eachword_options.count()<2) return;
	Index w;
	for (w=0; w<the_eachword_options.count()-1; ++w) {   // xappe$ zug $e-mat^im l-^axat ha-tabniot
		MorphOptionsWithSikui options_x = the_eachword_options[w], options_y = the_eachword_options[w+1];
		ArrayOfSikuiim tosafot_x, tosafot_y;
		init(tosafot_x,options_x.count()); init(tosafot_y,options_y.count());
		if (options_x.count()<=1 && options_y.count()<=1) continue;  // There is no point in adjusting the sikuiim when there is only one option!
		tiqunimlogfile << options_x << " --- " << options_y << endl;

		Sikui the_tosefet;
		LOOPVECTOR(;,options_x,ox) {
			LOOPVECTOR(;,options_y,oy) {
				MorphInfo info_x = options_x.info(ox).mila_axrona_info(), info_y = options_y.info(oy).mila_rijona_info();
				double rcl = relative_count_lipnei (info_x,info_y);
				the_tosefet = product (options_x.sikui(ox), options_y.sikui(oy), rcl ) ;
				tosafot_x[ox] += the_tosefet*mijqal_lx;
				tosafot_y[oy] += the_tosefet*mijqal_ly;
				double rca = relative_count_axrei (info_x,info_y);
				the_tosefet = product (options_x.sikui(ox), options_y.sikui(oy), rca ) ;
				tosafot_y[oy] += the_tosefet*mijqal_ax;
				tosafot_x[ox] += the_tosefet*mijqal_ay;
			}
		}
		options_x.add (tosafot_x);  options_y.add (tosafot_y);
		tiqunimlogfile << tosafot_x << " --- " << tosafot_y << endl;
		tiqunimlogfile << options_x << " --- " << options_y << endl;
	}
}






#ifdef TEST_TIQUNMN
/***************************************************************************/
/**********        TEST TIQUNMN                                     ********/
/***************************************************************************/

#include <morph/hpmaio.h>
#include <morph/alghist.h>
#include <morph/morphanl.h>
#include <cpplib/sentence.h>

ifstream correct_analysis;

void atxel_klali_0() {
	initialize_the_analyzer(log_path,log_path);
	atxel_global_database (NULL,NULL,"..\\..\\..\\harc\\harc10.nts");

	atxel_local_database ("..\\..\\..\\harc\\harc10h.txt");
	open_logfile(3);  xajev_sikuiim_lkol_hamilim_local(); logfile.close();
	open_outfile ("..\\..\\..\\harc\\harc10h.nts",logfile,0); 
	log_local_database(logfile); 
	logfile.close();

	open_infile_with_messages ("..\\..\\..\\harc\\harc10.mn",input);
	DOx(qra_monei_nituxim (input));  input.close();
}


void atxel_klali_s() {
	atxel_global_database (NULL,NULL,"..\\..\\..\\harc\\harc10.nts");
	atxel_local_database (NULL,NULL,"..\\..\\..\\harc\\harc10h.nts");
	qra_monei_nituxim("..\\..\\..\\harc\\harc10.mn");
}



void atxel_klali_mn() {
	atxel_global_database (NULL,NULL,"..\\..\\..\\harc\\harc10.nts");
	atxel_local_database (NULL,NULL,"..\\..\\..\\harc\\harc10h.nts");
	atxel_monei_nituxim ("..\\..\\..\\harc\\harc10ag.to2");
	adken_monei_nituxim ("..\\..\\..\\harc\\harc10ag.to2");
	open_outfile ("..\\..\\..\\harc\\harc10ag.mn",logfile,0);
	ktov_monei_nituxim (logfile);   logfile.close();
}


status read_and_analyze_the_next_sentence (istream& input, Sentence& thesentence, ArrayOfMOWS& the_sentence_options) {
	skip_spaces_and_stars (input);	
	DOr(thesentence.readline(input));
	free (the_sentence_options);
	DOr(the_sentence_options.realloc(thesentence.wordcount()));
	for (Index w=0; w<thesentence.wordcount(); ++w) {
		StringTemp curword = thesentence.word(w);
		if (curword.len==0)  { continue; }
		MorphOptionsWithSikui curoptions = analysis_with_approximate_sikuiim(curword.str);
		duplicate (the_sentence_options[w],curoptions);
	}
	return OK;
}


uint
	num_of_words,
	num_of_mistakes,
	num_of_baseword_mistakes;

void hajwe_nituxim (MorphInfoCR hanitux_jelanu, MorphInfoCR hanitux_hanakon, CStr curword) {
	//if (!identical_baseword(hanitux_jelanu,hanitux_hanakon))  ++num_of_baseword_mistakes;
	if (!identical(hanitux_jelanu,hanitux_hanakon)) { 
		++num_of_mistakes;
		if (errorlogfile.is_open()) 
			errorlogfile	<< "M#" << num_of_words << " (" << curword << "): "
							<< hanitux_jelanu << "    C\"L   " << hanitux_hanakon << endl;
	}
}

uint ms_tauyot (double lx, double ly, double ax, double ay) {
	mijqal_lx=max(lx,0.); mijqal_ly=max(ly,0.); mijqal_ax=max(ax,0.); mijqal_ay=max(ay,0.);
	Sentence cursentence(500);
	ArrayOfMOWS cursentence_options;
	MorphOptionsWithSikui curoptions;
	StringTemp curword(30);
	MorphInfo curanalysis;
	num_of_words = num_of_mistakes = num_of_baseword_mistakes = 0;
	open_infile ("..\\..\\..\\harc\\harc10h.txt",input);
	open_infile ("..\\..\\..\\harc\\harc10h.to",correct_analysis);
	for(;;) {
		DOEOFx(read_and_analyze_the_next_sentence (input, cursentence, cursentence_options));
		taqen_sikuiim_lfi_monei_nituxim (cursentence_options);
		//cerr << cursentence.word(0).str << "... ";
		for (Index w=0; w<cursentence.wordcount(); ++w) {
			StringTemp curword = cursentence.word(w);  if (curword.len==0)  { continue; }
			curoptions = cursentence_options[w];
			DOEOFx (read(correct_analysis,curanalysis));	
			Index m = curoptions.index_with_greatest_sikui();
			hajwe_nituxim (curoptions.info(m), curanalysis, curword.str);
			++num_of_words;
		}
	}
	return num_of_mistakes;
}


double merxaq (double lx, double ly, double ax, double ay) {
	lx=max(lx,0.); ly=max(ly,0.); ax=max(ax,0.); ay=max(ay,0.);
	return ms_tauyot (lx,ly,ax,ay) + (lx+ly+ax+ay)/1000;
}

void bdoq() {
//	double lx=0, ly=0, ax=0, ay=0;	// 00000
//	double lx=12.1, ly=63.2, ax=4.5, ay=6.7; // a,31
//	double lx=7, ly=25, ax=0, ay=12;	 // h[ah],66;  h[ag],66
	double lx=5.77, ly=15.2, ax=0, ay=8.6;	 // h[ag],65
	double d;						// d is the delta (the stepsize)
	for (d=1; d>0.5; ) {
		double mt1111 = merxaq (lx,ly,ax,ay);       
		LOG (logfile,lx<<" "<<ly<<" "<<ax<<" "<<ay<<" d="<<d<<": "<<mt1111<<endl);
		double mt0111 = merxaq (lx-d,ly,ax,ay);
		double mt2111 = merxaq (lx+d,ly,ax,ay);
		double mt1011 = merxaq (lx,ly-d,ax,ay);
		double mt1211 = merxaq (lx,ly+d,ax,ay);
		double mt1101 = merxaq (lx,ly,ax-d,ay);
		double mt1121 = merxaq (lx,ly,ax+d,ay);
		double mt1110 = merxaq (lx,ly,ax,ay-d);
		double mt1112 = merxaq (lx,ly,ax,ay+d);
		double mt_min = min (mt1111, min (
			min ( min(mt0111,mt2111),min(mt1011,mt1211) ),
			min ( min(mt1101,mt1121),min(mt1110,mt1112) ) ) );
		if (mt_min==mt1111) d*=0.8;
		else if (mt_min==mt0111) { lx-=d; }//d=1; }
		else if (mt_min==mt2111) { lx+=d; }//d=1; }
		else if (mt_min==mt1011) { ly-=d; }//d=1; }
		else if (mt_min==mt1211) { ly+=d; }//d=1; }
		else if (mt_min==mt1101) { ax-=d; }//d=1; }
		else if (mt_min==mt1121) { ax+=d; }//d=1; }
		else if (mt_min==mt1110) { ay-=d; }//d=1; }
		else if (mt_min==mt1112) { ay+=d; }//d=1; }
	}
	logfile.close();
	open_errorlogfile(log_path);
	merxaq (lx,ly,ax,ay);
	close_errorlogfile();
}





void main (void) {
	log_path = "..\\..\\..\\harc";
	atxel_klali_mn();
	open_logfile(0);
	bdoq();
}

#endif

