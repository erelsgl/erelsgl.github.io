/* cmdline2.h -- command-line handling routines */
#ifndef __CMDLINE2_H
#define __CMDLINE2_H

#include <cpplib/cmdline1.h>
#include <cpplib/stringt.h>

void enhanced_open_infile  (CStr&  filename, ifstream& , int or_mode=ios::nocreate);
void enhanced_open_outfile (CStr&  filename, ofstream& , int or_mode=ios::noreplace);
void enhanced_append_outfile (CStr& filename, ofstream&,  int or_mode=0);
/*
	These are enhanced 'open' routines, that try to solve
		all problems in the best way, by asking the user what to do.
	The filename may be changed by the user if there is a problem.
*/


#endif
