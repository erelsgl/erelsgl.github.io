/* revlines.cpp -- reverse lines. */

#include <cpplib/cmdline1.h>
#include <cpplib/convert1.h>

class RevlinesConverter: public Converter {
public:
	status convert_line (ostream& target) {
		for (Index i=0; i<myline.len; ++i) 
			target << myline[myline.len-i];
		return OK;
	}
};

void main (int argc, char* argv[]) {
	cout << endl << "REVLINES 1.0 -- lines reverser" << endl;
	set_synopsis ("REVLINES source target");
	parse_command_line (argc,argv, 2,2, "","");

	open_infile (variable(0),global_source); open_outfile(variable(1),global_target);
	RevlinesConverter theconverter;
	theconverter.convert();
}

