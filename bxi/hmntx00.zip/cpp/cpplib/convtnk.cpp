/* convcs -- character set convert */

#include <cpplib/cmdline1.h>
#include <cpplib/convert1.h>
#include <cpplib/ivrit.h>

class TNKConverter: public Converter {
public:
	int source_set_start, target_set_start;
	bool daleg_al_jem_hapasuq;

	Index txilat_pasuq(StringTempCR pasuq) {
		for (Index j=0; pasuq[j]!='\t'; ++j)   
			if (j>=pasuq.len) return OK;
		return j+1;
	}

	void convert_charset() {
		for (Index i=0; i<myline.len; ++i) 
			myline[i] = case_convert (myline[i], source_set_start, target_set_start);
	}

	void convert_name() {
		for (Index i=0; i+3<myline.len; ++i) 
			if (uchar(myline[i])==YUD && uchar(myline[i+1])==HEY && uchar(myline[i+2])==VAV && uchar(myline[i+3])==HEY) {
				myline[i+1]=myline[i+3]=DALET;
			}
	}

	status convert_line (ostream& target) {
		Index txilat_hapasuq = txilat_pasuq(myline);
		convert_charset();
		convert_name();
		if (daleg_al_jem_hapasuq) myline.removefirst_fast(txilat_hapasuq);
		target << myline;
		if (daleg_al_jem_hapasuq) myline.restorefirst(txilat_hapasuq);
		return OK;
	}
	TNKConverter (int sss, int tss):  
		Converter(), source_set_start(sss), target_set_start(tss) {}
};

void main (int argc, char* argv[]) {
	cout << endl << "CONVTNK 1.0 -- TNK conversion" << endl;
	set_synopsis ("CONVTNK source target [/append] [/jmot-psuqim-yimaxaqu]");
	parse_command_line (argc,argv, 2,2, "","aj");

	open_infile (variable(0),global_source); 
	if (swtch('a'))
		open_outfile(variable(1),global_target, ios::app);
	else 
		open_outfile(variable(1),global_target, 0);
	TNKConverter theconverter (128,224);
	theconverter.daleg_al_jem_hapasuq = swtch('j');
	theconverter. convert ();
}

