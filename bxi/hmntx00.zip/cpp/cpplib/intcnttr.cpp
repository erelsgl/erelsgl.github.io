/* intcnttr.h -- int counter trie */

#include <cpplib/intcnttr.h>

IntCounter the_empty_int_counter;
