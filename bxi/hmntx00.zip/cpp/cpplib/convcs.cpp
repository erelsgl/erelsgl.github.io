/* convcs -- character set convert */

#include <cpplib/cmdline1.h>
#include <cpplib/convert1.h>

class CharsetConverter: public Converter {
public:
	int source_set_start, target_set_start;
	status convert_line (ostream& target) {
		for (int i=0; i<myline.len; ++i) 
			target << case_convert (myline[i], source_set_start, target_set_start);
		return OK;
	}
	CharsetConverter (int sss, int tss):  
		Converter(), source_set_start(sss), target_set_start(tss) {}
};

void main (int argc, char* argv[]) {
	cout << endl << "CONVCS 1.0 -- chararcter-set conversion" << endl;
	set_synopsis ("CONVCS source target source_set_start target_set_start\n"
								"  example:\n"
								"		 CONVCS hebrew.7b hebrew.8b 96 128");
	parse_command_line (argc,argv, 4,4, "","");

	open_infile (variable(0),global_source); open_outfile(variable(1),global_target);
	CharsetConverter theconverter (variable_as_int(2,0,255), variable_as_int(3,0,255));
	theconverter. convert ();
}

