/* lexinf2.h -- structure LexicalInfo, to hold information about words in lexicon */

#ifndef __LEXINF2_H
#define __LEXINF2_H

#include <morph/morphtyp.h>
#include <cpplib/io.h>

/***************************************************************************************/
/*      LexicalInfo																       */
/***************************************************************************************/

struct LexicalInfo { 
	HeleqDiber heleqdiber: 4;
	uint sug1: 4;
	uint sug2: 7;
	LexicalInfo (HeleqDiber thehd=NO_HD, uint thesug1=0, uint thesug2=0) { heleqdiber=thehd; sug1=thesug1; sug2=thesug2; }

	LexicalInfo (uint ZERO) { heleqdiber = NO_HD; sug1=sug2=0; }
	void operator= (uint ZERO)  { heleqdiber = NO_HD; }  
	bool operator== (uint ZERO) const  { return (heleqdiber==NO_HD); }  
};

typedef const LexicalInfo& LexicalInfoCR;

void write (ostream& out, LexicalInfoCR theinfo, Format format="");
status read (istream& in, LexicalInfo& theinfo, Format format="");


DEFINE_INLINE_IO_OPERATORS (LexicalInfo)

#endif

