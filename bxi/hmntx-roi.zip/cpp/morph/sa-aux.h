/* sa-aux.h -- auxiliary structures for the sentence-analyzer
			[cf. JAMES ALLEN: NATURAL LANGUAGE UNDERSTANDING, 2nd ed., 1995, & 3.4]
*/


#include <morph/sntncinf.h>
#include <morph/soi.h>

#include <morph/mip.h>
#include <morph/cimcumim.h>
//#include <morph/lexiconb.h>

#include <cpplib/vector1.hxx>
#include <cpplib/array2.hxx>
#include <cpplib/queue2.hxx>
#include <cpplib/matrix1.hxx>
#include <math.h>




extern ofstream sntncanllogfile;

#define MIN_CIYUN -1000
#define MAX_CIYUN 0


double ciyun_taxbiri (SentenceInfoWithCiyunCR the_partially_analyzed_sentence) {
	if (the_partially_analyzed_sentence.count()==0) return 0;
	LOOPVECTOR (double acc=MAX_CIYUN,the_partially_analyzed_sentence,w) {
		MorphInfoCR curword = the_partially_analyzed_sentence[w];

		// ha&ne$ koll millit ^o milla $e-^einah po&l ^o millat xibbur:
		if (curword.otiotyaxas()!=NO_OY)
			acc += log10(0.5);
		if (!curword.hu(POAL) && !curword.hu(MILAT_XIBUR))
			acc += log10(0.5);

		// ha&ne$ koll po&l $e-^ein lo nose^:
		if ( curword.hu(POAL) && curword.guf()==GUF3 && !lapoal_yej_nose(curword) )
			acc += log10(0.9);

		//acc += ciyun_cimcumi(curword);

		if (w+1<the_partially_analyzed_sentence.count()) {
			MorphInfoCR nextword = the_partially_analyzed_sentence[w+1];
			// ha&ne$ $tei millim $e-^einan mxubbarot &"i millat xibbur.
			if (!curword.hu(MILAT_XIBUR) && !nextword.hu(MILAT_XIBUR) &&
				(!nextword.vav() && (nextword.jiabud()==NO_JIABUD||nextword.jiabud()==JIABUD_HA)))
					acc += log10(0.3);
			// ha&ne$ nismak bli somek.
			if (curword.nismak() && !curword.poal() && !nextword.can_be_somek())  
					acc += log10(0.1);
		}
		else {
			// ha&ne$ nismak bli somek.
			if (curword.nismak() && !curword.poal()) acc += log10(0.1);
		}
	}

	return acc + the_partially_analyzed_sentence.ciyun_cimcumi/3;
}


double ciyun_taxbiri0 (SentenceInfoWithCiyunCR the_partially_analyzed_sentence) {
	if (the_partially_analyzed_sentence.count()==0) return 0;
	LOOPVECTOR (double acc=MAX_CIYUN,the_partially_analyzed_sentence,w) {
		MorphInfoCR curword = the_partially_analyzed_sentence[w];
		if (curword.hu(MILAT_XIBUR)) continue;
		if (curword.otiotyaxas()!=NO_OY) 
			acc += log10(0.5);
		acc += log10(0.5);
	}
	return acc + the_partially_analyzed_sentence.ciyun_cimcumi/100;
}


inline double ciyun_taxbiri_gavoh_bioter (SentenceOptionsCR the_options) {
	LOOPVECTOR (double cur=MIN_CIYUN, the_options, o)
		if (ciyun_taxbiri(the_options[o]) > cur)
			cur = ciyun_taxbiri(the_options[o]);
	return cur;
}



/*************       mibnei &ezr              ****************************/
/*************       mibnei &ezr              ****************************/
/*************       mibnei &ezr              ****************************/


/*--------------------- Constituent -------------------------*/
/*--------------------- Constituent -------------------------*/

struct Constituent {               
  	MorphInfo word;
	Index from, to;
	float ciyun_cimcumi;
	bool contains (Index wordnum) const { return from<=wordnum && wordnum<to; }
	Constituent(): ciyun_cimcumi(0) {}
	Constituent(MorphInfoCR theword, Index thefrom, Index theto): word(theword), from(thefrom), to(theto), ciyun_cimcumi(0) { }
};
typedef const Constituent& ConstituentCR;
inline void free (Constituent& m) { };
inline void write (ostream& out, ConstituentCR thecons, Format format="") {
	out << thecons.word << ":" << thecons.from << "=>" << thecons.to << "["<<thecons.ciyun_cimcumi<<"]";
}
inline void read (istream& in, Constituent& thecons, Format format="") {
	// not implemented
}
inline bool identical (ConstituentCR  a, ConstituentCR b) {
	return (a.from==b.from && a.to==b.to && identical(a.word,b.word) && a.ciyun_cimcumi==b.ciyun_cimcumi); }
inline void duplicate (Constituent& to, ConstituentCR from) { to=from; }

DEFINE_INLINE_IO_OPERATORS(Constituent)





/*--------------------- ActiveArc -------------------------*/
/*--------------------- ActiveArc -------------------------*/

struct ActiveArc {         
	const XoqCimcum* xoq_p;
	XoqCimcumCR xoq() const { return *xoq_p; }

	SentenceInfoWithCiyun the_partial_sentence;
	Index from, to;
	bool contains (Index word) const { return from<=word && word<to; }

	//float ciyun_cimcumi;


	ActiveArc (): the_partial_sentence() {}
	void set (XoqCimcumCR thexoq, Index thefrom, Index theto) { 
		xoq_p=&thexoq; from=thefrom; to=theto; 
		the_partial_sentence.truncate(); 
	}
	//ActiveArc (XoqCimcumCR thexoq, Index thefrom, Index theto): the_partial_sentence(4) { set(thexoq,thefrom,theto); }
	ActiveArc (XoqCimcumCR thexoq, Index thefrom, Index theto): the_partial_sentence() { set(thexoq,thefrom,theto); }

	bool is_complete () const {
		return the_partial_sentence.count()==xoq().ork();        // ha-nquda nimce^t b-sop ha-xoqq.
	}

	bool match (MorphInfoCR theword) const {
		return xoq().match(the_partial_sentence.count(), theword);
	}

	bool can_be_extended_by (ConstituentCR thecons) const {
		return (to==thecons.from && match(thecons.word) );
	}

	status extend_by (ConstituentCR thecons)  {
		to = thecons.to;
		//ciyun_cimcumi += thecons.ciyun_cimcumi;
		return the_partial_sentence.append(thecons.word,thecons.ciyun_cimcumi);
	}

	bool can_become_a_complete_constituent (Constituent& thecons) {
		double haciyun_hacimcumi;
		if (!xoq().match(the_partial_sentence,0, thecons.word, &haciyun_hacimcumi)) return false;
		thecons.from = from;  thecons.to = to;
		thecons.ciyun_cimcumi = haciyun_hacimcumi + the_partial_sentence.ciyun_cimcumi;
		return true;
	}

	bool isvalid() const { return the_partial_sentence.isvalid(); }
};
typedef const ActiveArc& ActiveArcCR;
inline void duplicate (ActiveArc& target, ActiveArcCR source) {
	target.xoq_p = source.xoq_p;
	target.to = source.to;  target.from=source.from;
	::duplicate(target.the_partial_sentence, source.the_partial_sentence);
}

inline void free (ActiveArc& a) {  ::free(a.the_partial_sentence);   }

bool sharing (ActiveArcCR a, ActiveArcCR b) { return sharing(a.the_partial_sentence,b.the_partial_sentence); }



typedef Array2<ActiveArc> SimpleArrayOfActiveArcs;

// This structure stores the arcs according to the "to" field.
struct ArrayOfActiveArcs {
	Vector1 < SimpleArrayOfActiveArcs >  thearcs;
	static SimpleArrayOfActiveArcs the_empty_set;
	const SimpleArrayOfActiveArcs& arcs_that_maybe_can_be_extended_by(ConstituentCR thecons) const {
		if (thecons.from==0) return the_empty_set;
		return thearcs[thecons.from-1]; 
	}
//	status append (ActiveArcCR thearc) { return thearcs[thearc.to].append(thearc); }
	status append (ActiveArcCR thearc) { 
		SimpleArrayOfActiveArcs& curarcs = thearcs[thearc.to-1];
		if (curarcs.len()>0) {
			ActiveArcCR lastarc = curarcs.last();
			assert (!sharing(thearc, lastarc));
		}
		return curarcs.append(thearc); 
	}
	status reset (Size thesize) { return thearcs.reset(thesize); }
	void remove_all_arcs_containing (Index word) {
		for (Index to=word+1; to<thearcs.count(); ++to) {
			SimpleArrayOfActiveArcs& curarcs = thearcs[to-1];
			LOOPVECTOR(;,curarcs,a) 
				while (curarcs[a].contains(word) && a<curarcs.count())
					curarcs.removeat(a);
		}
	}
};

SimpleArrayOfActiveArcs ArrayOfActiveArcs::the_empty_set;

void isvalid (const SimpleArrayOfActiveArcs& curarcs) { 
	for (Index a=0; a+1<curarcs.count(); ++a) {
		const ActiveArc& curarc = curarcs[a];
		const ActiveArc& nextarc = curarcs[a+1];
		assert (!sharing(curarc,nextarc));
	}
}

void isvalid (const ArrayOfActiveArcs& aoaa) { 
	LOOPVECTOR(;,aoaa.thearcs,to) {
		const SimpleArrayOfActiveArcs& curarcs = aoaa.thearcs[to];
		isvalid(curarcs);
	}
}

void free (ArrayOfActiveArcs& aoaa) { ::free (aoaa.thearcs); }
void duplicate (ArrayOfActiveArcs& to, const ArrayOfActiveArcs& from) { ::duplicate(to.thearcs, from.thearcs); }
/*void duplicate (ArrayOfActiveArcs& to, const ArrayOfActiveArcs& from) { 
	DOx(to.thearcs.reset(from.thearcs.size()));
	LOOPVECTOR(;,from.thearcs,c) {
		const SimpleArrayOfActiveArcs& fromcurarcs = from.thearcs[c];
		SimpleArrayOfActiveArcs&       tocurarcs = to.thearcs[c];
		isvalid (fromcurarcs);
		::duplicate(tocurarcs,fromcurarcs);
		isvalid (tocurarcs);
		//LOOPVECTOR(;,fromcurarcs,a) {
		//	const ActiveArc& fromcurarc = fromcurarcs[a];
		//	ActiveArc&       tocurarc =   tocurarcs[a];
		//	::duplicate (tocurarc,fromcurarc);
		//}
	}
}*/



typedef Array2<Constituent> SimpleArrayOfConstituents;

// This structure stores the constituents according to the "from" field.
struct ArrayOfConstituents {
	Vector1 < SimpleArrayOfConstituents >  theconstituents;
	static SimpleArrayOfConstituents the_empty_set;
	const SimpleArrayOfConstituents& constituents_that_maybe_can_extend(ActiveArcCR thearc) const {
		if (thearc.to>=theconstituents.count()) return the_empty_set;
		return theconstituents[thearc.to]; 
	}
	status append (ConstituentCR thecons) { return theconstituents[thecons.from].append(thecons); }
	status reset (Size thesize) { return theconstituents.reset(thesize); }
	void remove_all_constituents_containing (Index word) {
		for (Index from=0; from<=word; ++from) {
			SimpleArrayOfConstituents& curconstituents = theconstituents[from];
			LOOPVECTOR(;,curconstituents,a) 
				while (curconstituents[a].contains(word) && a<curconstituents.count())
					curconstituents.removeat(a);
		}
	}
};
void free (ArrayOfConstituents& aoc) { ::free(aoc.theconstituents); }
void duplicate (ArrayOfConstituents& to, const ArrayOfConstituents& from) { ::duplicate(to.theconstituents,from.theconstituents); }

SimpleArrayOfConstituents ArrayOfConstituents::the_empty_set;


/*--------------------- SentenceOptionsWithCiyun -------------------------*/
/*--------------------- SentenceOptionsWithCiyun -------------------------*/
// This structure contains sentence-options which all have the same ciyun_taxbiri.

class SentenceOptionsWithCiyun;
typedef const SentenceOptionsWithCiyun& SentenceOptionsWithCiyunCR;
class SentenceOptionsWithCiyun: public SentenceOptions {
	double the_ciyun_taxbiri;
public:
	static SentenceInfoWithCiyun a_new_option;
	SentenceOptionsWithCiyun():  SentenceOptions(0), the_ciyun_taxbiri(MIN_CIYUN) {}
	void remove_all() {
		LOOPTHISVECTOR(;,i)  ::free(at(i));
		truncate(); 
		the_ciyun_taxbiri=MIN_CIYUN;
	}

	status append (SentenceInfoWithCiyunCR the_new_option) {
		double the_new_ciyun_taxbiri = ciyun_taxbiri0(the_new_option);
		if (the_new_ciyun_taxbiri > the_ciyun_taxbiri) {  // The new option is better, so throw away all current options...
			remove_all();
			SentenceInfoWithCiyun to_append;  ::duplicate(to_append,the_new_option);
			the_ciyun_taxbiri = the_new_ciyun_taxbiri;
			return SentenceOptions::append(to_append);
		}
		else if (the_new_ciyun_taxbiri == the_ciyun_taxbiri) { // The new option is equivalent, so append it.
			if (!contains(*this,the_new_option)) {
				SentenceInfoWithCiyun to_append;  ::duplicate(to_append,the_new_option);
				return SentenceOptions::append(to_append);
			}
			else return OK;
		}
		else {                            // The new option is worse, so do nothing.
			return OK;
		}
	}


	status append (MorphInfo the_word, float the_ciyun_cimcumi) {         // append a sinlge-word option
		a_new_option.truncate();	
		DOr(a_new_option.append(the_word, the_ciyun_cimcumi));
		return append(a_new_option);
	}

	status append (SentenceInfoWithCiyunCR firsthalf, SentenceInfoWithCiyunCR secondhalf, float the_ciyun_cimcumi=0) {  //  concat the halves and append the result
		a_new_option.truncate();
		DOr(a_new_option.append(firsthalf));
		DOr(a_new_option.append(secondhalf));
		return append(a_new_option);
	}

	status append (SentenceOptionsCR firsthalfoptions, SentenceOptionsCR secondhalfoptions) {
		LOOPVECTOR(;,firsthalfoptions,i) {
			LOOPVECTOR(;,secondhalfoptions,j) {
				DOr(append(firsthalfoptions[i], secondhalfoptions[j])); }}
		return OK;
	}

	status append (SentenceOptionsWithCiyunCR firsthalfoptions, SentenceOptionsWithCiyunCR secondhalfoptions) {
		double the_new_ciyun_taxbiri = firsthalfoptions.the_ciyun_taxbiri + secondhalfoptions.the_ciyun_taxbiri - MAX_CIYUN;
		if (the_new_ciyun_taxbiri < the_ciyun_taxbiri)  return OK;
		else return append ( (SentenceOptionsCR)firsthalfoptions, (SentenceOptionsCR)secondhalfoptions );
	}

	friend void duplicate (SentenceOptionsWithCiyun& to, const SentenceOptionsWithCiyun& from);
};

SentenceInfoWithCiyun SentenceOptionsWithCiyun::a_new_option;

void duplicate (SentenceOptionsWithCiyun& to, const SentenceOptionsWithCiyun& from) { 
	::duplicate( (SentenceOptions&)to ,(SentenceOptionsCR)from ); 
	to.the_ciyun_taxbiri = from.the_ciyun_taxbiri;
}


/*--------------------- PartialSentences -------------------------*/
/*--------------------- PartialSentences -------------------------*/
// Each SentenceOptions keeps all best-options found so far for 
//	analyzing the part of the sentence between "row" and "col+1". (i.e. row==from, col==to-1)

struct PartialSentences: Matrix1<SentenceOptionsWithCiyun> {

	PartialSentences() {}

	status append (ConstituentCR thecons) {
		return at(thecons.from, thecons.to-1).append(thecons.word, thecons.ciyun_cimcumi);
	}


	status create_whole_sentences () {
		// Algorithm: create partial-sentences of increasing lengths.
		// PRECONDITION: all partial sentence of length 1 are already in the table 
		//		(they were inserted when the corresponding Constituents were removed from the agenda).
		for (Index PSL=2; PSL<=rowcount(); ++PSL) {  // PSL==Partial Sentence Length
			// INVARIANT: the partial-sentences of length < PSL are already in the table.
			Index from, to;
			for (from=0, to=PSL; to<=colcount(); ++from, ++to)  {
				Data& the_options = at(from,to-1);
				for (Index middle=from+1; middle<=to-1; ++middle) {
					DataCR firsthalfoptions = at(from,middle-1);
					DataCR secondhalfoptions = at(middle,to-1);
					DOr( the_options.append (firsthalfoptions, secondhalfoptions) );
				}
			}
		}
		return OK;
	}


	void remove_all_partial_sentences_containing (Index theword) {
		for (Index from=0; from<=theword; ++from)
			for (Index to=theword+1; to<=colcount(); ++to)
				at(from,to-1).remove_all();
	}

	void remove_all() {
		for (Index r=0; r<rowcount(); ++r)
			for (Index c=0; c<colcount(); ++c)
				::free(at(r,c));
	}

};




/********************************************************************************/
/*************       Sentence Analyzer               ****************************/
/********************************************************************************/


class SentenceAnalyzer {
protected:
	
	Size the_wordcount;

	SentenceOptions* the_final_options_p;
	#define the_final_options (*the_final_options_p)

	Queue2<Constituent> the_complete_constituents;      // the "agenda"
	ArrayOfActiveArcs  the_active_arcs;
	ArrayOfConstituents  the_old_constituents;

	//PartialSentences the_partial_sentences;
	PartialSentences the_partial_sentences;

	static ActiveArc a_new_active_arc;

	status start (Size the_original_wordcount, SentenceOptions& the_options) {
		the_wordcount = the_original_wordcount;
		DOr(the_partial_sentences.reset (the_wordcount,the_wordcount) );
		DOr(the_active_arcs.reset (the_wordcount));
		DOr(the_old_constituents.reset (the_wordcount));
		::free (the_options);
		the_final_options_p = &the_options;
		return OK;
	}

	status extend_the_new_active_arc_and_append_it (ConstituentCR thecons) {
		a_new_active_arc.extend_by(thecons);
		if (!a_new_active_arc.is_complete()) {
			ActiveArc to_append;  ::duplicate(to_append, a_new_active_arc);
			DOr(the_active_arcs.append(to_append)); 
			return try_to_extend_arc_by_old_constituents(to_append);
		}
		else {
			Constituent the_new_cons;
			if (a_new_active_arc.can_become_a_complete_constituent(the_new_cons)) {
				if (!contains(the_complete_constituents,the_new_cons)) {
					DOr (the_complete_constituents.enqueue(the_new_cons)); }}
			return OK;
		}
	}


	status try_to_extend_arc_by_old_constituents (ActiveArcCR thearc) {
		const SimpleArrayOfConstituents& cur_constituents = the_old_constituents.constituents_that_maybe_can_extend(thearc);
		LOOPVECTOR(;,cur_constituents,c) {
			if (thearc.can_be_extended_by(cur_constituents[c])) {
				::duplicate(a_new_active_arc,thearc);
				DOr (extend_the_new_active_arc_and_append_it(cur_constituents[c]));
			}
		}
		return OK;
	}


	status add_new_active_arcs (ConstituentCR cur_constituent) {
		LOOPVECTOR (;,hacimcumim,x) {   
			XoqCimcumCR cur_xoq = hacimcumim[x]; 
			a_new_active_arc.set (cur_xoq,cur_constituent.from,cur_constituent.from);
			if (a_new_active_arc.can_be_extended_by (cur_constituent)) {
				DOr (extend_the_new_active_arc_and_append_it(cur_constituent));
			}
		}
		return OK;
	}

	status update_active_arcs (ConstituentCR cur_constituent) {
		const SimpleArrayOfActiveArcs& cur_arcs = the_active_arcs.arcs_that_maybe_can_be_extended_by(cur_constituent);
		LOOPVECTOR (;,cur_arcs,a) {  
			if (cur_arcs[a].can_be_extended_by(cur_constituent)) {
				::duplicate(a_new_active_arc,cur_arcs[a]);
				DOr (extend_the_new_active_arc_and_append_it(cur_constituent));
			}
		}
		return OK;
	}


	status create_final_options () {
		DOr(the_partial_sentences.create_whole_sentences());  // This line does NOT cause any memory-leak!
		#ifdef TEST_SNTNCANL
		writeln (sntncanllogfile,the_partial_sentences);
		#endif
		::free (the_final_options);

		::duplicate ( the_final_options, the_partial_sentences.at(0,the_wordcount-1) );
		//SentenceInfoWithCiyun theinfo;  ::duplicate (theinfo, the_partial_sentences.at(0,the_wordcount-1));
		//the_final_options.append (theinfo);

		writeln (sntncanllogfile,the_final_options,Format("*\n"));  sntncanllogfile<<endl<<endl<<endl;
		return OK;
	}


	status process_all_complete_constituents () {
		while (!the_complete_constituents.isempty()) {
			Constituent cur_constituent = the_complete_constituents.athead();
			sntncanllogfile<<cur_constituent<<" ";
			#ifdef TEST_SA_AUX
			cerr<<cur_constituent<<" ";
			#endif
			DOr(update_active_arcs(cur_constituent));
			DOr(add_new_active_arcs(cur_constituent)); 
			DOr(the_partial_sentences.append(cur_constituent));
			DOr(the_old_constituents.append(cur_constituent));
			the_complete_constituents.dequeue();
		}
		sntncanllogfile<<endl;
		#ifdef TEST_SA_AUX
		cerr<<endl;
		#endif
		return OK;
	}


public:

	status natax (SentenceInfoWithCiyunCR the_original_sentence, SentenceOptions& the_options) {
		DOr(start(the_original_sentence.count(),the_options));
		LOOPVECTOR (;,the_original_sentence,w)  {
			MorphInfoCR curword = the_original_sentence[w];
			DOr(the_complete_constituents.enqueue (
				Constituent(curword,w,w+1)));
			DOr(process_all_complete_constituents());
		}
		DOr(create_final_options());
		return OK;
	}

	status natax_jenit (Index word_to_replace, MorphInfoCR new_word) {
		the_active_arcs.remove_all_arcs_containing(word_to_replace);
		the_old_constituents.remove_all_constituents_containing(word_to_replace);
		the_partial_sentences.remove_all_partial_sentences_containing(word_to_replace);
		DOr(the_complete_constituents.enqueue (
			Constituent(new_word,word_to_replace,word_to_replace+1)));
		DOr(process_all_complete_constituents());
		DOr(create_final_options());
		return OK;
	}
	friend void duplicate (SentenceAnalyzer& to, const SentenceAnalyzer& from);

	status finish() {
		::free(the_complete_constituents);
		//isvalid(the_active_arcs);
		::free(the_active_arcs);
		::free(the_old_constituents);
		::free(the_partial_sentences);
		return OK;
	}

	~SentenceAnalyzer() { finish(); }

};


ActiveArc SentenceAnalyzer::a_new_active_arc;




void duplicate (SentenceAnalyzer& to, const SentenceAnalyzer& from) {
	to.the_wordcount = from.the_wordcount;
	to.the_final_options_p = from.the_final_options_p;

	//isvalid(from.the_active_arcs);
	::duplicate(to.the_active_arcs, from.the_active_arcs);
	//isvalid(to.the_active_arcs);
	::duplicate(to.the_old_constituents.theconstituents,from.the_old_constituents.theconstituents);
	::duplicate(to.the_partial_sentences,from.the_partial_sentences);
}




/*******************************************************************/
/*********  public routines						      **************/
/*******************************************************************/

bool the_sentence_analyzer_is_initialized = false;

void initialize_the_sentence_analyzer (CStr path_to_cimcumim) {
	assert (OK==qra_cimcumim(path_to_cimcumim) );
	//assert (OK==qra_lexicon_bituyim(path_to_cimcumim) );
	//ktov_lexicon_bituyim(path_to_cimcumim);
	the_sentence_analyzer_is_initialized = true;
}
