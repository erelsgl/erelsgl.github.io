/* testmmm.cpp -- test mone Milim-Axrei-Mila */

#include <morph/mone-mm.h>

void main (void) {
	MorphInfo mibe1("$BR",ECEM), mibe2("AXD",ECEM);
	MorphInfo mibp1("$BR",POAL), mibt1("AXD",TOAR);
	mibp1.setjiabud (JIABUD_KJE);
	mibt1.setjiabud (JIABUD_JE); mibt1.setvav(true);
	MoneMilimAxreiMila thecounter; writeln (cout,thecounter);
	EXECx(thecounter.add(mibe1,mibe2));    writeln (cout,thecounter);
	EXECx(thecounter.add(mibe1,mibp1));    writeln (cout,thecounter);
	EXECx(thecounter.add(mibe1,mibt1));    writeln (cout,thecounter);
	EXECx(thecounter.add(mibe2,mibe1));    writeln (cout,thecounter);
	EXECx(thecounter.add(mibe2,mibp1));    writeln (cout,thecounter);
	EXECx(thecounter.add(mibe2,mibt1));    writeln (cout,thecounter);
}
