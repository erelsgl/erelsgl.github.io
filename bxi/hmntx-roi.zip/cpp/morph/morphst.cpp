/* morphst.cpp -- morphological options trie with sikuiim */

#include <morph/morphst.h>

// tries to find the word-analysis in the trie, and if not found -- analyzes it and enters it to the trie.
MorphOptionsWithSikui MorphOptionsWithSikuiTrie::analysis (CStr theword) {
	if (contains(theword))
		 return item(theword);
	else {
		MorphOptionsWithSikui theoptions = analyze_s (theword); 
		insert (theword,theoptions);
		return theoptions;
	}
}


status MorphOptionsWithSikuiTrie::analyze_words_in_file  (istream& in, CStr the_stopper) {
	StringTemp cur_word(30);
	for (Index wordnum=0;;++wordnum) {
		skip_comments (in,'%');
		DOEOF (cur_word.readline(in," \t\n"));
		if (compare(cur_word.str,the_stopper)==0) return OK;
		if (contains(cur_word.str))  continue;
		DOr(insert (cur_word.str, analyze_s(cur_word.str) ));
		if (wordnum%100==0) cerr << (wordnum/100) << " " << cur_word << " ";
	}
}


