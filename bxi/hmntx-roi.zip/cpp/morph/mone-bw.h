/* mone-bw.h -- baseword (with HeleqDiber) counter */

#ifndef __MONEBW_H
#define __MONEBW_H

#include <cpplib/wordcnt.h>
#include <cpplib/sikui.h>
#include <morph/morphinf.h>

/*        ***** USAGE EXAMPLE ***** (OUTDATED!)
// inserting and counting:
	MoneBaseword yourcounter;
	yourcounter.insert ("&WLH",ECEM);
	yourcounter.insert ("&WLH",TOAR);
	yourcounter.insert ("&WLH",ECEM);
	yourcounter.insert ("&LH",POAL);
	cout << yourcounter.count("&WLH",ECEM);       // prints 2
	cout << yourcounter.count("&WLH",TOAR);       // prints 1
	cout << yourcounter.count("&WLH",POAL);       // prints 0
	cout << yourcounter.count("&LH",POAL);       // prints 1
	cout << yourcounter.count("&LH",ECEM);       // prints 0
	cout << yourcounter.wordcount();        // prints 4 (4 basewords total)
	cout << yourcounter.count();            // prints 3 (3 different basewords)

//saving the counter to a file:
	ofstream your_output_stream("file.txt");
	write (your_output_stream, yourcounter );
	yout_output_stream.close();
//restoring the counter from the file:
	ifstream your_input_stream("file.txt");
	read (your_input_stream, yourcounter );
	yout_input_stream.close();
*/



class MoneBaseword;
typedef const MoneBaseword& MoneBasewordCR;

class MoneBaseword {
	WordCounter mycounters [16];
	WordCounter& counter (HeleqDiber hd) { return mycounters[hd+8]; }
public:
	void zero_all() {
		for (Index i=0; i<16; ++i) 
			mycounters[i].zero_all();
	}
	status setcount (MorphInfoCR theinfo, Sikui thesikui=0) {
		return counter(theinfo.heleqdiber()).setcount (theinfo.baseword(), thesikui ); }
	status add (MorphInfoCR theinfo, Sikui thesikui=SIKUI1) {
		return counter(theinfo.heleqdiber()).insert (theinfo.baseword(), thesikui ); }
	Count count (MorphInfoCR theinfo) {
		return counter(theinfo.heleqdiber()).count (theinfo.baseword() ); }
	friend void write (ostream& out, MoneBasewordCR theinfo);
	friend status read (istream& in, MoneBaseword& theinfo);
};

void write (ostream& out, MoneBasewordCR theinfo) {
//	out << "{" << endl;
	for (Index i=0; i<16; ++i) {
		write(out, theinfo.mycounters[i], Format("T")); 
//		out<<".";
	}
//	out << "}" << endl;
}

status read (istream& in, MoneBaseword& theinfo) {
//	DOr(testchar(in,'{'));
	for (Index i=0; i<16; ++i)
		DOr(read (in,theinfo.mycounters[i]));
//		read_trie (in,theinfo.mycounters[i],':','\n','.',Format(""));
//	DOr(testchar(in,'}'));
	return OK;
}



#endif
