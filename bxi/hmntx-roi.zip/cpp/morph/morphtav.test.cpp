/* morphtav.test.cpp -- a main program to test the morphologic 'tavniot'. */

#include <morph/morphtav.h>


void main (int argc, char* argv[]) {
	DOx ( read_the_tavniot(".") );
}
