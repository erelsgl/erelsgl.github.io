/* gencorp.cpp -- corpus generation */ 

#include <cpplib/cmdline1.h>
#include <morph/convlang.h>

ofstream outfile;


void gencorp (StringTempR thetemplate, bool variable_length=false)  { // each 'x' will be replaced by the letters A-T
	Index i = charindex ('x',thetemplate.str);
	if (i==thetemplate.len)            // the word is complete -- no 'x' to replace
		outfile << thetemplate << " ";  
	else {
		for (uchar c=ALEPH; c<=TAV; ++c) {
			if (is_sofit(c)) continue;
			thetemplate[i]=heb2eng(c);
			gencorp (thetemplate,variable_length);
		}
		if (variable_length) {
			thetemplate[i]='\0';
			outfile << thetemplate << " ";  
		}
		outfile << endl;
		thetemplate[i]='x';
	}
}

void gencorp (CStr thetemplate, bool variable_length=false) {
	StringTemp temp (thetemplate);
	gencorp (temp,variable_length);
}

void open_the_outfile (CStr thename) {
	StringTemp filename = concat_path_to_filename (variable(0),thename);
	cerr << "opening file " << filename.str << endl;
	open_outfile (filename.str,outfile,0);
}


void main (int argc, char* argv[]) {
	set_synopsis ("GENCORP target-path /n <number>");
	parse_command_line (argc,argv,1,1,"n","");
	int n = option_as_int ('n',0,4);
	if (n==2) {
		open_the_outfile ("corp2.cln");
		gencorp ("xxIM");
		gencorp ("xxWT");
		gencorp ("xx");
	}
	else if (n==3) {
		open_the_outfile ("corp3.cln");
		gencorp ("xxIM");
		gencorp ("xxWT");
		gencorp ("xx");
		gencorp ("xxx");
	}
	else if (n==4) {
		open_the_outfile ("corp4.cln");
		gencorp ("xxxx");
		open_the_outfile ("corp4im.cln");
		gencorp ("xxxxIM");
		open_the_outfile ("corp4wt.cln");
		gencorp ("xxxxWT");
		open_the_outfile ("corp4m.cln");
		gencorp ("Mxxxx");
		open_the_outfile ("corp4t.cln");
		gencorp ("Txxxx");
		//open_the_outfile ("corp4tt.cln");
		//gencorp ("TxTxxx");
		//gencorp ("TTxxxx");
		open_the_outfile ("corp3x.cln");
		gencorp ("xx");
		gencorp ("xxx");
		gencorp ("xxxIM");
		gencorp ("xxxWT");
	}
	else if (n==0) {
		open_the_outfile ("corpmis.cln");
		gencorp ("$NIxxx",true);
		gencorp ("$TIxxx",true);
		gencorp ("$LW$xxx",true);
		gencorp ("ARB&xxx",true);
		gencorp ("XM$xxx",true);
		gencorp ("XMI$xxx",true);
		gencorp ("$$xxx",true);
		gencorp ("$I$xxx",true);
		gencorp ("$B&xxx",true);
		gencorp ("$IB&xxx",true);
		gencorp ("$MWNxxx",true);
		gencorp ("T$&xxx",true);
		gencorp ("TI$&xxx",true);
		gencorp ("&$Rxxx",true);
		gencorp ("MAxxx",true);
		gencorp ("ALPxxx",true);
	}
}
