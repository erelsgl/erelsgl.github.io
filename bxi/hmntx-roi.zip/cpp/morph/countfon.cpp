/* countfon.cpp -- count ... */

#include <cpplib/klli1.h>
#include <cpplib/mapc.hxx>
#include <cpplib/countc.hxx>
#include <cpplib/map1.hxx>
#include <cpplib/trie0.hxx>
typedef Trie0OfContainerType(CounterVector1Sorted,CStr)   FonemicCounterTrie;

#include <cpplib/cmdline1.h>
#include <morph/convlang.h>

FonemicCounterTrie mytrie;
ifstream fonemic_infile, hebrew_infile;

void get_the_data () {
	StringTemp fonemic_word, hebrew_word(30);
	fonemic_word.alloc(30);
	for(;;) {
		skip (fonemic_infile," \n,;.:()[]{}!?");
		DOEOFx( fonemic_word.readline(fonemic_infile,Format(" \n,;.:()[]{}!?")) );
		if (word_contains_number(fonemic_word)) continue;
		if (fonemic_word[0]=='"') fonemic_word.remove(0);
		if (fonemic_word.at_end(0)=='"') fonemic_word.backspace();

		for(;;) {
			fonemic2eng (fonemic_word,hebrew_word);
			//cout << fonemic_word << " = " << hebrew_word << " ";
			if (hebrew_word.len>1) 
				DOx ( mytrie.insert(hebrew_word.str,fonemic_word.duplicate() ) );
			Index maqafindex = charindex('-',fonemic_word.str);
			if (maqafindex==0) break;
			if (maqafindex>=fonemic_word.len) break;
			fonemic_word.remove(0,maqafindex+1);
		}
	}
}




#ifdef TEST_COUNTFON

void main(int argc, char* argv[]) {
	//cout << sizeof FonemicCounterTrie;
	set_synopsis ("COUNTFON fonemic");
	parse_command_line (argc,argv, 1,2, "","");
	open_infile (variable(0), fonemic_infile);
	get_the_data();
	fonemic_infile.close();
	if (variable(1)!=NULL) {
		open_infile (variable(1), fonemic_infile);
		get_the_data();
		fonemic_infile.close();
	}
	//writeln (cout, *mytrie.infop("HNXIWT")  ,Format("L"));
	writeln (cout, mytrie ,Format("T L"));
}

#endif
