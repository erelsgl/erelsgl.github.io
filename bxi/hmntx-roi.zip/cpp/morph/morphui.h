/* morphui.h */

#include <morph/morphinf.h>

/* noten la-mi$tamme$ liktob nittux xada$ l- "hmila" */
void input_morphinfo (CStr hmila, MorphInfo& hnitux);
