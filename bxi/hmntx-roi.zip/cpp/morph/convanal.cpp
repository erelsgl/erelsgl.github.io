/* convanal.cpp */

#include <morph/morphopt.h>
#include <cpplib/stringp.h>
#include <cpplib/stringt.h>
#include <morph/convlang.h>
#include <cpplib/convert1.h>
#include <cpplib/cmdline1.h>

/* 
	The format of the demoanal output:
	fullword  pos  baseword  smikut  guf  meen  mispar  zman  guf_s  meen_s  mispar_s  corrected  isvariant  
*/


StringTemp parse_hebword (StringParseR theline) {
	FINDinSTRING(theline,is_heb(c));
	StringTemp theword(theline.len-theline.index+1);
	PARSE(theline, !(is_heb(c)||is_punctchar(c)), theword);
	heb2eng(theword);
	return theword;
}

HeleqDiber parse_hd (StringParseR theline) {
	FINDinSTRING(theline,is_heb(c));
	uchar c1=theline.get(), c2=theline.get();
	if (c1==PEY && c2==' ')     return POAL;
	else if (c1==JIN) {
		if (c2==AYN)  return ECEM;
		if (c2==TAV)  return TOAR;
		if (c2==PEY)  return JEM_PRATI;
		if (c2==MEM)  return MISPAR;
	}
	else if (c1==MEM) {
		if (c2==YUD) return MILAT_YAXAS;
		if (c2==GIMEL) return MILAT_GUF;
		if (c2==JIN) return MILAT_JEELA;
		if (c2==HET) return MILAT_XIBUR;
		if (c2==' ') return MILIT;
	}
	else if (c1==NUN && c2==TET) return NOTRICON;
	else if (c1==TAV && c2==PEY) return TOAR_POAL;
	return NO_HD;
}

Smikut parse_smikut(StringParseR theline) {
	FINDinSTRING(theline,is_heb(c)||c=='*');
	uchar c1=theline.cur(2);    theline.next(5);
	if      (c1==REJ) return NIFRAD;
	else if (c1==MEM) return NISMAK;
	else if (c1=='/') return BOTH;
	else return NONE;
}

Guf parse_guf(StringParseR theline) {
	FINDinSTRING(theline,is_heb(c)||c=='*'||c=='1');
	uchar c1=theline.cur(), c2=theline.cur(4);  theline.next(5);
	if (c1==GIMEL)  {
		if      (c2=='1') return GUF1;
		else if (c2=='2') return GUF2;
		else if (c2=='3') return GUF3;
	}
	else if (c1=='1') return BOTH;
	return NONE;
}		

Meen parse_meen(StringParseR theline) {
	FINDinSTRING(theline,is_heb(c)||c=='*');
	uchar c1=theline.cur(), c2=theline.cur(2);   theline.next(3);
	if      (c1==ZAYIN && c2==NUN)  return BOTH;
	else if (c1==ZAYIN)  return ZAKAR;
	else if (c1==NUN) return NEQEVA;
	else return NONE;
}

Mispar parse_mispar(StringParseR theline) {
	FINDinSTRING(theline,is_heb(c)||c=='*'); 
	uchar c1=theline.get();   
	if      (c1==REJ)  return RABIM;
	else if (c1==YUD)  return YAXID;
	else return NONE;
}

Zman parse_zman(StringParseR theline) {
	FINDinSTRING(theline,is_heb(c)||c=='*');   
	uchar c1=theline.cur(1);    theline.next(5);
	if      (c1==BET)  return AVAR;
	else if (c1==VAV)  return HOWE;
	else if (c1==TAV)  return ATID;
	else if (c1==YUD)  return CIWUI;
	else if (c1==MEMSOFIT)  return MAQOR;
	else return NO_ZMAN;
}


bool get_morphinfo_from_demoanal_output (StringTempR therawline, MorphInfo& theinfo, StringTemp& thefullword) {
	if (charindex('1',therawline.str)<=3)   return false;     // don't deal with variants.
	if (charinstring('r',therawline.str)) return false;       // error line
	if (charinstring('t',therawline.str)) return false;		  // status line	
	StringParse theline(therawline.str);
	theline.reverse();
	thefullword = parse_hebword (theline);  if (theline.end()) return false;
	theinfo.setheleqdiber (parse_hd(theline));  if (theline.end()) return false;
	theinfo.setbaseword   (parse_hebword(theline).str);  if (theline.end()) return false;
	theinfo.setsmikut (parse_smikut(theline));  if (theline.end()) return false;
	theinfo.setguf (parse_guf(theline));
	theinfo.setmeen (parse_meen(theline));
	theinfo.setmispar (parse_mispar(theline));
	theinfo.setzman (parse_zman(theline));
	theinfo.setguf_siomet (parse_guf(theline));
	theinfo.setmeen_siomet (parse_meen(theline));
	theinfo.setmispar_siomet (parse_mispar(theline));
	return true;
}

/***********************************************************************************/
/***********     The converter                  ************************************/
/***********************************************************************************/

struct AnalysisConverter: public Converter {
	MorphOptions cur_options;
	StringTemp cur_fullword;

	AnalysisConverter(): Converter(), cur_fullword(50) {}

	void start (ostream&) { cur_fullword.truncate(); }

	status convert_line(ostream& target) {
		MorphInfo theinfo;
		StringTemp thefullword;
		if ( get_morphinfo_from_demoanal_output(myline,theinfo,thefullword) ) {
			if (thefullword==cur_fullword) {
				if (!(theinfo.heleqdiber()==POAL && theinfo.guf_siomet()!=NONE))   // igonre kinuiei musa^
					cur_options.append(theinfo);
				return STAY_IN_THE_SAME_LINE;
			}
			else {
				if (cur_fullword.len>0)  target << cur_fullword << ": ";
				write(target,cur_options,Format(" "));
				cur_fullword = thefullword;
				cur_options.truncate();
				if (!(theinfo.heleqdiber()==POAL && theinfo.guf_siomet()!=NONE))   // igonre kinuiei musa^
					cur_options.append(theinfo);
				return OK;
			}
		}
		else return STAY_IN_THE_SAME_LINE;
	}		

	void finish(ostream& target) { 
		target << cur_fullword << ": ";
		writeln(target,cur_options,Format(" "));
	}
};



void main (int argc, char* argv[]) {
	set_synopsis ("CONVANAL source{Hebrew} target{compact,English}");
	ofstream out; ifstream in;
	parse_command_line (argc,argv,0,2,"","");
	if (variable(0)!=NULL) { open_infile(variable(0),in);  cin=in; }
	if (variable(1)!=NULL) { open_outfile(variable(1),out,0);  cout=out; }
	//open_infile(variable(0),global_source);  open_outfile(variable(1),global_target,0);
	AnalysisConverter theconverter;
	theconverter.convert(cin,cout);
}
