/* genlex.cpp -- generate lexicon */

#include <morph/lexicon.h>
#include <morph/morphopt.h>
#include <morph/morphtav.h>
#include <cpplib/cmdline1.h>
#include <cpplib/stringt.h>
#include <morph/addlex.h>

status generate_the_lexicon(istream& in) {
	MorphOptions cur_options;
	StringTemp cur_fullword (50);
	for(;;) {
		skip(in,"\n\t: ");
		DOEOFx(cur_fullword.readline (in,Format(":")));
		if (cur_fullword.len==0) continue;   // empty word.
		skip(in," \t");
		DOx(read (in, cur_options, Format("L")));
		for (Index i=0; i<cur_options.count(); ++i) 
			cout << cur_options[i] << " ";
			extend_lexicon (cur_fullword.str, cur_options[i]);
		}
	}
	return OK;
}



void print_the_lexicon () {
	write_the_lexicon (variable(1));
}

void main (int argc, char* argv[]) {
	set_synopsis ("GENLEX analysis.ANS path-to-lexicon [/Append-to-current] [/t path-to-tavniot]");
	parse_command_line (argc,argv,2,2,"t","a");
	DOx (read_the_tavniot( option('t')==NULL? "e:\\erel\\morph": option('t') ));
	if (swtch('a'))  
		read_the_lexicon(variable(1));
	ifstream in;
	open_infile(variable(0),in);
	status st;
	DOx(st=generate_the_lexicon(in));  
	assert (st==EOF || st==OK);
	print_the_lexicon ();
}
