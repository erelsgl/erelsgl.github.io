/* convcorp.cpp */
/*
INPUT: A file in "CLN" format. That is: a file that contains Hebrew text in English
	letters (1:1 correspondence). (similar but not identical to phonemic script).
OUTPUT: A file in DOS-Hebrew, but in logical order.
	In the output file, each word appears only once (in the first place where it is seen).
	This is done to save space and time later. Also, the punctuation marks and the numbers 
	are removed.
*/


#include <morph/convlang.h>
#include <cpplib/convert1.h>
#include <cpplib/ivrit.h>
#include <cpplib/cmdline1.h>
#include <strstrea.h>
#include <iomanip.h>

#include <cpplib/trie0.hxx>

/**********************************************************/
/*************** word table      **************************/
/**********************************************************/


bool only_one_word_of_each_kind, only_long_words, translate_language;
Trie0<byte> word_table;
uint word_count=0;

inline bool I_remember (CStr theword) { return word_table.contains(theword); }
inline status remember (CStr theword) { if (!word_table.contains(theword)) {++word_count; return word_table.insert(theword,1);} else return OK; }
status save_word_table (CStr filename) {
	ofstream outfile;
	DOr (open(filename,outfile,0));
	write (outfile,word_table,Format("D"));
	outfile.close();
	return OK;
}
status load_word_table (CStr filename) {
	ifstream infile;
	DOr (open(filename,infile));
	DOr (read (infile,word_table,Format("D")));
	infile.close();
	return OK;
}




/**********************************************************/
/*************** line   conversion ************************/
/**********************************************************/

class CorpusConverter: public Converter {
	StringTemp myword;
	void start(ostream&)  { myword.truncate(); }

	void write_myword (ostream& target) {
	}


	bool I_should_print (StringTempCR myline) {
		if (myline.len<1 && 30<myline.len) return false;
		if (only_long_words) {
			if (myline.len<=4) return false;
			if (myline.len<=5 && (myline[0]=='M' || myline[0]=='T') ) return false;
			if (myline.len<=6 && ((myline.at_end(0)=='M' && myline.at_end(1)=='I') ||
								  (myline.at_end(0)=='T' && myline.at_end(1)=='W')   ))  return false;
			if (word_contains_number(myline)) return false;
		}
		if (only_one_word_of_each_kind)
			if  (I_remember(myline.str)) return false;
		return true;
	}


	status convert_line(ostream& target) {
		if (I_should_print(myline)) {
			if (translate_language)  eng2heb(myline);
			target << myline << " ";
		}
		if (only_one_word_of_each_kind) {
			if (translate_language)  heb2eng(myline);
			remember(myline.str);
		}
		myline.truncate();
		if (linenum%250==0)  cerr << linenum << ":" << word_count << "  ";
		if (only_long_words||only_one_word_of_each_kind) return STAY_IN_THE_SAME_LINE;
		else return OK;
	}

	void finish(ostream&) {
		cout << "Total number of new words remembered: " << word_count << endl;
	}

public:
	CorpusConverter (): Converter(punctuation_chars), myword(100) {}
};




void convert_the_files (CStr sourcename, CStr targetname) {
	cout << "Opening " << sourcename << " and " << targetname << endl;
	DOx(open(sourcename,global_source));  
	DOx(open(targetname,global_target,0));
	cout << "Converting " << sourcename << " into " << targetname << endl;
	CorpusConverter myconverter;
	DOx(myconverter.convert());
	cout << "Closing " << sourcename << " and " << targetname << endl;
	global_source.close();  global_target.close();
}



/**********************************************************/
/*************** CORPUS conversion ************************/
/**********************************************************/

CStr filenames[] = {
	"apr15-23-90","apr2-13-90","aug1-12-90" ,"aug21-31-90",
	"dec10-21-90","dec22-2-90","feb1-14-91","feb12-18-90","feb5-14-91","feb28-7-90",
	"jan16-30-91","jan22-30-90","jan31-9-90","jan8-16-90","jul16-24-90","jul25-1-90",
	"jul5-15-90","jun24-4-90","mar14-21-90","mar18-28-91","mar21-1-90","mar5-17-91",
	"may7-15-90","nov16-26-90","nov29-4-90","nov9-15-90","sep11-16-90","sep30-9-90" };


void main (int argc, char* argv[]) {
	set_synopsis ("CONVCORP source.CLN target.HEB [/Only-one-word-of-each-kind] [/only-Long-words] [/Translate-eng2heb]");
	uint files_count = sizeof(filenames);
	parse_command_line (argc,argv,2,2,"","olt");
	only_one_word_of_each_kind = swtch('o');
	only_long_words  = swtch('l');
	translate_language = swtch('t');
	if (variable(1)!=NULL) 
		convert_the_files (variable(0),variable(1));
	else {
		//DOx(load_word_table("wordtab.tri"));
		for (uint i=0; i<6; ++i) 
			convert_the_files ( format("d:\\c\\%s.CLN",filenames[i]).str,
								format("d:\\c\\coharc%02d.heb",i).str      );
	}
}
