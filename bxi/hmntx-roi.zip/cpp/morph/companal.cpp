/* companal -- compare 2 analysis files */


#include <morph/morphinf.h>
#include <cpplib/cmdline1.h>
#include <cpplib/io2.h>
#include <cpplib/stringt.h>

ifstream testfile, correctfile;
ofstream logfile;

void main (int argc, char* argv[]) {
	set_synopsis ("COMPANAL test.OUT correct.OUT [/g log-path]");
	parse_command_line (argc,argv,2,2,"g","");
	CStr testname=variable(0);  CStr correctname=variable(1);
	CStr log_path = option('g')==NULL? ".": option('g');
	DOx(open(testname,testfile));  
	DOx(open(correctname,correctfile));
	DOx(open( concat_path_to_filename(log_path,"log.cmp").str ,logfile, 0));

	MorphInfo testinfo, correctinfo;
	uint num_of_words = 0, num_of_mistakes=0, num_of_baseword_mistakes=0;
	for(;;) {
		skip(testfile,PUNCTUATION_CHARS);		DOEOFx (read(testfile,testinfo)); 
		skip(correctfile,PUNCTUATION_CHARS);	DOEOFx (read(correctfile,correctinfo)); 
		if (!identical_baseword(testinfo,correctinfo))  ++num_of_baseword_mistakes;
		if (!identical(testinfo,correctinfo))  ++num_of_mistakes;
		if (!identical(testinfo,correctinfo)) {  // log the mistake	
			logfile << "M#" << num_of_words << ": "
					<< testinfo << "    C\"L   " << correctinfo << endl;
		}
		++num_of_words;
	}
	LOG(logfile,"\nMSPR MILIM KWLL:            " << num_of_words << endl);
	LOG(logfile,"MSPR $GIAWT:                " << num_of_mistakes
			<< " (" << (num_of_mistakes*100./num_of_words) << "%)" << endl);
	LOG(logfile,"MSPR $GIAWT B&RK MILWNI:    " << num_of_baseword_mistakes 
			<< " (" << (num_of_baseword_mistakes*100./num_of_words) << "%)" << endl);
	testfile.close();  correctfile.close();
	logfile.close();
}
