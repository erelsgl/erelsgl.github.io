/* convfnm.cpp -- convert fonemic script to Hebrew (in English letters) */


#include <cpplib/convert1.h>
#include <cpplib/ivrit.h>
#include <morph/convlang.h>


/**********************************************************/
/*************** line   conversion ************************/
/**********************************************************/

class FonemicConverter: public Converter {
	StringTemp myword2;
	void start(ostream&)  {  }

	status convert_line(ostream& target) {
		if (0<myline.len) {
			if (!word_contains_number(myline)) {
				fonemic2eng (myline,myword2);
				target << myword2;
			}
		}
		return OK;
	}

	void finish(ostream&) {}

public:
	FonemicConverter (): Converter(" \n,;.:\"()[]{}"),  myword2(100) {}
};



#include <cpplib/cmdline1.h>

void main(int argc, char* argv[]) {
	parse_command_line (argc,argv,2,2,"","");
	CStr sourcename=variable(0);  CStr targetname=variable(1);
	cout << "Opening " << sourcename << " and " << targetname << endl;
	DOx(open(sourcename,global_source));  
	DOx(open(targetname,global_target,0));
	cout << "Converting " << sourcename << " into " << targetname << endl;
	FonemicConverter myconverter;
	DOx(myconverter.convert());
	cout << "Closing " << sourcename << " and " << targetname << endl;
	global_source.close();  global_target.close();
}
