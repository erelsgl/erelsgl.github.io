/* addlex.h -- functions to extend the lexicon */

#ifndef __ADDLEX_H
#define __ADDLEX_H

#include <morph/morphinf.h>

status extend_lexicon (CStr thefullword, MorphInfo theanalysis);
	// this function extends the lexicon, so that it will know that 'the-analysis' matches 'the-fullword'.
	// Use this function if the analyzer doesn't find some analysis.

#endif
