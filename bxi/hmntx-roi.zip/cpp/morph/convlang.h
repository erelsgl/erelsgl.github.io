/* convlang.h */
 
#ifndef __CONVLANG_H
#define __CONVLANG_H

#include <cpplib/ivrit.h>

/*
	This unit contains utility routines for converting between the 'real' Hebrew
		and the Hebrew in our morphological-analyzer (the English-transcription).
*/

/*******************************************************************************/
/*********      Hebrew-English letter translation     **************************/
/*******************************************************************************/

uchar heb2eng(uchar c);
uchar eng2heb(uchar c);

void heb2eng(StringTemp& s);
void eng2heb(StringTemp& s);
void fonemic2eng (StringTempCR source, StringTemp& target);

extern CStr hebrew_english_letters;  // the English letters used for Hebrew-tranliteration


#endif
