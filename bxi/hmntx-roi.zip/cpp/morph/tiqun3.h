/* tiqun3.h */

#ifndef __TIQUN3_H
#define __TIQUN3_H

#include <morph/corpus.h>


void lmad_tiqunim (CStr input_filename, CStr correct_analysis_filename, int min_tiqun_score=3);
void qra_tiqunim (CStr thepath);
void ktov_tiqunim (CStr thepath);
void ktov_tiqunim_barur (CStr thepath);


struct CorpusImTiqunim: public Corpus {
	void taqen_nituxim (Index start_from_word_num=0);  
		// mtaqqen ^et ha-nitux_jelanu lpi ha-tiqunim $e-nilmdu ^o niqr^u.
};

#endif
