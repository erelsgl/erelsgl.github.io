/* sntncas.cpp -- mnattex taxbiri l-&ibrit, &im sikkuyim.
		mi$tamme$ b-^algoritm "BOTTOM-UP CHART-PARSING" 
			[cf. JAMES ALLEN: NATURAL LANGUAGE UNDERSTANDING, 2nd ed., 1995, & 3.4]
*/

#include <morph/sntncas.h>
#include <morph/mip.h>
#include <morph/cimcumim.h>
#include <cpplib/vector1.hxx>
#include <cpplib/array2.hxx>
#include <cpplib/queue2.hxx>
#include <cpplib/matrix1.hxx>
#include <math.h>




extern ofstream sntncanllogfile;



double ciyun (SentenceInfoCR the_partially_analyzed_sentence) {
	if (the_partially_analyzed_sentence.count()==0) return 0;
	LOOPVECTOR (double acc=1,the_partially_analyzed_sentence,w) {
		MorphInfoCR curword = the_partially_analyzed_sentence[w];

		if (curword.otiotyaxas()!=NO_OY)
			acc *= 0.5;

		if (curword.heleqdiber()!=POAL && curword.heleqdiber()!=MILAT_XIBUR)
			acc *= 0.5;
		else if ( lapoal_yej_nose(curword) || lapoal_yej_musa_yajir(curword) )
			acc *= 1;
		else 
			acc *= 0.9;
	}
	return acc;
}


double ciyun0 (SentenceInfoCR the_partially_analyzed_sentence) {
	if (the_partially_analyzed_sentence.count()==0) return 0;
	return pow (0.5, the_partially_analyzed_sentence.count() );
}



/*************       mibnei &ezr              ****************************/
/*************       mibnei &ezr              ****************************/
/*************       mibnei &ezr              ****************************/


/*--------------------- Constituent -------------------------*/
/*--------------------- Constituent -------------------------*/

struct Constituent {               
  	MorphInfo word;
	Index from, to;
	Constituent() {}
	Constituent(MorphInfoCR theword, Index thefrom, Index theto): word(theword), from(thefrom), to(theto) { }
};
typedef const Constituent& ConstituentCR;
inline void free (Constituent& m) { };
inline void write (ostream& out, ConstituentCR thecons, Format format="") {
	out << thecons.word << ":" << thecons.from << "=>" << thecons.to;
}
inline void read (istream& in, Constituent& thecons, Format format="") {
	// not implemented
}
inline bool identical (ConstituentCR  a, ConstituentCR b) {
	return (a.from==b.from && a.to==b.to && identical(a.word,b.word)); }

DEFINE_INLINE_IO_OPERATORS(Constituent)





/*--------------------- ActiveArc -------------------------*/
/*--------------------- ActiveArc -------------------------*/

struct ActiveArc {         
	const XoqCimcum* xoq_p;
	XoqCimcumCR xoq() const { return *xoq_p; }

	SentenceInfo the_partial_sentence;

	Index from, to;

	ActiveArc (): the_partial_sentence(4) {}
	void set (XoqCimcumCR thexoq, Index thefrom, Index theto) { 
		xoq_p=&thexoq; from=thefrom; to=theto; 
		the_partial_sentence.truncate(); 
	}
	ActiveArc (XoqCimcumCR thexoq, Index thefrom, Index theto): the_partial_sentence(4) { set(thexoq,thefrom,theto); }

	bool is_complete () const {
		return the_partial_sentence.count()==xoq().ork();        // ha-nquda nimce^t b-sop ha-xoqq.
	}

	bool match (MorphInfoCR theword) const {
		return xoq().tavniot[the_partial_sentence.count()].match(theword);
	}

	bool can_be_extended_by (ConstituentCR thecons) const {
		return (to==thecons.from && match(thecons.word) );
	}

	status extend_by (ConstituentCR thecons)  {
		to = thecons.to;
		return the_partial_sentence.append(thecons.word);
	}

	bool can_become_a_complete_constituent (Constituent& thecons) {
		if (!xoq().match(the_partial_sentence,0, thecons.word)) return false;
		thecons.from = from;  thecons.to = to;
		return true;
	}
};
typedef const ActiveArc& ActiveArcCR;
inline void duplicate (ActiveArc& target, ActiveArcCR source) {
	target.xoq_p = source.xoq_p;
	target.to = source.to;  target.from=source.from;
	duplicate(target.the_partial_sentence, source.the_partial_sentence);
}
inline void duplicate2 (ActiveArc& target, ActiveArcCR source) {
	target.xoq_p = source.xoq_p;
	target.to = source.to;  target.from=source.from;
	if (target.the_partial_sentence.size() < source.the_partial_sentence.len())
		duplicate(target.the_partial_sentence, source.the_partial_sentence);
	else {
		LOOPVECTOR(;,source.the_partial_sentence,w) 
			target.the_partial_sentence[w] = source.the_partial_sentence[w];
		target.the_partial_sentence.truncate(source.the_partial_sentence.len());
	}
}
inline void free (ActiveArc& a) { 
	free(a.the_partial_sentence); 
}




typedef Array2<ActiveArc> SimpleArrayOfActiveArcs;

// This structure stores the arcs according to the "to" field.
struct ArrayOfActiveArcs {
	Vector1 < SimpleArrayOfActiveArcs >  thearcs;
	const SimpleArrayOfActiveArcs& arcs_that_maybe_can_be_extended_by(ConstituentCR thecons) const{
		return thearcs[thecons.from]; }
	status append (ActiveArcCR thearc) { return thearcs[thearc.to].append(thearc); }
	status reset (Size thesize) { return thearcs.reset(thesize); }
};
void free (ArrayOfActiveArcs& aoaa) { free(aoaa.thearcs); }



typedef Array2<Constituent> SimpleArrayOfConstituents;

// This structure stores the constituents according to the "from" field.
struct ArrayOfConstituents {
	Vector1 < SimpleArrayOfConstituents >  theconstituents;
	const SimpleArrayOfConstituents& constituents_that_maybe_can_extend(ActiveArcCR thearc) const {
		return theconstituents[thearc.to]; }
	status append (ConstituentCR thecons) { return theconstituents[thecons.from].append(thecons); }
	status reset (Size thesize) { return theconstituents.reset(thesize); }
};
void free (ArrayOfConstituents& aoc) { free(aoc.theconstituents); }




/*--------------------- SentenceOptionsWithCiyun -------------------------*/
/*--------------------- SentenceOptionsWithCiyun -------------------------*/
// This structure contains sentence-options which all have the same ciyun.

class SentenceOptionsWithCiyun: public SentenceOptions {
	double the_ciyun;
public:
	static SentenceInfo a_new_option;
	SentenceOptionsWithCiyun():  SentenceOptions(0), the_ciyun(0.) {}
	status append (SentenceInfoCR the_new_option) {
		double the_new_ciyun = ciyun0(the_new_option);
		if (the_new_ciyun > the_ciyun) {  // The new option is better, so throw away all current options...
			free(myinfo);  truncate();
			SentenceInfo to_append;  duplicate(to_append,the_new_option);
			the_ciyun = the_new_ciyun;
			return SentenceOptions::append(to_append);
		}
		else if (the_new_ciyun == the_ciyun) { // The new option is equivalent, so append it.
			if (!contains(*this,the_new_option)) {
				SentenceInfo to_append;  duplicate(to_append,the_new_option);
				return SentenceOptions::append(to_append);
			}
			else return OK;
		}
		else {                            // The new option is worse, so do nothing.
			return OK;
		}
	}


	status append (MorphInfo the_word) {         // append a sinlge-word option
		a_new_option.truncate();	
		DOr(a_new_option.append(the_word));
		return append(a_new_option);
	}

	status append (SentenceInfoCR firsthalf, SentenceInfoCR secondhalf) {  //  concat the halves and append the result
		a_new_option.truncate();
		DOr(a_new_option.append(firsthalf));
		DOr(a_new_option.append(secondhalf));
		return append(a_new_option);
	}

	status append (SentenceOptionsCR firsthalfoptions, SentenceOptionsCR secondhalfoptions) {
		LOOPVECTOR(;,firsthalfoptions,i) {
			LOOPVECTOR(;,secondhalfoptions,j) {
				DOr(append(firsthalfoptions[i], secondhalfoptions[j])); }}
		return OK;
	}

};


SentenceInfo SentenceOptionsWithCiyun::a_new_option;



/*--------------------- PartialSentences -------------------------*/
/*--------------------- PartialSentences -------------------------*/
// Each SentenceOptions keeps all best-options found so far for 
//	analyzing the part of the sentence between "row" and "col+1". (i.e. row==from, col==to-1)

struct PartialSentences: Matrix1<SentenceOptionsWithCiyun> {

	PartialSentences() {}

	PartialSentences (SentenceInfo the_whole_sentence): 
		Matrix1<SentenceOptionsWithCiyun>(the_whole_sentence.count(), the_whole_sentence.count()) 
	{
		::free (SentenceOptionsWithCiyun::a_new_option);
		SentenceOptionsWithCiyun::a_new_option.reset(the_whole_sentence.count());
	}

	status append (ConstituentCR thecons) {
		return at(thecons.from, thecons.to-1).append(thecons.word);
	}


	status create_whole_sentences (Size the_wordcount) {
		// Algorithm: create partial-sentences of increasing lengths.
		// PRECONDITION: all partial sentence of length 1 are already in the table 
		//		(they were inserted when the corresponding Constituents were removed from the agenda).
		for (Index PSL=2; PSL<=the_wordcount; ++PSL) {  // PSL==Partial Sentence Length
			// INVARIANT: the partial-sentences of length < PSL are already in the table.
			Index from, to;
			for (from=0, to=PSL; to<=the_wordcount; ++from, ++to)  {
				SentenceOptionsWithCiyun& the_options = at(from,to-1);
				for (Index middle=from+1; middle<=to-1; ++middle) {
					SentenceOptionsCR firsthalfoptions = at(from,middle-1);
					SentenceOptionsCR secondhalfoptions = at(middle,to-1);
					DOr( the_options.append (firsthalfoptions, secondhalfoptions) );
				}
			}
		}
		return OK;
	}

};




/********************************************************************************/
/*************       Sentence Analyzer               ****************************/
/********************************************************************************/


struct SentenceAnalyzer {

	Size the_wordcount;

	SentenceOptions* the_final_options_p;
	#define the_final_options (*the_final_options_p)

	Queue2<Constituent> the_complete_constituents;      // the "agenda"
	ArrayOfActiveArcs  the_active_arcs;
	ArrayOfConstituents  the_old_constituents;

	PartialSentences the_partial_sentences;

	static ActiveArc a_new_active_arc;
/*
	status start (SentenceInfoCR the_sentence, SentenceOptions& the_options) {
		//DOr(the_sentence.hafred_txiliot (the_original_sentence));
		duplicate(the_original_sentence, the_sentence);
		DOr(the_partial_sentences.reset (the_original_sentence.count(), the_original_sentence.count() ));
		DOr(the_active_arcs.reset (the_original_sentence.count()));
		free (the_options);
		the_final_options_p = &the_options;
		writeln (sntncanllogfile,the_original_sentence);
		return OK;
	}
*/

	status start (Size the_original_wordcount, SentenceOptions& the_options) {
		the_wordcount = the_original_wordcount;
		DOr(the_partial_sentences.reset (the_wordcount,the_wordcount) );
		DOr(the_active_arcs.reset (the_wordcount));
		DOr(the_old_constituents.reset (the_wordcount));
		free (the_options);
		the_final_options_p = &the_options;
		return OK;
	}

	status finish() {
		free(the_complete_constituents);
		free(the_active_arcs);
		free(the_old_constituents);
		free(the_partial_sentences);
		writeln (sntncanllogfile,the_final_options,Format("*\n"));  sntncanllogfile<<endl<<endl<<endl;
		return OK;
	}


	status extend_the_new_active_arc_and_append_it (ConstituentCR thecons) {
		a_new_active_arc.extend_by(thecons);
		if (!a_new_active_arc.is_complete()) {
			ActiveArc to_append;  duplicate(to_append, a_new_active_arc);
			DOr(the_active_arcs.append(to_append)); 
			return try_to_extend_arc_by_old_constituents(to_append);
		}
		else {
			Constituent the_new_cons;
			if (a_new_active_arc.can_become_a_complete_constituent(the_new_cons)) {
				if (!contains(the_complete_constituents,the_new_cons)) {
					DOr (the_complete_constituents.enqueue(the_new_cons)); }}
			return OK;
		}
	}


	status try_to_extend_arc_by_old_constituents (ActiveArcCR thearc) {
		const SimpleArrayOfConstituents& cur_constituents = the_old_constituents.constituents_that_maybe_can_extend(thearc);
		LOOPVECTOR(;,cur_constituents,c) {
			if (thearc.can_be_extended_by(cur_constituents[c])) {
				duplicate2(a_new_active_arc,thearc);
				DOr (extend_the_new_active_arc_and_append_it(cur_constituents[c]));
			}
		}
		return OK;
	}


	status add_new_active_arcs (ConstituentCR cur_constituent) {
		LOOPVECTOR (;,hacimcumim,j) {   
			LOOPVECTOR (;,hacimcumim[j],xc) {
				XoqCimcumCR cur_xoq = hacimcumim[j][xc];  if (cur_xoq.is_mdume()) continue;
				a_new_active_arc.set (cur_xoq,cur_constituent.from,cur_constituent.from);
				if (a_new_active_arc.can_be_extended_by (cur_constituent)) {
					DOr (extend_the_new_active_arc_and_append_it(cur_constituent));
				}
			}
		}
		return OK;
	}

	status update_active_arcs (ConstituentCR cur_constituent) {
		const SimpleArrayOfActiveArcs& cur_arcs = the_active_arcs.arcs_that_maybe_can_be_extended_by(cur_constituent);
		LOOPVECTOR (;,cur_arcs,a) {  
			if (cur_arcs[a].can_be_extended_by(cur_constituent)) {
				duplicate2(a_new_active_arc,cur_arcs[a]);
				DOr (extend_the_new_active_arc_and_append_it(cur_constituent));
			}
		}
		return OK;
	}


	status create_final_options () {
		DOr(the_partial_sentences.create_whole_sentences(the_wordcount));  // This line does NOT cause any memory-leak!
		writeln (sntncanllogfile,the_partial_sentences);
		duplicate ( the_final_options, the_partial_sentences.at(0,the_wordcount-1) );
		return OK;
	}


	status natax_et_kol_hacerufim (ArrayOfMOWSCR the_original_sentence, SentenceOptions& the_options) {
		DOr(start(the_original_sentence.count(),the_options));
		LOOPVECTOR (;,the_original_sentence,w)  {
			MorphOptionsWithSikuiCR curword = the_original_sentence[w];
			LOOPVECTOR(;,curword,o) {
				DOr(the_complete_constituents.enqueue (
					Constituent(curword.info(o),w,w+1)));
			}
			for (;;) {
				if (the_complete_constituents.isempty()) break;
				Constituent cur_constituent = the_complete_constituents.athead();
				LOG(sntncanllogfile, cur_constituent<<" ");
				DOr(update_active_arcs(cur_constituent));
				DOr(add_new_active_arcs(cur_constituent)); 
				DOr(the_partial_sentences.append(cur_constituent));
				DOr(the_old_constituents.append(cur_constituent));
				the_complete_constituents.dequeue();
			}
			LOG(sntncanllogfile,endl);
		}
		DOr(create_final_options());
		return finish();
	}

	status natax_et_haceruf_hasavir_bioter (ArrayOfMOWSCR the_original_sentence, SentenceOptions& the_options) {
		DOr(start(the_original_sentence.count(),the_options));
		LOOPVECTOR (;,the_original_sentence,w)  {
			MorphOptionsWithSikuiCR curword = the_original_sentence[w];
			DOr(the_complete_constituents.enqueue (
				Constituent(curword.info(0),w,w+1));
			for (;;) {
				if (the_complete_constituents.isempty()) break;
				Constituent cur_constituent = the_complete_constituents.athead();
				LOG(sntncanllogfile, cur_constituent<<" ");
				DOr(update_active_arcs(cur_constituent));
				DOr(add_new_active_arcs(cur_constituent)); 
				DOr(the_partial_sentences.append(cur_constituent));
				DOr(the_old_constituents.append(cur_constituent));
				the_complete_constituents.dequeue();
			}
			LOG(sntncanllogfile,endl);
		}
		DOr(create_final_options());
		return finish();
	}

};


ActiveArc SentenceAnalyzer::a_new_active_arc;



/*******************************************************************/
/*********  public routines						      **************/
/*******************************************************************/

bool the_sentence_analyzer_is_initialized = false;

void initialize_the_sentence_analyzer (CStr path_to_cimcumim) {
	assert (OK==read_the_cimcumim(path_to_cimcumim) );
	the_sentence_analyzer_is_initialized = true;
}

double ciyun_gavoh_bioter (SentenceOptionsCR the_options) {
	LOOPVECTOR (double cur=0, the_options, o)
		if (ciyun(the_options[o]) > cur)
			cur = ciyun(the_options[o]);
	return cur;
}

void mxaq_et_hanituxim_hapaxot_tovim (SentenceOptions& the_options, double the_ciyun_saf) {
	LOOPVECTOR(;, the_options, o) {
		while (ciyun(the_options[o]) < the_ciyun_saf  &&  o<the_options.count()) {
			the_options.removeat(o);    
		}
	}
}


void natax (ArrayOfMOWSCR thesentence, SentenceOptions& theoptions) {
	assert (the_sentence_analyzer_is_initialized);
	SentenceAnalyzer myanalyzer;
	DOx(myanalyzer.natax(thesentence, theoptions));
}
/*
double ciyun_hanitux_hataxbiri_hatov_bioter (SentenceInfoCR the_sentence) {
	SentenceOptions the_options;
	natax (the_sentence,the_options);
	double CGB = ciyun_gavoh_bioter(the_options);
	free (the_options);
	return CGB;
}
*/

/*******************************************************************************************************/
/****************  SELF TEST          ******************************************************************/
/*******************************************************************************************************/


#ifdef TEST_SNTNCAS

#include <cpplib/sentence.h>
#include <morph/hpmaio2.h>
#include <morph/alghist.h>
#include <morph/tiqun2.h>
#include <morph/mn.h>

#define LOG_PATH "..\\..\\..\\harc\\"

void atxel_klali() {
	atxel_global_database (NULL, LOG_PATH "harc10.nts");
	atxel_local_database (NULL,  LOG_PATH "harc10a.nts");
	read_the_cimcumim(LOG_PATH);
	//atxel_tiqunim (LOG_PATH);
	atxel_tiqunim_from_cimcumim ();
	adken_tiqunim (LOG_PATH "harc10.to");
	ktov_tiqunim (LOG_PATH);
	adken_monei_zugot_nituxim (LOG_PATH "harc10.to");
	open_logfile(1); ktov_monei_zugot_nituxim(logfile); logfile.close();
}




void bdoq() {
	Sentence cursentence(500);
	ArrayOfMOWS cursentence_eachword_options;
	SentenceOptions cursentence_options;
	for(;;) {
		DOEOFx(read_and_analyze_the_next_sentence (input, cursentence, cursentence_eachword_options));
		taqen_sikuiim_zugot (cursentence_eachword_options);

		//LOG (errorlogfile,cursentence.word(0).str << "...: ");
		//DOx(convert_eachword_options_to_sentence_options (cursentence_eachword_options, 5, cursentence_options));
		natax(cursentence_eachword_options,cursentence_options);
		LOG (logfile,cursentence_eachword_options<<endl<<endl<<cursentence<<endl);
		writeln (logfile,cursentence_options, Format("*\n"));  writeln (cout,cursentence_options, Format("*\n"));
		logfile << endl << endl << endl;
	}
}

/*
void bdoq_zikkaron() {
	SentenceInfo the_sentence_info;
	SentenceOptions the_sentence_options;
	DOx(the_sentence_info.read(correct_analysis));
	SentenceAnalyzer myanalyzer;
	for(Index i=0;;i++) {
		DOx(myanalyzer.natax(the_sentence_info, the_sentence_options));
		LOG (logfile,i<<endl);
		writeln (logfile,the_sentence_options, Format("*\n"));
		writeln (cout,the_sentence_options, Format("*\n"));
		LOG (logfile,endl<<endl<<endl);
	}
}
*/

void main (int argc, char* argv[]) {
	set_synopsis ("SNTNCANL source.TXT source.TO [/t path-to-cimcumim]");
	parse_command_line (argc,argv,2,2,"t","");
	CStr path_to_cimcumim = log_path = option('t')==NULL? ".": option('t');
	initialize_the_sentence_analyzer (path_to_cimcumim);
	atxel_klali();
	open_logfile(0);
	open_sntncanllogfile(log_path);
	open_infile_with_messages (concat_path_to_filename(log_path,variable(0)).str,input);
	open_infile_with_messages (concat_path_to_filename(log_path,variable(1)).str,correct_analysis);
	bdoq();
}

#endif
