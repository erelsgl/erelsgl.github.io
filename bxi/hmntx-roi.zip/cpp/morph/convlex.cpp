/* convlex.cpp */


#include <morph/lexicon.h>
#include <cpplib/cmdline1.h>

void main (int argc, char* argv[]) {
	parse_command_line (argc,argv,2,2,"","");
	read_the_lexicon (variable(0));
	write_the_lexicon (variable(1));
}
