/* lexinf.cpp */

#include <morph/lexinf.h>


