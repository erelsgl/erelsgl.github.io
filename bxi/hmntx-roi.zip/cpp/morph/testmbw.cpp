/* testmbw.cpp -- test mone baseword */

#include <morph/mone-bw.h>

void main (void) {
	MorphInfo mibe1("$BR",ECEM), mibe2("AXD",ECEM);
	MorphInfo mibp1("$BR",POAL), mibt1("AXD",TOAR);
	MoneBaseword thecounter; writeln (cout,thecounter);
	EXEC(thecounter.setcount(mibe1,1000));    writeln (cout,thecounter);
	EXEC(thecounter.setcount(mibp1,1000));    writeln (cout,thecounter);
	EXEC(thecounter.add(mibe1));    writeln (cout,thecounter);
	EXEC(thecounter.add(mibp1));    writeln (cout,thecounter);
	EXEC(thecounter.add(mibt1));    writeln (cout,thecounter);
	EXEC(thecounter.add(mibe2));    writeln (cout,thecounter);
	EXEC(thecounter.setcount(mibe1,500));    writeln (cout,thecounter);
}
