/* alghist.cpp -- algoritm histabbruti l-xi$$uv ha-nittux ha-sabir bioter */

#include <cpplib/wordcnt.h>
#include <iomanip.h> 
#include <morph/morphst2.h>
#include <morph/morphanl.h>
#include <morph/similar.h>
#include <morph/alghist.h>
#include <morph/bw2fw.h>
#include <morph/mone-nit.h>
#include <morph/mone-bw.h>

#include <morph/hpmaio.h>


/***************************************************************************/
/**********        The Databases                                    ********/
/***************************************************************************/

BasewordToFullwordMap the_bw2fw_map;
	// maps each baseword to all it's derived fullwords. See the file morph/bw2fw.h

struct GlobalDatabase {
	MorphOptionsWithSikuiTrie hmyda_hmqorv;
		// this database contains, for each word, the approximate sikui for each option, 
		//	as calculated by the algorithm. See the file morph/morphst.h
	MorphOptionsWithSikuiTrie hmyda_hamiti;
		// this database contains, for each word, the number of real analyses (approved by the user)
		//	for each option-index. See the file morph/morphst.h
	WordCounter mone_milim_jlmot;
		// counts full-words in the corpus. See the file cpplib/wordcnt.h
	MoneBaseword mone_arkim_miloniim;
		// counts basewords (ignoring analyses). See the file morph/mone-bw.h
	MoneNituxim mone_nituxim;
		// counts analyses (ignoring lexical-values). See the file morph/mone-nit.h

	uint total_word_count;

	bool idkun_mone_nituxim;
		// controls updating of "the-mone-nituxim" during "xjv_sikuiim_lkol_hmilim".

	bool xijuv_jaqet; 
		// controls message-displaying during "xjv_sikuiim_lkol_hmilim".
	bool xijuv_jaqet_meod;
		// controls logging during "xjv_sikuiim".


	#define LOOP_OVER_ALL_THE_WORDS(cursor) for (MorphOptionsWithSikuiTrie::Cursor cursor(hmyda_hmqorv);  cursor.isvalid();  ++cursor)

	bool isempty() const { return total_word_count==0; }

	MorphOptionsWithSikui analysis_with_approximate_sikuiim (CStr hamila) {
		MorphOptionsWithSikui theoptions;
		if (!hmyda_hmqorv.contains(hamila, theoptions)) {
			theoptions = natax_im_sikui_axid(hamila); 
			if (!last_analysis_used_the_default()) {
				hmyda_hmqorv.insert(hamila,theoptions);
				mone_milim_jlmot.insert(hamila);
				xjv_sikuiim(hamila,true /* maher */ );
			}
		}
		return theoptions;
	}

	MorphOptionsWithSikui independent_analysis_with_approximate_sikuiim (CStr hamila) {
		return duplicate
			(analysis_with_approximate_sikuiim(hamila));
	}



	/****************** Database update ******************************/
	/******             Database update             ******************/
	/****************** Database update ******************************/

	status adkn (CStr hamila, MorphInfoCR hanitux) {
		DOr(hmyda_hamiti.insert (hamila,hanitux));
		DOr(mone_milim_jlmot.remove_one (hamila));
		return OK;
	}

	status adkn (CStr hamila, MorphOptionsWithSikuiCR theoptions) {
		DOr(hmyda_hmqorv.insert(hamila,theoptions));
		DOr(hmyda_hamiti.insert(hamila,theoptions));
		return OK;
	}

	status havr_mila_axt_mhmyda_hmqorv_lmyda_hamiti (CStr hamila, MorphOptionsWithSikuiCR the_realistic_options) {
		DOx(hmyda_hamiti.add (hamila,the_realistic_options));
		DOx(mone_milim_jlmot.remove_one (hamila));
		return OK;
	}

	void adkn_monim () { // m&adkn ^et 2 ha-monim (erk-miloni, nituxim)
		// loop over all the words in the corpus, and insert all distinct MorphInfoBasic's to the analysis counter. 
		if (idkun_mone_nituxim) {
			LOOP_OVER_ALL_THE_WORDS(cursor1) {
				CStr cur_fullword = cursor1.string().str;
				MorphOptionsWithSikui cur_options = hmyda_hmqorv.item(cur_fullword);
				LOOPVECTOR(;,cur_options,i) 
					mone_nituxim.setcount(cur_options.info(i),0);
			}
		}
		mone_arkim_miloniim.zero_all();
		
		// loop over all the words in the corpus, and if they are similar to the main_word -- add their probabilities to the sums. 
		LOOP_OVER_ALL_THE_WORDS(cursor) {
			CStr cur_fullword = cursor.string().str;
			logfile << cur_fullword << "; "; logfile.flush();
			MorphOptionsWithSikuiCR cur_options = hmyda_hmqorv.item(cur_fullword);
			uint cur_count = mone_milim_jlmot.count(cur_fullword);
			MorphOptionsWithSikuiCR cur_options_real = hmyda_hamiti.item(cur_fullword);
			LOOPVECTOR(;,cur_options,i) {
				Sikui cur_sikui = (Sikui)(cur_options.sikui(i) * (cur_count+0.5) + 
									cur_options_real.sikui(i));
				mone_arkim_miloniim.add(cur_options.info(i), cur_sikui);
				if (idkun_mone_nituxim) mone_nituxim.add_exact(cur_options.info(i), cur_sikui);
			}
		}
	}


	void qra_mone_nituxim (CStr thefilename) {
		ifstream input;
		open_infile_with_messages (thefilename,input);
		assert (OK==read(input,mone_nituxim));
		input.close();
		idkun_mone_nituxim = false;
	}



	/**************************** sfor-sikuiim ************************************/
	/***********                  sfor-sikuiim                        *************/
	/**************************** sfor-sikuiim ************************************/

	// en == &erk-milloni + nittux
	// e  == &erk-milloni
	// n  == nittux

	ArrayOfSikuiim 
		sikuiim_en,
		sikuiim_e,
		sikuiim_n,
		sikuiim_mjuqllim;

	double 
		mjql_en; 

	// count-similar-words for one main MorphOptions, in the entire database.
	// This function should be called only after 'adkn_monim' has been called.
	void sfor_sikuiim_mhr (CStr main_word, MorphOptionsWithSikuiCR main_options_s) {
		/*** ^atxel ^et veq@orei ha-toca^a ***/
		atxel (sikuiim_en,main_options_s.count() );
		atxel (sikuiim_e,main_options_s.count() );
		atxel (sikuiim_n,main_options_s.count() );
		LOOPVECTOR (;, main_options_s, i) {
			MorphInfoCR cur_option = main_options_s.info(i);
			sikuiim_en[i] += (Sikui)(main_options_s.sikui(i) * (mone_milim_jlmot.count(main_word)+0.5)
							 +	hmyda_hamiti.sikui(main_word,i));
			sikuiim_n[i] += mone_nituxim.count(cur_option);
			sikuiim_e[i] += mone_arkim_miloniim.count(cur_option);
		}
	}


	void sfor_sikuiim (CStr main_word, MorphOptionsWithSikuiCR main_options_s, bool mhr) {
		//if (mhr)
			sfor_sikuiim_mhr (main_word, main_options_s);
		//else 
		//	sfor_sikuiim (main_word, main_options_s);
	}


	/**************************** xjv-sikuiim ************************************/
	/*********                    xjv-sikuiim                         ************/
	/**************************** xjv-sikuiim ************************************/


	void jqll_sikuiim (MorphOptionsWithSikui main_options_s) {
			atxel (sikuiim_mjuqllim,main_options_s.count());

			normalize (sikuiim_n,1000.,1.);
			normalize (sikuiim_e,1000.,1.);
			set (sikuiim_mjuqllim,sikuiim_n,1);
			multiply_ew (sikuiim_mjuqllim,sikuiim_e);

			normalize (sikuiim_mjuqllim,1000.,1.);
			normalize (sikuiim_en,1000.,1.);
			add (sikuiim_mjuqllim,sikuiim_en, mjql_en);
	}



	// calculate sikuiim of all the analyses of the main_word, and adkn the database
	virtual void xjv_sikuiim (CStr main_word, bool mhr) {
		MorphOptionsWithSikui main_options_s = hmyda_hmqorv.item(main_word);
		if (main_options_s.count()<=1)  return;      // no need to calculate probabilities
		if (!xijuv_jaqet_meod) logfile << endl << main_word << (mhr? "| ": ": ");
		sfor_sikuiim (main_word, main_options_s, mhr);
		if (!xijuv_jaqet_meod) logfile << "GLOBAL  en " << sikuiim_en << "  e " << sikuiim_e << "  n " << sikuiim_n << endl;
		jqll_sikuiim (main_options_s);
		if (!xijuv_jaqet_meod) logfile << "GLOBAL  en " << sikuiim_en << "  e " << sikuiim_e << "  n " << sikuiim_n << "  sh\"k " << sikuiim_mjuqllim << endl;
		main_options_s.set (sikuiim_mjuqllim);
		hmyda_hmqorv.insert (main_word,main_options_s);   // adkn the database
		if (!xijuv_jaqet_meod) logfile << " " << main_options_s << endl;
	}

	void xjv_sikuiim_lkol_hmilim () {
		adkn_monim();
		LOOP_OVER_ALL_THE_WORDS(cursor) {
			if (!xijuv_jaqet)
				cerr << cursor.string() << " ";
			xjv_sikuiim (cursor.string().str, true);  // xjv siukuiim mhr.
		}
	}


	bool contains_sbwsast (MorphOptionsWithSikuiCR theoptions, MorphInfoCR theinfo) {
		LOOPVECTOR (;,theoptions,i)
			if (are_SBW_SA_ST(theoptions.info(i),theinfo)) return true;
		return false;
	}

	void xjv_sikuiim_lkol_hmilim_im_sbwsast (MorphInfoCR theinfo) {
		FullwordArray& the_fullword_array = the_bw2fw_map.fullword_array(theinfo.baseword());
		bool there_are_many_fullwords = the_fullword_array.count() > 10;
		if (there_are_many_fullwords) 
			adkn_monim(); 
		for (FullwordArray::Cursor cursor(the_fullword_array); cursor.isvalid(); ++cursor) {
			CStr cur_fullword = cursor.item();
			MorphOptionsWithSikui& curoptions = *(hmyda_hmqorv.itemp(cur_fullword));
			if (contains_sbwsast(curoptions,theinfo)) {
				curoptions.set_sikui_axid();
				xjv_sikuiim (cur_fullword, there_are_many_fullwords );
			}
		}
	}



	bool contains_sbw (MorphOptionsWithSikuiCR theoptions, MorphInfoCR theinfo) {
		LOOPVECTOR (;,theoptions,i)
			if (are_SBW(theoptions.info(i),theinfo)) return true;
		return false;
	}

	void xjv_sikuiim_lkol_hmilim_im_sbw (MorphInfoCR theinfo) {
		FullwordArray& the_fullword_array = the_bw2fw_map.fullword_array(theinfo.baseword());
		bool there_are_many_fullwords = the_fullword_array.count() > 3;
		if (there_are_many_fullwords) 
			adkn_monim(); 
		for (FullwordArray::Cursor cursor(the_fullword_array); cursor.isvalid(); ++cursor) {
			xjv_sikuiim (cursor.item(), there_are_many_fullwords );
		}
	}


	/****************** Database I/O ******************************/
	/********           Database I/O                  *************/
	/****************** Database I/O ******************************/


	GlobalDatabase(): 
		hmyda_hmqorv(), 
		hmyda_hamiti(),
		mone_milim_jlmot(),
		mone_arkim_miloniim(),
		mone_nituxim(),
		sikuiim_en(20),
		sikuiim_e(20),   
		sikuiim_n(20),
		sikuiim_mjuqllim(20)
		{ 
			xijuv_jaqet = xijuv_jaqet_meod = false;
			idkun_mone_nituxim = true;
			mjql_en = 1.;
		}


	void log_the_database (ofstream& logfile) {
		//hmyda_hmqorv.remove(":");
		//hmyda_hamiti.remove(":");
		//mone_milim_jlmot.remove(":");
		logfile << total_word_count << endl;  
		writeln (logfile, hmyda_hmqorv);
		writeln (logfile, mone_milim_jlmot);
		writeln (logfile, mone_arkim_miloniim);
		writeln (logfile, mone_nituxim);
		writeln (logfile, hmyda_hamiti);
	}

	void log_the_database_qcr (ofstream& logfile) {
		//logfile << total_word_count << endl;  
		logfile << 0 << endl;  
		//writeln (logfile, hmyda_hmqorv);
		logfile << "{}" << endl;
		//writeln (logfile, mone_milim_jlmot);
		logfile << "{}" << endl;
		writeln (logfile, mone_arkim_miloniim);
		writeln (logfile, mone_nituxim);
		//writeln (logfile, hmyda_hamiti);
		logfile << "{}" << endl;
	}

	void atxl_myda_amiti() {
		LOOP_OVER_ALL_THE_WORDS(cursor) {
			CStr cur_fullword = cursor.string().str;
			MorphOptionsWithSikui cur_options; 
			duplicate (cur_options,hmyda_hmqorv.item(cur_fullword));
			cur_options.zero();
			hmyda_hamiti.insert(cur_fullword,cur_options);
		}
	}

	void atxl_mqovc_log (CStr analysis_with_sikui_filename) {
		ifstream input;
		open_infile_with_messages (analysis_with_sikui_filename,input);
		cerr << "\treading total_word_count:" << endl;
		assert (OK==read(input,total_word_count));
		cerr << "\treading hmyda_hmqorv:" << endl;
		assert (OK==read(input,hmyda_hmqorv));
		cerr << "\treading mone_milim_jlmot:" << endl;
		assert (OK==read(input,mone_milim_jlmot));	
		cerr << "\treading mone_arkim_miloniim:" << endl;
		assert (OK==read(input,mone_arkim_miloniim));
		cerr << "\treading mone_nituxim:" << endl;
		assert (OK==read(input,mone_nituxim));
		cerr << "\treading hmyda_hamiti:" << endl;
		assert (OK==read(input,hmyda_hamiti));
	}

	void atxl_mqovc_txt (CStr input_filename) {
		ifstream input;
		open_infile_with_messages (input_filename,input);
		cerr << endl << "counting words in input file " << input_filename << endl;
		mone_milim_jlmot.count_words_in_file(input);
		open_infile_with_messages (input_filename,input);
		default_heleq_diber=JEM_PRATI;
		DOx(hmyda_hmqorv.analyze_words_in_file (input));
		total_word_count = mone_milim_jlmot.wordcount();
		mone_milim_jlmot.remove("*");
		hmyda_hmqorv.remove("*");
		atxl_myda_amiti();
	}

	void atxl_mnitux_nkon (CStr input_filename, CStr output_filename) {
		if (mone_milim_jlmot.wordcount()<=1)
			atxl_mqovc_txt(input_filename);
		ifstream correct_analysis, input;
		cerr << "reading correct output file " << output_filename << endl;
		open_infile_with_messages (output_filename,correct_analysis);
		open_infile_with_messages (input_filename,input);
		StringTemp curword(30);
		MorphInfo curanalysis;
		for(int wordnum=0;;++wordnum) {
			skip_spaces_and_stars(correct_analysis);  
			if (correct_analysis.eof()) break;
			DOEOFx (read(correct_analysis,curanalysis));
			skip_spaces_and_stars(input);			
			DOEOFx (curword.readword(input));
			if (wordnum%100==0) cerr << (wordnum/100) << " " << curword << " ";
			if (adkn(curword.str,curanalysis) != OK) {
				cerr << "$GIAH BMILH " << curword << ": HNITUX " << curanalysis << " LA NMCA!" << endl;
				lexlogfile << curword << ": " << curanalysis << endl;
			}
		}
		correct_analysis.close();
		input.close();
	}


	void atxl (CStr input_filename, CStr analysis_counter_filename, CStr analysis_with_sikui_filename) {
		ifstream input;
		if (analysis_with_sikui_filename!=NULL) 
			atxl_mqovc_log (analysis_with_sikui_filename);
		else 
			atxl_mqovc_txt (input_filename);
		if (analysis_counter_filename!=NULL) 
			qra_mone_nituxim (analysis_counter_filename);
	}
}; // end of class GlobalDatabase

GlobalDatabase globaldb;	// The global DB holds the data about the whole corpus.


/***************************************************************************/
/**********        atxl the databases                              ********/
/***************************************************************************/


void atxl_bw2fw_map_global() {
	for (MorphOptionsWithSikuiTrie::Cursor cursor(globaldb.hmyda_hmqorv);  cursor.isvalid();  ++cursor) {
		CStr cur_fullword = cursor.string().duplicate();
		MorphOptionsWithSikuiCR cur_options = cursor.data();
		LOOPVECTOR (;,cur_options,i) 
			the_bw2fw_map.insert (cur_options.info(i).baseword(), cur_fullword);
	}
}


void atxl_global_database (CStr input_filename, CStr analysis_with_sikui_filename) {
	globaldb.atxl(input_filename, NULL, analysis_with_sikui_filename);
	atxl_bw2fw_map_global();
}

void qra_nitux_nakon_global (CStr input_filename, CStr output_filename) {
	globaldb.atxl_mnitux_nkon(input_filename, output_filename);
}

void qra_mone_nituxim_global (CStr input_filename) {
	globaldb.qra_mone_nituxim(input_filename);
}



void set_mjqlim_global (double mjql_en) {
	globaldb.mjql_en = mjql_en;
}



/***************************************************************************/
/**********        adkn databases                                  ********/
/***************************************************************************/


MorphOptionsWithSikui analysis_with_approximate_sikuiim (CStr hamila) {
	return globaldb.analysis_with_approximate_sikuiim(hamila);
}

MorphOptionsWithSikui independent_analysis_with_approximate_sikuiim (CStr hamila) {
	return globaldb.independent_analysis_with_approximate_sikuiim(hamila);
}


status adkn_database (CStr hamila, MorphInfoCR hanitux) {
	return globaldb.adkn (hamila, hanitux); 
}

status adkn_database (CStr hamila, MorphOptionsWithSikuiCR kol_hanituxim) {
	return globaldb.adkn (hamila,kol_hanituxim);
}


status havr_mila_axt_mhmyda_hmqorv_lmyda_hamiti (CStr hamila, MorphOptionsWithSikuiCR the_realistic_options) {
	return globaldb.havr_mila_axt_mhmyda_hmqorv_lmyda_hamiti (hamila, the_realistic_options); 
}

void ktov_global_database (CStr output_filename) { 
	ofstream output;
	open_outfile (output_filename, output, 0);
	globaldb.log_the_database_qcr(output); 
	output.close();
}

void xjv_sikuiim_lkol_hmilim_global () { 
	open_logfile(2);  globaldb.xjv_sikuiim_lkol_hmilim();  logfile.close();
}

void xjv_sikuiim_lkol_hmilim_im_sbwsast (MorphInfoCR theinfo) {
	globaldb.xjv_sikuiim_lkol_hmilim_im_sbwsast(theinfo);
}


void xjv_sikuiim_lkol_hmilim_im_sbw (MorphInfoCR theinfo) {
	globaldb.xjv_sikuiim_lkol_hmilim_im_sbw(theinfo);
}

void xjv_sikuiim (CStr main_word) {
	globaldb.xjv_sikuiim (main_word,false); }

void xjv_sikuiim_mhr (CStr main_word) {
	globaldb.xjv_sikuiim (main_word,true);        }


/***************************************************************************/
/**********        TEST ALGHIST                                     ********/
/***************************************************************************/

#ifdef TEST_ALGHIST

#include <cpplib/hcs.hxx>
#include <cpplib/sentence.h>
#include <morph/corpus.h>

#define LOG_PATH "..\\..\\..\\harc"

ofstream hcs_logfile;

Corpus the_text;


void atxl_klali_01() {
	initialize_the_analyzer(log_path,log_path);
	atxl_global_database(filename(variable(0),"txt").str, NULL);
	open_outfile (filename(variable(0),"nt0").str,logfile,0); globaldb.log_the_database(logfile); logfile.close();

	if (option('n')!=NULL)
		globaldb.atxl_mnitux_nkon(filename(option('n'),"txt").str, filename(option('n'),"to").str);

	globaldb.xijuv_jaqet = true;
	qjr_myda_mqomi_lmyda_globli();
}

void atxl_klali() {
	initialize_the_analyzer(log_path,log_path);
	atxl_global_database(NULL, filename(variable(0),"nt0").str);

	if (option('n')!=NULL)
		globaldb.atxl_mnitux_nkon(filename(option('n'),"txt").str, filename(option('n'),"to").str);

	globaldb.xijuv_jaqet = true;
	qjr_myda_mqomi_lmyda_globli();
}





class MijqalimSearcher_klali: public HillClimbingSearcher<double> {

	void init_the_parameters() {}

	double score () const {
		//globaldb.mjql_sbwsast=max(par[0],0.); globaldb.mjql_sbw=max(par[1],0.); globaldb.mjql_sast=max(par[2],0.); globaldb.mjql_yidua=max(par[3],0.); 
		globaldb.mjql_en=max(par[0],0.); 
		globaldb.hmyda_hmqorv.set_sikui_axid();
		xjv_sikuiim_lkol_hmilim_global();

		the_text.ntx_qlt_1();
		the_text.ntx_qlt_2();
		return the_text.score();
	}


	void log (double thestep, double thescore) {
		write(hcs_logfile,par);   write(cerr,par);
		LOG(hcs_logfile," " << thestep << ": " << thescore<<endl);  
	}
	
	void finish() {
		open_errorlogfile(log_path);
		score();
		the_text.log_ms_jgiot();
		close_errorlogfile();
		ktov_global_database(filename(variable(0),option('n')==NULL? "nts": "nt1").str);
	}

public:
	MijqalimSearcher_klali(): HillClimbingSearcher<double>(1) {}

	void run (double step0, double step1, double m0 /*,double m1,double m2,double m3*/) {
		par[0]=m0; //par[1]=m1; par[2]=m2; par[3]=m3;
		open_outfile (LOG_PATH "loghcs.ma2",hcs_logfile,0);
		the_text.atxl (500);
		CStr mamr_lbdiqa = variable(1)==NULL? variable(0): variable(1);
		the_text.qra_qlt (filename(mamr_lbdiqa,"txt").str);
		the_text.qra_nituxim_nkonim (filename(mamr_lbdiqa,"to").str);
		run_algorithm_a(step0,step1);
		hcs_logfile.close();
	}

};

void test_klali() {
	MijqalimSearcher_klali the_searcher;
	the_searcher.run(10,12, 0);
	//2.0708 0 1.1338 0.440251 0.0107374
}





void main (int argc, char* argv[]) {
	log_path = LOG_PATH;
	parse_command_line(argc,argv,1,2,"n","mks");
	if (swtch('k')) {       // klali
		if (swtch('s'))  atxl_klali(); else  atxl_klali_01();
		test_klali();
	}
}

#endif

