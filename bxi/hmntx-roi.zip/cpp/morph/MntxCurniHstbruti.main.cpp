/* MntxCurniHstbruti.main.cpp */

#include <math.h>

#include <morph/lexicon.h>
#include <morph/addlex.h>
#include <morph/morphanl.h>

#include <morph/alghist.h>
#include <morph/tiqun3.h>

#include <cpplib/ui.h>
#include <morph/morphui.h>
#include <morph/corpus.h>

#include <cpplib/wordcnt.h>
#include <cpplib/map.hxx>
#include <cpplib/hashtab.hxx>
#include <cpplib/countc.hxx>
#include <morph/hpmaio.h>
#include <morph/hpmamain.h>


void ntx_qlt (Index start_from_word_num=0) {
	thetext.ntx_qlt_1(start_from_word_num);
	thetext.ntx_qlt_2(start_from_word_num);
	thetext.taqen_nituxim(start_from_word_num);
}

/***************************************************************************/
/***********        analysis modes                              ********/
/***************************************************************************/

void test_mode_analysis () {
	thetext.ms_milim = thetext.ms_tauyot = thetext.ms_tauyot_baerek_hamiloni=0;
	ntx_qlt();
	thetext.hajwe_nituxim();
	thetext.log_ms_jgiot();
}


void batch_mode_analysis (Index start_from_word_num=0) {
	ntx_qlt(start_from_word_num);
	thetext.ktov_et_hanitux_jelanu(output);
}


void interactive_mode_analysis(Index start_from_word_num=0) {
	ntx_qlt(start_from_word_num);
	bdoq_et_hanitux_jelanu_laqlt(start_from_word_num);
	ktov_et_hanituxim_lapelet();
	ktov_tocaot();
}



/***************************************************************************/
/***********        The Main Program                                ********/
/***************************************************************************/

CStr lex_path;
CStr article_path, article_output_path;
CStr corpus_path, corpus_log_path, corpus_ready_log_path;
CStr training_corpus_path, training_corpus_output_path;

void read_the_command_line(int argc, char* argv[]) {
	set_synopsis ("\n"
		"Interactive mode (first time):        MntxCurniHstbruti -i    corpus-filename article-filename [options]\n"
		"Interactive mode (continue):          MntxCurniHstbruti -i -h corpus-filename article-filename [options]\n"
		"Batch mode (first time):              MntxCurniHstbruti -b    corpus-filename article-filename [options]\n"
		"Batch mode (continue):                MntxCurniHstbruti -b -h corpus-filename article-filename [options]\n"
		"	[NOTE: use the 'continue' mode only if you used the switch '-d' in all previous runs!]\n"
		"Compare mode:                         MntxCurniHstbruti -q    corpus-filename article-filename [options]\n"
		"    options:  [-l path-of-lexicon] [-g path-for-logfiles-and-inputfiles] [-o training-corpus-filename]\n"
		"    switches: [-d=dense-output-format] [-s=load-corpus-NTS-file] [-t=load-corpus-NT1-file]");
	parse_command_line (argc,argv,2,2,"lgxo","iqb h d st");
	lex_path = option('l')==NULL? ".": option('l');
	log_path = option('g')==NULL? ".": option('g');

	corpus_path=filename(variable(0),"txt").finalstr();


	if (swtch('t')) {
		corpus_ready_log_path=filename(variable(0),"nt1").finalstr();
		corpus_log_path=NULL;
	}
	else if (swtch('s')) {
		corpus_ready_log_path=filename(variable(0),"nts").finalstr();
		corpus_log_path= option('o')?
			corpus_log_path=filename(variable(0),"nt1").finalstr():
			corpus_log_path=NULL;
	}
	else {      
		corpus_ready_log_path=NULL;
		corpus_log_path= option('o')?
			filename(variable(0),"nt1").finalstr():
			corpus_log_path=filename(variable(0),"nts").finalstr();
	}

	if (option('o')) {
		training_corpus_path=filename(option('o'),"txt").finalstr();
		training_corpus_output_path=filename(option('o'),"to").finalstr();
	}
	else if (option('x')) {
		training_corpus_path=filename(option('x'),"txt").finalstr();
		training_corpus_output_path=filename(option('x'),"to").finalstr();
	}
	else {
		training_corpus_path=training_corpus_output_path=NULL;
	}

	article_path=filename(variable(1),"txt").finalstr();
	article_output_path=filename(variable(1), swtch('q')? "to": "out" ).finalstr();

	pelet_cafuf = swtch('d');
}



void atxl () {
	if (swtch('t')) {
		atxl_global_database (NULL,corpus_ready_log_path);
	}
	else if (swtch('s')) {
		atxl_global_database (NULL,corpus_ready_log_path);
		if (option('o'))  {    // read correct analysis file for corpus
			qra_nitux_nakon_global (training_corpus_path, training_corpus_output_path);
			xjv_sikuiim_lkol_hmilim_global(); 
			ktov_global_database (corpus_log_path);
		}
	}
	else {      
		atxl_global_database(corpus_path,NULL);
		if (option('o'))      // read correct analysis file for corpus
			qra_nitux_nakon_global (training_corpus_path, training_corpus_output_path);
		xjv_sikuiim_lkol_hmilim_global();
		ktov_global_database (corpus_log_path);
	}

	if (option('x')) {      // lmad tiqqunim lfi ha-corpus
		lmad_tiqunim (training_corpus_path, training_corpus_output_path);
		ktov_tiqunim (lex_path);
	}
}


void open_all_the_logs() {
	open_logfile(7); 
	open_lexlogfile(log_path);
	open_errorlogfile(log_path);
	//open_tiqunimlogfile(log_path);
	//open_sntncsiklogfile(log_path);
	//open_sntncanllogfile(log_path);
	//open_bituyimlogfile(log_path);
}

void close_all_the_logs() {
	logfile.close();  
	close_errorlogfile();
	close_lexlogfile();
	//close_tiqunimlogfile();
	//close_bituyimlogfile();
	//close_sntncsiklogfile();
	//close_sntncanllogfile();
}




void main (int argc, char* argv[]) {
	Index start_from_word_num;

	lexicon_is_creative=false;
	read_the_command_line(argc, argv);
	initialize_the_analyzer(lex_path,lex_path);
	atxl ();
	qra_tiqunim(lex_path);
	open_all_the_logs();

	thetext.atxl(500);
	thetext.qra_qlt (article_path);

	if (swtch('q')) {          // bdoq
		thetext.qra_nituxim_nkonim (article_output_path);
	}
	else if (swtch('h')) {               // hosef
		thetext.qra_pelet_xelqi (article_output_path);
		open_outfile_with_messages(article_output_path,output,ios::app);
		start_from_word_num = thetext.hanitux_jelanu_laqlt.count();
	}
	else {
		open_outfile_with_messages(article_output_path,output,0);
		start_from_word_num = 0;
	}

	if (swtch('q'))	test_mode_analysis();
	else if (swtch('i')) interactive_mode_analysis(start_from_word_num);
	else if (swtch('b')) batch_mode_analysis(start_from_word_num);

	close_all_the_logs();
}
