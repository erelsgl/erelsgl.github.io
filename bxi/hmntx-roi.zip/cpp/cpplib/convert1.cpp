/* convert1.cpp -- a file-conversion unit */

#include "convert1.h"
#include <string.h>

ifstream global_source;
ofstream global_target;

CStr punctuation_chars = " \n\t,;.!?:'\"()[]{}";

/*************************************************************************/
/*****       convert                                          *******/
/*************************************************************************/

status Converter::convert (istream& source, ostream& target) {
	start(target);
	myline.truncate();
	for (linenum=0;;++linenum)	{
		DOEOFr (myline.read(source,myformat.str()));
		if (my_show_linenum && linenum%my_show_linenum==0)  cerr << linenum << ' ';
		the_status = convert_line(target);
		if      (the_status==OK) {
			while (myformat.delimits(source))      // move all delimiters as they are, from source to target
				target << char(source.get());
		}
		else if (the_status==STAY_IN_THE_SAME_LINE) {
			skip (source,myformat.str());     // skip all delimiters
		}
		else if (the_status==STOP_THE_CONVERSION_NOW) {finish(target); return OK;}
		else										  return the_status;  // an error
		if (source.eof()) break;
	}
	finish(target);
	return OK;
}



#ifdef TEST_CONVERT1
/*************************************************************************/
/*****       convert self-test                                     *******/
/*************************************************************************/

#include <cpplib/cmdline1.h>


void main (int argc, char* argv[]) {
	cout << endl << "CONVERT 1.0" << endl;
	set_synopsis ("CONVERT source target");
	parse_command_line (argc,argv, 2,2, "","");

	open_infile (variable(0),global_source);
	open_outfile(variable(1),global_target);
	Converter theconverter;
	DOx(theconverter.convert());
}

#endif
