/* wordcnt.cpp -- word counter */

#include <cpplib/wordcnt.h>


status WordCounter::count_words_in_file  (istream& in, CStr the_stopper) {
	StringTemp cur_word(30);
	for (Index wordnum=0;;++wordnum) {
		skip_comments (in,'%');
		DOEOF (cur_word.readline(in," \t\n"));
		if (compare(cur_word.str,the_stopper)==0) break;
		DOr(insert(cur_word.str));
	}
}


