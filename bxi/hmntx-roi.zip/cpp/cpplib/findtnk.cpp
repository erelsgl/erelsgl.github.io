/* findtnk -- find verses in the TNK */

#include <cpplib/cmdline1.h>
#include <cpplib/convert1.h>
#include <cpplib/ivrit.h>

class TNKFinder: public Converter {
public:
	Index txilat_hapasuq, sof_hapasuq;
	uint ms_otiot, ms_rwaxim, ms_ptuxot, ms_stumot;

	void mca_et_qcot_hapasuq() {
		for (Index j=0; myline[j]!='\t'; ++j)   
			if (j>=myline.len) break;
		txilat_hapasuq=j+1;
		sof_hapasuq = charindex('.',myline.str)-1;
	}

	bool matxil_b(char ot) {
		return (myline.at(txilat_hapasuq)==ot);
	}

	bool nigmar_b(char ot) {
		return (myline.at(sof_hapasuq)==ot);
	}

	void sfor_otiot() {
		for (Index i=txilat_hapasuq; i<=sof_hapasuq; ++i) {
			uchar c = uchar(myline[i]);
			if (c=='{' && i+2<=sof_hapasuq) i+=2;
			if (is_heb(c)) ++ms_otiot;
			if (c==' ' && is_heb(myline[i-1])) ++ms_rwaxim;
		}
	}

	void sfor_parjiot() {
		if (strinstring("}�{",myline.str)) ++ms_stumot;
		if (strinstring("{�}",myline.str)) ++ms_stumot;
		if (strinstring("}�{",myline.str)) ++ms_ptuxot;
		if (strinstring("{�}",myline.str)) ++ms_ptuxot;
	}

	void start(ostream&) { ms_otiot=ms_ptuxot=ms_stumot=ms_rwaxim=0; }

	void finish(ostream&) { 
		cout << "^otiot " << ms_otiot << endl
			 << "rwaxim " << ms_rwaxim << endl
			 << "par$iot ptuxot " << ms_ptuxot << endl 
			 << "par$iot stumot " << ms_stumot << endl;
	}

	status convert_line (ostream& target) {
		mca_et_qcot_hapasuq();
		if (txilat_hapasuq>=myline.len) return STAY_IN_THE_SAME_LINE;
		sfor_otiot();
		sfor_parjiot();
		return STAY_IN_THE_SAME_LINE;
	}

	TNKFinder ():  Converter() {}
};

void main (int argc, char* argv[]) {
	cout << endl << "FINDTNK 1.0 -- TNK searches" << endl;
	set_synopsis ("FINDTNK source target [/t path-to-tnk]");
	parse_command_line (argc,argv, 2,2, "t","");
	CStr path_to_tnk = option('t')==NULL? ".": option('t');
	StringTemp input_filename=concat_path_to_filename(path_to_tnk,variable(0));
	StringTemp output_filename=concat_path_to_filename(path_to_tnk,variable(1));
	open_infile (input_filename.str, global_source);
	open_outfile(output_filename.str, global_target, 0);
	TNKFinder thefinder;
	thefinder. convert ();
}

