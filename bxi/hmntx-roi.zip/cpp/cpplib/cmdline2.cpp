/* cmdline2.cpp -- command-line handling routines */

#include <process.h>
#include <assert.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
#include <cpplib/cmdline2.h>
#include <cpplib/ui.h>



/*************************************************************************/
/***             Enhanced open routines   ********************************/
/*************************************************************************/

void enhanced_open_infile (CStr& filename, ifstream& stream, int or_mode/*=ios::nocreate*/)
{
	assert (filename!=NULL);
	char menu_EQ (CStr prompt, CStr filename);
	for (;;) {
		stream. open (filename, ios::in | or_mode);
		if (!stream.fail()) return;
		stream.clear();  
		switch ( menu_EQ("Error in opening input file, probably file not found",filename) ) {
			case 'e':  filename = input_string ("filename",100) .finalstr(); break;
			case 'q':  exit (1);
		}
	}
}

void enhanced_open_outfile (CStr& filename, ofstream& stream, int or_mode/*=ios::noreplace*/)
{
	assert (filename!=NULL);
	char menu_EQ   (CStr prompt, CStr filename);
	char menu_RAEQ (CStr prompt, CStr filename);
	for (;;) {
		stream .open (filename, ios::out | or_mode);
		if (!stream.fail()) return;
		stream.clear();  
		switch ( menu_RAEQ("Probably already exists",filename) ) {
			case 'r':
				stream .open (filename, ios::out | ios::trunc | (or_mode & ~ios::noreplace));
				if (!stream.fail()) return;
				switch (menu_EQ("Error in creating file",filename)) {
					case 'e':  filename = input_string ("filename",100) .finalstr(); break;
					case 'q':  exit (1);
				}
				break;
			case 'a':
				stream.open(filename, ios::out | ios::app | ios::ate | or_mode);
				if (!stream.fail()) return;
				switch (menu_EQ("Error in opening output file",filename)) {
					case 'e':  filename = input_string ("filename",100) .finalstr(); break;
					case 'q':  exit (1);
				}
				break;
			case 'e':  filename = input_string ("filename",100) .finalstr(); break;
			case 'q':  exit (1);
		}
	}
}


void enhanced_append_outfile (CStr& filename, ofstream& stream, int or_mode/*=0*/)
{
assert (filename!=NULL);
char menu_EQ   (CStr prompt, CStr filename);
	char menu_RAEQ (CStr prompt, CStr filename);
  for (;;) {
 	  stream .open (filename, ios::out | ios::app | ios::ate | or_mode);
	  if (!stream.fail()) return;
	stream.clear();  
	 switch (menu_EQ("Error in opening output file",filename)) {
										case 'e':
											  filename = input_string ("filename",100) .finalstr();
											  break;
										case 'q':
												exit (1);
	}
	}
}

char menu_EQ (CStr message, CStr filename)  // a subroutine of the file-open routines
{
	cout << "file " << filename << ": " << message << endl
		  << "What would you like to do now?" << endl
		  << "   [E]nter a new filename" << endl
		  << "   [Q]uit"                    << endl;
			return getche_from("eq");
}

char menu_RAEQ (CStr message, CStr filename)  // a subroutine of the file-open routines
{
	cout	<< "file " << filename << ": "  << message  << endl
			<< "What would you like to do now?"     << endl
			<< "   [R]eplace current file"          << endl
			<< "   [A]ppend to end of current file" << endl
			<< "   [E]nter a new file name"         << endl
			<< "   [Q]uit"                          << endl;
			return getche_from("raeq");
}

