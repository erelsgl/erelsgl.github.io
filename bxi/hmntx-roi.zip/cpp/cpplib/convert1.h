/* convert1.h -- a file-conversion class */

#ifndef __CONVERT1_H
#define __CONVERT1_H


#include <cpplib/stringt.h>
#include <fstream.h>

extern ifstream global_source;
extern ofstream global_target;


/*
	A Converter is a general class that you have to inherit in order to do something
		useful.
	You use the converter like this:
		YourConverterType your_converter;
		your_converter.convert (source,target);
			(source is an ifstream and target is an ofstream).
	You can also use the global_source and global_target by:
		your_converter.convert();

	You extend the converter by inheriting from it and overriding the 
		function "convert_line", and also (maybe) "start" and "finish".
*/

// the following are statuses that you should use when you override the 
//	"convert_line" routine:
// #define OK				    0       // this is already defined.
#define STAY_IN_THE_SAME_LINE   1001
#define STOP_THE_CONVERSION_NOW 1002

extern CStr punctuation_chars;

class Converter {
	protected:
		StringTemp myline;     // the current line that is converted
		Index linenum;         // the current line number
		uint my_show_linenum;  // If this variable is 0, no linenum information will be shown (the default).
	                           // If it is n (n>0), the conversion will print linenum every n lines (for debugging).
		Format myformat;

		virtual void start(ostream& target)			    {}  // the default does nothing
		virtual void finish(ostream& target)		    {}  // the default does nothing
		//virtual status read_line(istream& source) { return myline.readline(source); }
		virtual status convert_line(ostream& target)	{ target<<myline; return OK; }  // the default only copies the line to the output.
		
	public:
		Converter(CStr thedelimiters="\n"):   myline(300) /* this is the default line size */  , my_show_linenum(false), myformat(thedelimiters)  {}
			// If you use thedelimiters=punctuation_chars instead of "\n", you will have a word-converter instead of a line-converter.
		void show_linenum (uint value=1) { my_show_linenum=value; }
		status convert (istream& source, ostream& target);
		status convert() { return convert(global_source,global_target); }
};


#endif