/* conv.cpp */

#include <cpplib/cmdline1.h>
#include <cpplib/convert1.h>
#include <cpplib/ui.h>
#include <string.h>
#include <ctype.h>

int source_set_start, target_set_start;  // variables for charset conversion

char reverse_line_method;				// variables for line-reversal conversion

int old_field_start, old_field_end, new_field_start, new_field_end; // vars for field-moving conversion


void case_convert_line (char source_line[], ostream& target)
{
	int len = strlen(source_line);
	for (int i=0; i<len; ++i) {
		target << case_convert (
			source_line[i], source_set_start, target_set_start);
	}
}

void parenthesis_reverse_line (char source_line[], ostream& target)
{
	int len = strlen(source_line);
	for (int i=0; i<len; ++i) {
		target << parenthesis_reverse (source_line[i]);
	}
}

void full_reverse_line (char source_line[], ostream& target)
{
	int len = strlen(source_line);
	for (int i=len-1; i>=0; --i) 
		target << source_line[i];
}



/*********** hebrew reverse line methods **********************/


bool is_hebrew (uchar c) {
	return (source_set_start<=c && c<=source_set_start+26) ;
}

bool can_be_hebrew (uchar c) {
	return 
		is_hebrew(c) ||
		isspace(c)	||
		strchr ("&-.()[]{}",c);
}		


#define cur source_line[j]
#define print_range(from,to) for(k=from; k<to; ++k) target<<source_line[k]
#define print_range_rev(from,to) for(k=to-1; k>=from; --k) target<<source_line[k]

void hebrew_reverse_line_A (char source_line[], ostream& target)
{
	int len = strlen(source_line);
	int i,j,k;
	bool is_hebrew_field;
	for (i=0; i<len; ) {        // Iterate on source string

		for (j=i; j<len; ++j)         // find an English field
			if (can_be_hebrew(cur)) break;  // end of English field
		print_range(i,j);
		i=j;

		is_hebrew_field=false;
		for (j=i; j<len; ++j) {        // find an Hebrew field
			if (is_hebrew(cur))  is_hebrew_field=true;
			if (!can_be_hebrew(cur)) break;  // end of Hebrew field
		}
		if (is_hebrew_field)
			print_range_rev(i,j);
		else
			print_range(i,j);
		i=j;
	}
}

void hebrew_reverse_line_B (char source_line[], ostream& target)
/* similar to hebrew_reverse_line_A, only here i goes from 'len' to 0 */
{
	int len = strlen(source_line);
	int i,j,k;
	bool is_hebrew_field;
	for (i=len-1; i>=0; ) {        // Iterate on source string

		for (j=i; j>=0; --j)         // find an English field
			if (can_be_hebrew(cur)) break;  // end of English field
		print_range(j+1,i+1);
		i=j;

		is_hebrew_field=false;
		for (j=i; j>=0; --j) {        // find an Hebrew field
			if (is_hebrew(cur))  is_hebrew_field=true;
			if (!can_be_hebrew(cur)) break;  // end of Hebrew field
		}
		if (is_hebrew_field)
			print_range_rev(j+1,i+1);
		else
			print_range(j+1,i+1);
		i=j;
	}
}



void field_replace (char source_line[], ostream& target)
{
	int len = strlen(source_line);
	int i;
	for (i=0; i<old_field_start; ++i)
		target << source_line[i];
	for (i=new_field_start; i<new_field_end; ++i)
		target << source_line[i];
	for (i=old_field_end; i<len; ++i)
		target << source_line[i];
}



void main (int argc, char* argv[]) {
	cout << endl << "CONV 1.0 -- file conversion utility" << endl;
	set_synopsis ("CONV source target");
	parse_command_line (argc,argv, 2,2, "","");
	open_source (variable(0)); open_target(variable(1));
	cout << "Enter conversion action: " << endl 
		<< "1. change character sets" << endl 
		<< "2. reverse parenthesis" << endl 
		<< "3. reverse lines" << endl
		<< "4. move/remove fields" << endl;
	switch (getche_from("1234")) {
		case '1':  // change char-sets
			source_set_start = input_int ("\nASCII-start-code of source char set",0,255);
			target_set_start = input_int ("\nASCII-start-code of target char set",0,255);
			convert (case_convert_line);
			break;
		case '2':
			convert (parenthesis_reverse_line);
			break;
		case '3':  // reverse lines;
			cout <<  "\nreverse-line method [1=full, 2=Hebrew-A, 3=Hebrew-B]:"; cout.flush();
			switch (getche_from ("123")) {
				case '1':
					convert (full_reverse_line);
					break;
				case '2': 
					source_set_start = input_int ("\nASCII-start-code of Hebrew char set",0,255);
					convert (hebrew_reverse_line_A);
					break;
				case '3': 
					source_set_start = input_int ("\nASCII-start-code of Hebrew char set",0,255);
					convert (hebrew_reverse_line_B);
					break;
			}
			break;
		case '4':    // move/remove fields
			old_field_start = input_int ("old field start",0,500);			
			old_field_end = input_int ("old field end",0,500);			
			new_field_start = input_int ("new field start",0,500);			
			new_field_end = input_int ("new field end",0,500);
			convert (field_replace);
			break;
	}

}

