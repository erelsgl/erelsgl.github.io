/* klli1.test.cpp -- a main program to test a bug in skip_comments. */

#include <cpplib/klli1.h>
#include <cpplib/stringt.h>

status read_the_tavniot (CStr thepath) {
	ifstream tavniot_infile;
	StringTemp thefilename = concat_path_to_filename(thepath,"milon/tavniot.ma");
	cerr << "reading tavniot file " << thefilename << endl;
	DOr(open(thefilename.str,tavniot_infile));
	skip_comments(tavniot_infile,'%');
	cerr<<"skipped comments"<<endl;
/*	DOr(read_tavniot_jayakut(tavniot_infile));
	skip_comments(tavniot_infile,'%');
	DOr(read(tavniot_infile,tavniot_ribui_ecem,Format("P T")));
	skip_comments(tavniot_infile,'%');
	DOr(read(tavniot_infile,tavniot_toar,Format("P T")));
	skip_comments(tavniot_infile,'%');
	DOr(read(tavniot_infile,tavniot_poal_avar,Format("P T")));
	skip_comments(tavniot_infile,'%');
	DOr(read (tavniot_infile,tavniot_beinony,Format("P T")));
	for (Index i=0; i<NUM_OF_BINYANIM; ++i) {
		skip_comments(tavniot_infile,'%');
		DOr(read (tavniot_infile,txiliot_poal_atid[i],Format("P T")));
		skip_comments(tavniot_infile,'%');
		DOr(read (tavniot_infile,hemjeky_poal_atid_ZY[i],Format("P T")));
		skip_comments(tavniot_infile,'%');
		DOr(read (tavniot_infile,hemjeky_poal_atid_NY[i],Format("P T")));
		skip_comments(tavniot_infile,'%');
		DOr(read (tavniot_infile,hemjeky_poal_atid_ZR[i],Format("P T")));
		skip_comments(tavniot_infile,'%');
		DOr(read (tavniot_infile,hemjeky_poal_atid_NR[i],Format("P T")));
	}
	tavniot_infile.close();*/
	return OK;
}


void main (int argc, char* argv[]) {
	DOx(read_the_tavniot("."));
}
